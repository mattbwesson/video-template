/**
 * typewriter-tracking-match-cut.tsx — exactly two states, joined by one hard match cut:
 *
 *   STATE 1 (zoomed in): the camera sits close enough that the sentence overflows the frame —
 *   as characters are typed, the camera has to pan right to keep the active cursor in view.
 *   HARD CUT (scale-down match cut, mid-motion): a real 3D camera pull-back.
 *   STATE 2 (zoomed out): the whole sentence fits the frame at rest; typing simply continues to
 *   completion in place — no further camera movement needed.
 *
 * Typing is ONE continuous process across the whole composition (state 1 and state 2 share the
 * same character-reveal timeline) — the cut changes the CAMERA, never the typing. Characters
 * (letters, spaces, punctuation) simply become visible as they're typed, no per-character fade;
 * timing is weighted, not uniform (spaces are quicker, with a small extra beat after each word —
 * see buildCumulativeWeights).
 *
 * THE CUT: a real 3D camera move, `perspective(px) translateZ(z)` — apparent size is a BYPRODUCT
 * of the browser's own perspective projection, never a 2D scale. z is held at its "zoomed in"
 * value for all of state 1, animates down to 0 (natural size) during a short transition window,
 * then holds at 0 for all of state 2 — the standard excised-band match-cut timing (cutStart/
 * cutEnd, same shape as match-cut.tsx's matchCutTimeline) places a hard jump in that animation
 * during its fast stretch, on cubic-bezier(0.61, -0.35, 0.38, 1.15). The size of that jump is
 * configurable via `intensity` ("hard"/"medium"/"soft", same three presets as match-cut.tsx's
 * MatchCut — default "hard", cutStart 0.5/cutEnd 0.75), or via explicit `cutStart`/`cutEnd`.
 *
 * STATE 1's camera pan: the cursor drifts freely from a left start position, then once its
 * on-screen position would cross a tracking-zone threshold, the camera engages and holds it
 * there (computed in PRE-zoom coordinates, so the fixed zoomFactor amplifies it into the dramatic
 * on-screen sweep state 1 needs) — lightly smoothed with a short trailing average so it isn't
 * rigidly locked to the cursor frame-to-frame. STATE 2 has no pan at all: the sentence's full
 * width is measured up front, so its fixed centered position already fits everything that will
 * ever be typed.
 *
 * SCOPE: single baseline only (no line-wrapping) — camera tracking is a 1D horizontal pan.
 *
 * Part of the zm-motion library. Import:
 *   `import {TypewriterTrackingMatchCut} from 'zm-motion/typewriter-tracking-match-cut'`.
 */
import React, { useMemo } from "react";
import { AbsoluteFill, Easing, useCurrentFrame, useVideoConfig } from "remotion";
import { Caret } from "./caret";

export type TypewriterTrackingMatchCutProps = {
  text: string;

  /** Typing speed in characters per second (weighted — see buildCumulativeWeights). default 16 */
  charsPerSecond?: number;
  /** Fraction of the typing duration at which the scale-down match cut begins. default 0.42 */
  cutAtFraction?: number;
  /** Frames for the scale-down match-cut transition itself. default 16 */
  transitionDurationInFrames?: number;
  /** How much of the transition is skipped — same three presets as match-cut.tsx's MatchCut:
   *  "hard" (default, cutStart 0.5/cutEnd 0.75, skips 25%), "medium" (0.5/0.70, skips 20%), "soft"
   *  (0.5/0.65, skips 15%). Ignored if `cutStart`/`cutEnd` are also given — those win. */
  intensity?: "hard" | "medium" | "soft";
  /** Excised-band cut point within the transition (time, not eased output) — set directly to
   *  override `intensity` with an exact custom window. default 0.5 / 0.75 (via intensity "hard") */
  cutStart?: number;
  cutEnd?: number;
  /** How zoomed in state 1 is (state 2 is always natural/1×). default 2.4 */
  zoomInFactor?: number;
  /** perspective() distance for the 3D camera move — smaller = more dramatic foreshortening. default 1000 */
  perspectivePx?: number;
  /** Frames held after typing completes, before the composition ends. default 10 */
  endHoldInFrames?: number;

  fontSize?: number;
  fontWeight?: number;
  color?: string;
  cursorColor?: string;
  fontFamily?: string;
  background?: string;
};

const DEFAULT_FONT_FAMILY =
  "-apple-system, BlinkMacSystemFont, 'Helvetica Neue', Arial, sans-serif";
const DEFAULT_BACKGROUND =
  "radial-gradient(120% 140% at 12% 8%, #fdfdfc 0%, #f3f2f7 28%, #dde8f7 58%, #dff2ea 100%)";

// The one curve for the whole camera system.
const CAMERA_EASE = Easing.bezier(0.61, -0.35, 0.38, 1.15);

const clamp01 = (t: number): number => (t < 0 ? 0 : t > 1 ? 1 : t);

/**
 * Per-character typing weight: spaces are quicker (0.55×) than letters/punctuation (1×), plus a
 * small extra beat (+0.7) riding on each space that follows a word — a "breath" between words
 * without ever fully stopping. `cum[i]` is the total weight of the first `i` characters;
 * `cum[text.length] === total`.
 */
const buildCumulativeWeights = (text: string): { cum: number[]; total: number } => {
  const cum = [0];
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    let w = c === " " ? 0.55 : 1;
    if (c === " " && i > 0) w += 0.7;
    cum.push(cum[cum.length - 1] + w);
  }
  return { cum, total: cum[cum.length - 1] };
};

/** The largest character count whose cumulative weight is ≤ the given weighted progress `p`. */
const countAtWeightedProgress = (cum: number[], p: number): number => {
  let i = 0;
  while (i < cum.length - 1 && cum[i + 1] <= p) i++;
  return i;
};

// A single reusable canvas 2D context for text measurement — real glyph widths for a proportional
// font, not a character-count estimate, so the camera tracks the ACTUAL rendered cursor position.
let measureCtx: CanvasRenderingContext2D | null | undefined;
const measureTextWidth = (text: string, font: string): number => {
  if (measureCtx === undefined) {
    measureCtx =
      typeof document === "undefined" ? null : document.createElement("canvas").getContext("2d");
  }
  if (!measureCtx) return 0; // no DOM available — unreachable in Remotion's browser-based render
  measureCtx.font = font;
  return measureCtx.measureText(text).width;
};

/** The standard excised-band match-cut timeline (see match-cut.tsx's matchCutTimeline), self-
 *  contained here so this component can use the user-specified camera curve directly rather than
 *  match-cut's DOLLY mode (hard-wired to a different, held-start curve). `frame` is relative to
 *  the transition window's own start — negative/over-range values clamp, which is what makes
 *  "hold before / hold after" fall out for free. */
// Same three presets as match-cut.tsx's MatchCut — kept as a local copy since this file is
// self-contained and doesn't import from match-cut.tsx.
const INTENSITY_WINDOWS: Record<"hard" | "medium" | "soft", { cutStart: number; cutEnd: number }> = {
  hard: { cutStart: 0.5, cutEnd: 0.75 },
  medium: { cutStart: 0.5, cutEnd: 0.7 },
  soft: { cutStart: 0.5, cutEnd: 0.65 },
};

const resolveCutWindow = (
  props: TypewriterTrackingMatchCutProps,
): { cutStart: number; cutEnd: number } => {
  const preset = INTENSITY_WINDOWS[props.intensity ?? "hard"];
  return {
    cutStart: props.cutStart ?? preset.cutStart,
    cutEnd: props.cutEnd ?? preset.cutEnd,
  };
};

const dollyTimeline = (frame: number, T: number, cutStart: number, cutEnd: number) => {
  const f = clamp01(frame / T);
  const w1 = Math.max(0, cutStart);
  const w2 = Math.max(0, 1 - cutEnd);
  const fSplit = w1 + w2 === 0 ? 0.5 : w1 / (w1 + w2);
  const beforeCut = f < fSplit;
  const m = beforeCut ? (f / fSplit) * cutStart : cutEnd + ((f - fSplit) / (1 - fSplit)) * (1 - cutEnd);
  return { beforeCut, disp: CAMERA_EASE(m) };
};

/** Camera depth: disp 0→1 maps z from zNear (close, zoomFactor×) down to 0 (rest, 1×) — a real
 *  perspective(px) translateZ(z) dolly, same formula as match-cut.tsx's dollyTransform. */
const dollyDepth = (disp: number, zoomFactor: number, perspectivePx: number): number => {
  const zNear = perspectivePx * (1 - 1 / zoomFactor);
  return zNear * (1 - disp);
};

const SentenceLayer: React.FC<{
  text: string;
  translateX: number;
  fontSize: number;
  fontWeight: number;
  color: string;
  fontFamily: string;
  cursorColor: string;
  cursorBlink: boolean;
}> = ({ text, translateX, fontSize, fontWeight, color, fontFamily, cursorColor, cursorBlink }) => (
  <AbsoluteFill>
    <div
      style={{
        position: "absolute",
        left: 0,
        top: "50%",
        transform: `translate(${translateX}px, -50%)`,
        whiteSpace: "nowrap",
      }}
    >
      <span style={{ fontSize, fontWeight, color, fontFamily, letterSpacing: "-0.02em" }}>
        {text}
        <Caret
          color={cursorColor}
          blink={cursorBlink}
          width={Math.max(3, fontSize * 0.045)}
          height={fontSize * 0.92}
          marginLeft={fontSize * 0.03}
          style={{ verticalAlign: "text-bottom" }}
        />
      </span>
    </div>
  </AbsoluteFill>
);

/** Total duration in frames — for sizing a <Sequence>/<Player> before mounting (mirrors the
 *  imessageChatFlowDuration convention elsewhere in this library). */
export function typewriterTrackingMatchCutDuration(
  props: Pick<TypewriterTrackingMatchCutProps, "text" | "charsPerSecond" | "endHoldInFrames">,
  fps = 30,
): number {
  const { text, charsPerSecond = 16, endHoldInFrames = 10 } = props;
  const typingDurationInFrames = Math.max(1, Math.round((text.length / charsPerSecond) * fps));
  return typingDurationInFrames + endHoldInFrames;
}

export const TypewriterTrackingMatchCut: React.FC<TypewriterTrackingMatchCutProps> = (props) => {
  const {
    text,
    charsPerSecond = 16,
    cutAtFraction = 0.42,
    transitionDurationInFrames = 16,
    zoomInFactor = 2.4,
    perspectivePx = 1000,
    fontSize = 54,
    fontWeight = 700,
    color = "#0a0a0a",
    cursorColor = color,
    fontFamily = DEFAULT_FONT_FAMILY,
    background = DEFAULT_BACKGROUND,
  } = props;
  const { cutStart, cutEnd } = resolveCutWindow(props);

  const frame = useCurrentFrame();
  const { width, fps } = useVideoConfig();
  const typingDurationInFrames = Math.max(1, Math.round((text.length / charsPerSecond) * fps));
  const font = `${fontWeight} ${fontSize}px ${fontFamily}`;

  const layout = useMemo(() => {
    const { cum, total } = buildCumulativeWeights(text);
    const fullWidth = measureTextWidth(text, font);
    const cx = width / 2;
    // Where the cursor pins ON SCREEN once zoomed-in tracking engages, and where the sentence
    // starts on screen before it does — converted to PRE-zoom coordinates (dividing by
    // zoomInFactor) so that once the constant zoomInFactor camera scale is applied, the cursor
    // actually lands at these on-screen fractions.
    const screenTrackZoneX = width * 0.38;
    const screenLeftStart = width * 0.12;
    const unscaledTrackZoneX = cx + (screenTrackZoneX - cx) / zoomInFactor;
    const unscaledLeftMargin = cx + (screenLeftStart - cx) / zoomInFactor;
    const centeredTranslateX = (width - fullWidth) / 2;
    return { cum, total, unscaledTrackZoneX, unscaledLeftMargin, centeredTranslateX };
  }, [text, font, width, zoomInFactor]);

  const countAtFrame = (f: number): number =>
    countAtWeightedProgress(layout.cum, layout.total * clamp01(f / typingDurationInFrames));

  const count = countAtFrame(frame);
  const typing = count < text.length;

  const transitionStart = Math.round(typingDurationInFrames * cutAtFraction);
  const { beforeCut, disp } = dollyTimeline(
    frame - transitionStart,
    transitionDurationInFrames,
    cutStart,
    cutEnd,
  );
  const z = dollyDepth(disp, zoomInFactor, perspectivePx);
  const transform = `perspective(${perspectivePx}px) translateZ(${z}px)`;

  // Pre-zoom tracking pan: drift freely from the left start, then clamp once the cursor's
  // (pre-zoom) position would cross the tracking-zone threshold. Lightly smoothed (trailing
  // average) so it isn't rigidly locked to the cursor frame-to-frame.
  const trackingPanAt = (f: number): number => {
    const c = countAtFrame(f);
    const worldX = measureTextWidth(text.slice(0, c), font);
    const cursorFreeX = layout.unscaledLeftMargin + worldX;
    return layout.unscaledLeftMargin + Math.min(0, layout.unscaledTrackZoneX - cursorFreeX);
  };
  const PAN_LAG_FRAMES = 6;
  const smoothedPan = (() => {
    const lo = Math.max(0, frame - PAN_LAG_FRAMES);
    let sum = 0;
    let n = 0;
    for (let f = lo; f <= frame; f++) {
      sum += trackingPanAt(f);
      n++;
    }
    return sum / n;
  })();

  const translateX = beforeCut ? smoothedPan : layout.centeredTranslateX;

  return (
    <AbsoluteFill style={{ background }}>
      <AbsoluteFill style={{ transform, willChange: "transform" }}>
        <SentenceLayer
          text={text.slice(0, count)}
          translateX={translateX}
          fontSize={fontSize}
          fontWeight={fontWeight}
          color={color}
          fontFamily={fontFamily}
          cursorColor={cursorColor}
          cursorBlink={!typing}
        />
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
