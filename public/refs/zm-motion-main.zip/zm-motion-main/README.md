# zm-motion

A [Remotion](https://remotion.dev) motion-component library: the
[remocn](https://github.com/Remocn/remocn) animation primitives plus custom
compositions, consolidated into one place.

**→ [COMPONENTS.md](./COMPONENTS.md)** — every component in one table: what it does, its
props type, its duration helper, and what it keeps mounted. Start there.
**→ [AGENTS.md](./AGENTS.md)** — conventions, the frame-space contract, and the mounting
rules that govern render cost.

## Layout

```
zm-motion/
├── index.ts                # barrel — the complete public surface (generated)
├── COMPONENTS.md           # one-row-per-component inventory (generated)
├── AGENTS.md               # conventions for humans and agents
├── *.tsx                   # vendored remocn animation primitives (flat)
├── lib/                    # shared helpers (timeline, theme, color, motion, types)
├── orbit-animation/        # custom: icon row → orbit → collapse (self-contained)
├── zoom-meeting.tsx        # custom: Zoom meeting UI (2-up / 4-up, gallery ↔ share)
├── scripts/                # generators for index.ts and COMPONENTS.md
├── type-tests/             # compile-time tests (@ts-expect-error assertions)
└── site/                   # the preview gallery (Vite)
```

## Checks

```bash
npm run check    # regenerate the barrel, then strict-typecheck the library
```

## Install & import

Components import each other with **relative paths**, so the library resolves
like a normal package — no path-alias setup needed in the consumer.

```bash
npm install github:mattbwesson/zm-motion
```

```tsx
import { IconOrbitScene, ZoomMeetingScene } from 'zm-motion';
import { WhipPan } from 'zm-motion/whip-pan';
```

The repo is private, so `npm install` needs GitHub auth — a token in your
`.npmrc` or an SSH url:
`npm i git+ssh://git@github.com/mattbwesson/zm-motion.git`.

## Peer dependencies

`react`, `react-dom`, `remotion`, and `@remotion/*` are **peer** dependencies —
the host project provides them, so there is a single Remotion instance (mixed
Remotion versions break hooks/renders). Keep all `@remotion/*` packages on the
same version. Runtime deps (`@paper-design/shaders-react`, `culori`,
`lucide-react`) install with the library.

## Custom compositions

- **`IconOrbitScene`** (`orbit-animation/`) — nine placeholder icons pop into a
  row, lerp into a tilted spinning orbit, then collapse with a dot-grid ripple.
  Fully self-contained (inline shapes, no assets).
- **`ZoomMeetingScene`** (`zoom-meeting.tsx`) — a Zoom meeting UI that morphs
  from a gallery (2-up or 4-up via `participants`) into a screen-share. Inline
  black placeholders for video; Inter via `@remotion/google-fonts`.

## Attribution

The flat `*.tsx` primitives and `lib/` helpers are vendored from
[remocn](https://github.com/Remocn/remocn) via `shadcn add @remocn/*`. See the
remocn repository for their license and terms before redistributing.
