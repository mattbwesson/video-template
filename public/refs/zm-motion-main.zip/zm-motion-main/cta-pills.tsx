/**
 * cta-pills.tsx — labelled glass pills pop in one at a time while the camera
 * jump-cuts between them, then all of them arc into the centre and vanish.
 *
 * THE CHOREOGRAPHY, per pill, is two beats that overlap:
 *   1. POP    — it starts as a dot: width equals height, so `borderRadius: 999`
 *               makes a perfect circle, scaling 0 → 1 on an ease-out-expo.
 *   2. MORPH  — once the dot is ~80% grown, the wrapper's WIDTH animates out to
 *               the full pill. The content inside is a fixed-width row that
 *               `overflow: hidden` clips, so the text is REVEALED by the growth
 *               rather than stretched with it. Words then fade up on their own
 *               stagger, so the shape leads and the type catches up.
 *
 * THE CAMERA cuts rather than pans: each pill gets a window during which the
 * frame is scaled in and centred on it, and the cut to the next one is hard.
 * Because it tracks the pill's growing right edge, it has to recompute the morph
 * that `AnimatedPill` owns internally — the two are kept in step by hand, so if
 * you retune the morph, retune both.
 *
 * THE MERGE bows each pill along an arc into the centre: the perpendicular
 * offset peaks at the halfway point and is zero at both ends, so a pill leaves
 * and arrives on its true line and only bulges in between. They shrink to 5% and
 * fade as they go, which reads as being absorbed rather than flying off.
 *
 * Authored in a 1920x1080 coordinate space. The layout is absolutely positioned
 * in those units, so to use it at another size scale the whole component rather
 * than changing the numbers.
 */
import type { CSSProperties, ReactNode } from "react";
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from "remotion";

// ── Curves ──────────────────────────────────────────────────────────────────────────

/** Fast start, long settle — the pill's pop and its word rises. */
const EASE_OUT_EXPO = Easing.bezier(0.16, 1, 0.3, 1);
/** Symmetric in-out — the width morph, and the camera's follow of it. */
const EASE_IN_OUT = Easing.bezier(0.4, 0, 0.2, 1);
/** Slow to leave, then accelerates away hard — the merge into the centre. */
const EASE_MERGE = Easing.bezier(0.71, -0.01, 0.87, 0.49);

// ── Pill geometry ───────────────────────────────────────────────────────────────────

export const PILL_HEIGHT = 84;
/** Half the pill's height — centres a pill on its own midline, not its top edge. */
const PILL_HALF_H = 42;

const PILL_FONT_SIZE = 38;
const PILL_PADDING_X = 36;
const PILL_WORD_GAP = 8;

/**
 * Text widths are measured once by laying the words out as the same flex row of
 * per-word spans this component renders (so the inter-word gap is included) at
 * this size. Glyph advance widths scale linearly with font size, so rescaling by
 * the ratio is exact — no need to re-measure when the type size is nudged.
 */
export const PILL_MEASURED_AT_FONT_SIZE = 34;

const PILL_POP_DUR = 8;
/** The morph takes over once the dot has reached ~80% of its size (8 × 0.8 ≈ 6). */
const PILL_DOT_80_PERCENT_OFFSET = 6;
const PILL_MORPH_DUR = 22;

const PILL_TEXT_STAGGER = 4;
const PILL_TEXT_DUR = 14;
const PILL_TEXT_RISE = 16;

const DEFAULT_FONT_FAMILY =
  '-apple-system, BlinkMacSystemFont, "SF Pro Display", "Segoe UI", Arial, sans-serif';

/**
 * Laid-out width of a pill once fully morphed open. Exported because the camera
 * needs it to follow the growing right edge and the merge needs it to centre the
 * pill on the target.
 */
export function pillFullWidth(
  measuredTextWidth: number,
  extraPaddingRight = 0,
): number {
  return (
    measuredTextWidth * (PILL_FONT_SIZE / PILL_MEASURED_AT_FONT_SIZE) +
    PILL_PADDING_X * 2 +
    extraPaddingRight
  );
}

/**
 * Frames from a pill's first dot to its last word settling. Useful for spacing
 * several pills so their entrances don't collide.
 */
export function pillEntranceDuration(wordCount: number): number {
  return (
    PILL_DOT_80_PERCENT_OFFSET +
    Math.max(PILL_MORPH_DUR, (wordCount - 1) * PILL_TEXT_STAGGER + PILL_TEXT_DUR)
  );
}

// ── One pill ────────────────────────────────────────────────────────────────────────

export interface AnimatedPillProps {
  /** Frame in the CALLER's space — this component does no rebasing of its own. */
  frame: number;
  /** Frame (same space as `frame`) the dot begins popping on. */
  popStart: number;
  /** Pill text. Split on spaces; each word fades up on its own stagger. */
  text: string;
  /** Laid-out width of `text` at PILL_MEASURED_AT_FONT_SIZE. */
  measuredTextWidth: number;
  left: number;
  top: number;
  scale?: number;
  /** Extra right padding, for labels that need optical balance. Default 0. */
  extraPaddingRight?: number;
  /**
   * Any number. Gives this pill its own phase for the ambient bob so several on
   * screen don't drift in lockstep. Omit for no bob.
   */
  ambientSeed?: number;
  /** Font stack. Defaults to a system stack — the library ships no fonts. */
  fontFamily?: string;
  /** Fill of the glass surface. */
  tint?: string;
}

export function AnimatedPill({
  frame,
  popStart,
  text,
  measuredTextWidth,
  left,
  top,
  scale = 1,
  extraPaddingRight = 0,
  ambientSeed,
  fontFamily = DEFAULT_FONT_FAMILY,
  tint = "rgba(113, 0, 241, 0.42)",
}: AnimatedPillProps) {
  const words = text.split(" ");
  const fullWidth = pillFullWidth(measuredTextWidth, extraPaddingRight);

  const morphStart = popStart + PILL_DOT_80_PERCENT_OFFSET;

  const popScale = interpolate(frame, [popStart, popStart + PILL_POP_DUR], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
    easing: EASE_OUT_EXPO,
  });
  const morphT = interpolate(
    frame,
    [morphStart, morphStart + PILL_MORPH_DUR],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: EASE_IN_OUT },
  );
  // Width alone animates: the row inside keeps its full width and is clipped, so
  // the text is uncovered rather than squashed.
  const width = interpolate(morphT, [0, 1], [PILL_HEIGHT, fullWidth]);

  const floatT = Math.max(0, frame - popStart);
  const ambientX =
    ambientSeed != null ? Math.sin(floatT * 0.045 + ambientSeed * 1.7) * 8 : 0;
  const ambientY =
    ambientSeed != null ? Math.cos(floatT * 0.035 + ambientSeed * 1.3) * 10 : 0;

  return (
    <div
      style={{
        position: "absolute",
        left,
        top,
        width,
        height: PILL_HEIGHT,
        borderRadius: 999,
        background: tint,
        backdropFilter: "blur(20px) saturate(160%)",
        WebkitBackdropFilter: "blur(20px) saturate(160%)",
        border: "1px solid rgba(255, 255, 255, 0.22)",
        boxSizing: "border-box",
        overflow: "hidden",
        transform: `scale(${popScale * scale}) translate(${ambientX}px, ${ambientY}px)`,
        transformOrigin: "center center",
        boxShadow:
          "0 20px 40px -10px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.1) inset, 0 1px 1px rgba(255, 255, 255, 0.25) inset",
      }}
    >
      {/* Top highlight — the glint that sells it as glass rather than a swatch. */}
      <div
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          height: 1,
          background:
            "linear-gradient(90deg, rgba(255,255,255,0) 0%, rgba(255,255,255,0.4) 50%, rgba(255,255,255,0) 100%)",
        }}
      />
      <div
        style={{
          position: "absolute",
          inset: 0,
          width: fullWidth,
          display: "flex",
          alignItems: "center",
          paddingLeft: PILL_PADDING_X,
          paddingRight: PILL_PADDING_X + extraPaddingRight,
          fontFamily,
          fontSize: PILL_FONT_SIZE,
          fontWeight: 400,
          color: "#ffffff",
          letterSpacing: "-0.01em",
          whiteSpace: "nowrap",
          zIndex: 2,
        }}
      >
        {words.map((word, i) => {
          const wordStart = morphStart + i * PILL_TEXT_STAGGER;
          const wordT = interpolate(
            frame,
            [wordStart, wordStart + PILL_TEXT_DUR],
            [0, 1],
            { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: EASE_OUT_EXPO },
          );
          return (
            <span
              key={`${word}-${i}`}
              style={{
                display: "inline-block",
                marginRight: i < words.length - 1 ? PILL_WORD_GAP : 0,
                opacity: wordT,
                transform: `translateY(${interpolate(wordT, [0, 1], [PILL_TEXT_RISE, 0])}px)`,
              }}
            >
              {word}
            </span>
          );
        })}
      </div>
    </div>
  );
}

// ── The scene ───────────────────────────────────────────────────────────────────────

const FRAME_W = 1920;
const FRAME_H = 1080;
const CENTER_X = FRAME_W / 2;
const CENTER_Y = FRAME_H / 2;

const CAMERA_SCALE = 1.65;
/**
 * Framing bias along the pill's width. 0.72 rather than 0.5 keeps the growing
 * right edge in shot as the pill morphs open, instead of letting it run out of
 * frame while the camera sits on the pill's centre.
 */
const CAMERA_EDGE_BIAS = 0.72;

const MERGE_DUR = 26;
/** Pills shrink to 5% of their size as they arrive. */
const MERGE_SHRINK = 0.95;

const AURA_SIZE = 820;
const AURA_BLUR = 65;
const AURA_OPACITY = 0.65;
const AURA_SPIN_DEG_PER_FRAME = 2.5;

export interface CtaPill {
  text: string;
  /** Laid-out width of `text` at PILL_MEASURED_AT_FONT_SIZE. */
  measuredTextWidth: number;
  left: number;
  top: number;
  /** Frame the dot starts popping on, and the camera cuts to it. */
  popStart: number;
  scale?: number;
  /** Extra frames this pill waits before starting its merge. */
  stagger?: number;
  /** Perpendicular bow of the merge path, in px. */
  arc?: { x: number; y: number };
  /** Extra right padding for optical balance. */
  extraPaddingRight?: number;
}

/**
 * The four pills the scene was authored around.
 *
 * These widths were measured in a browser against DEFAULT_FONT_FAMILY. They are
 * font-specific: the original was authored against a condensed light face and
 * its numbers run ~15% wider, which leaves visible slack on the right when used
 * with anything else. If you pass your own `fontFamily`, re-measure — see
 * PILL_MEASURED_AT_FONT_SIZE for how.
 */
export const DEFAULT_CTA_PILLS: CtaPill[] = [
  { text: "News", measuredTextWidth: 82, left: 280, top: 320, popStart: 0, scale: 1.6, stagger: 0, arc: { x: -80, y: -60 } },
  { text: "Communication", measuredTextWidth: 227, left: 1120, top: 340, popStart: 25, scale: 1.6, stagger: 2, arc: { x: 80, y: -60 }, extraPaddingRight: 24 },
  { text: "Recognition", measuredTextWidth: 171, left: 310, top: 680, popStart: 80, scale: 1.6, stagger: 4, arc: { x: -80, y: 70 }, extraPaddingRight: 24 },
  { text: "Resources", measuredTextWidth: 150, left: 1160, top: 660, popStart: 110, scale: 1.6, stagger: 6, arc: { x: 80, y: 70 }, extraPaddingRight: 24 },
];

/** Frame the merge begins, measured from the first pill's pop. */
const MERGE_START = 150;

/**
 * Total frames the scene occupies, ending as the last pill finishes merging.
 *
 * Derived rather than a constant: the original shipped a fixed 141, which ended
 * before the merge had even started at 150 — anyone trusting it cut the ending
 * off. It now follows the pills you actually pass.
 */
export function ctaPillsDuration(pills: CtaPill[] = DEFAULT_CTA_PILLS): number {
  const lastMergeEnd = pills.reduce(
    (latest, p) => Math.max(latest, MERGE_START + (p.stagger ?? 0) + MERGE_DUR),
    MERGE_START + MERGE_DUR,
  );
  const lastEntranceEnd = pills.reduce(
    (latest, p) =>
      Math.max(latest, p.popStart + pillEntranceDuration(p.text.split(" ").length)),
    0,
  );
  return Math.max(lastMergeEnd, lastEntranceEnd) + 1;
}

export interface CtaPillsProps {
  /** Override the pills. Defaults to DEFAULT_CTA_PILLS. */
  pills?: CtaPill[];
  /**
   * What the pills merge into — a logo, a lockup, a mark. Rendered dead centre.
   * Omit for nothing, and the pills simply converge on the middle of the frame.
   */
  centerElement?: ReactNode;
  /** The blurred conic glow behind the centre element. Default false. */
  showAura?: boolean;
  /** Font stack for the pill labels. Defaults to a system stack. */
  fontFamily?: string;
  /** Fill of the glass pills. */
  tint?: string;
  style?: CSSProperties;
}

/**
 * See the file header for the mechanic. Use `ctaPillsDuration` for the length
 * rather than counting frames — the merge runs well past the last entrance, so
 * the obvious guess is short.
 */
export function CtaPills({
  pills = DEFAULT_CTA_PILLS,
  centerElement,
  showAura = false,
  fontFamily = DEFAULT_FONT_FAMILY,
  tint,
  style,
}: CtaPillsProps) {
  const frame = useCurrentFrame();

  // ── Camera: hard cuts, not pans ──
  // Each pill owns the frame from its own pop until the next one's, and the last
  // holds until the merge takes over.
  const activeIndex = pills.reduce(
    (found, p, i) => (frame >= p.popStart && frame < MERGE_START ? i : found),
    -1,
  );

  let camScale = 1;
  let camX = 0;
  let camY = 0;

  const active = activeIndex >= 0 ? pills[activeIndex] : undefined;
  if (active) {
    camScale = CAMERA_SCALE;
    // The camera follows the pill's own morph, so it recomputes it — AnimatedPill
    // owns that value but does not report it. Keep the two in step by hand.
    const morphStart = active.popStart + PILL_DOT_80_PERCENT_OFFSET;
    const morphT = interpolate(
      frame,
      [morphStart, morphStart + PILL_MORPH_DUR],
      [0, 1],
      { easing: EASE_IN_OUT, extrapolateLeft: "clamp", extrapolateRight: "clamp" },
    );
    const currentWidth = interpolate(
      morphT,
      [0, 1],
      [PILL_HEIGHT, pillFullWidth(active.measuredTextWidth, active.extraPaddingRight ?? 0)],
    );
    camX = CENTER_X - (active.left + currentWidth * CAMERA_EDGE_BIAS);
    camY = CENTER_Y - (active.top + PILL_HALF_H);
  }

  const auraPulse = interpolate(
    Math.sin((frame / 30) * Math.PI),
    [-1, 1],
    [0.92, 1.08],
  );

  return (
    // Transparent by design — mount it over your own background, or render with
    // a codec that keeps alpha.
    <AbsoluteFill style={{ overflow: "hidden", ...style }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          transform: `scale(${camScale}) translate(${camX}px, ${camY}px)`,
          transformOrigin: `${CENTER_X}px ${CENTER_Y}px`,
        }}
      >
        {showAura && (
          <div
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              transform: `translate(-50%, -50%) scale(${auraPulse})`,
              width: AURA_SIZE,
              height: AURA_SIZE,
              borderRadius: "50%",
              background: `conic-gradient(from ${
                (frame * AURA_SPIN_DEG_PER_FRAME) % 360
              }deg, #901dc9, #b13ee3, #d070f7, #a824e0, #901dc9)`,
              filter: `blur(${AURA_BLUR}px)`,
              opacity: AURA_OPACITY,
              zIndex: 1,
            }}
          />
        )}

        {centerElement && (
          <div
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              transform: "translate(-50%, -50%)",
              zIndex: 5,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            {centerElement}
          </div>
        )}

        <div style={{ position: "absolute", inset: 0, zIndex: 20 }}>
          {pills.map((pill, i) => {
            const extraPad = pill.extraPaddingRight ?? 0;
            const scale = pill.scale ?? 1;
            const arc = pill.arc ?? { x: 0, y: 0 };
            const mergeStart = MERGE_START + (pill.stagger ?? 0);
            const mergeProgress = interpolate(
              frame,
              [mergeStart, mergeStart + MERGE_DUR],
              [0, 1],
              { easing: EASE_MERGE, extrapolateLeft: "clamp", extrapolateRight: "clamp" },
            );

            // Bows out and back: peaks halfway, zero at both ends, so the pill
            // leaves and arrives on its true line and only bulges in between.
            const arcCurve = Math.sin(mergeProgress * Math.PI);

            const targetLeft =
              CENTER_X - (pillFullWidth(pill.measuredTextWidth, extraPad) * scale) / 2;
            const targetTop = CENTER_Y - PILL_HALF_H;

            const opacity = 1 - mergeProgress;
            // Unmounted once merged: these carry a backdrop-filter and a large
            // shadow, and in Remotion an invisible element still costs a full
            // render, layout and paint.
            if (opacity <= 0) return null;

            return (
              <div key={pill.text} style={{ opacity }}>
                <AnimatedPill
                  frame={frame}
                  popStart={pill.popStart}
                  text={pill.text}
                  measuredTextWidth={pill.measuredTextWidth}
                  extraPaddingRight={extraPad}
                  left={
                    interpolate(mergeProgress, [0, 1], [pill.left, targetLeft]) +
                    arc.x * arcCurve
                  }
                  top={
                    interpolate(mergeProgress, [0, 1], [pill.top, targetTop]) +
                    arc.y * arcCurve
                  }
                  scale={scale * (1 - mergeProgress * MERGE_SHRINK)}
                  ambientSeed={i}
                  fontFamily={fontFamily}
                  tint={tint}
                />
              </div>
            );
          })}
        </div>
      </div>
    </AbsoluteFill>
  );
}
