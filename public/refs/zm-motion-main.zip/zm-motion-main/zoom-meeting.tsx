import React from 'react';
import {AbsoluteFill, interpolate, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Inter';

// Portable Zoom meeting UI — no /public assets. Participant tiles + the shared
// screen are inline black placeholders; Inter is loaded via @remotion/google-fonts
// (not ambient CSS, which falls back in renders); and the stage scales to any
// composition size via useVideoConfig. Swap the black boxes for <OffthreadVideo>/
// <Img> when you have real media.
const {fontFamily: INTER} = loadFont();

const STAGE_W = 1051;
const STAGE_H = 756;
// The UI was composed to fill ~50% width of a 1920×1080 frame; BASE_SCALE keeps
// that framing, and `fit` (below) rescales it proportionally for any comp size.
const DESIGN_W = 1920;
const DESIGN_H = 1080;
const BASE_SCALE = (768 * 1.25) / STAGE_W;

const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
const clamp01 = (v: number) => Math.max(0, Math.min(1, v));

type Rect = {left: number; top: number; w: number; h: number};
const lerpRect = (a: Rect, b: Rect, t: number): Rect => ({
  left: lerp(a.left, b.left, t),
  top: lerp(a.top, b.top, t),
  w: lerp(a.w, b.w, t),
  h: lerp(a.h, b.h, t),
});

export interface Participant {
  name: string;
  /** green "speaking" border; also the default screen-share presenter */
  active?: boolean;
}

const DEFAULT_PARTICIPANTS: Participant[] = [
  {name: 'Ellana Parker', active: true},
  {name: 'Lianna Mitchell'},
];

// Tile geometry in 1051×756 stage space (48px top bar, 76px toolbar). A participant
// morphs from MEET[i] (gallery) → SHARE[i] (right filmstrip) as shareProgress 0→1.
// Two layouts: 2-up (side-by-side) and 4-up (2×2 grid), matching MeetingScene.
const MEET_2: Rect[] = [
  {left: 4, top: 169, w: 520, h: 323},
  {left: 527, top: 169, w: 520, h: 323},
];
const SHARE_2: Rect[] = [
  {left: 789, top: 176, w: 250, h: 141},
  {left: 789, top: 325, w: 250, h: 141},
];
const MEET_4: Rect[] = [
  {left: 4, top: 110, w: 518, h: 250},
  {left: 529, top: 110, w: 518, h: 250},
  {left: 4, top: 368, w: 518, h: 250},
  {left: 529, top: 368, w: 518, h: 250},
];
const SHARE_4: Rect[] = [
  {left: 789, top: 70, w: 250, h: 122},
  {left: 789, top: 204, w: 250, h: 122},
  {left: 789, top: 338, w: 250, h: 122},
  {left: 789, top: 472, w: 250, h: 122},
];

const Tile: React.FC<{rect: Rect; name: string; active: boolean; labelSize: number}> = ({
  rect, name, active, labelSize,
}) => (
  <div style={{
    position: 'absolute', left: rect.left, top: rect.top, width: rect.w, height: rect.h,
    borderRadius: 7, overflow: 'hidden',
    border: `3px solid ${active ? '#35c46a' : '#9aa6c2'}`,
    background: '#000', // placeholder — drop an <OffthreadVideo> here for real footage
  }}>
    <div style={{
      position: 'absolute', left: 10, bottom: 10,
      background: 'rgba(12,20,42,.72)', color: '#fff', fontFamily: INTER,
      fontSize: labelSize, fontWeight: 500, padding: '4px 10px', borderRadius: 6,
    }}>{name}</div>
  </div>
);

/**
 * Zoom meeting. `shareProgress` morphs the layout from a centered 2-up gallery (0) into a
 * screen-share view (1): the two video tiles slide/shrink into a right-side filmstrip while the
 * shared slide fades in on the left and a "<name>'s screen" tab appears in the top bar.
 */
export interface ZoomMeetingProps {
  /** 2 or 4 participants; controls the gallery layout (side-by-side vs 2×2). */
  participants?: Participant[];
  shareProgress?: number;
  zoom?: number;
  cursorX?: number;
  cursorY?: number;
  cursorOpacity?: number;
  cursorScale?: number;
}

export const ZoomMeetingScene: React.FC<ZoomMeetingProps> = ({
  participants = DEFAULT_PARTICIPANTS,
  shareProgress = 0, zoom = 1, cursorX = 0, cursorY = 0, cursorOpacity = 0, cursorScale = 1,
}) => {
  const {width, height} = useVideoConfig();
  // Scale the fixed design (STAGE at BASE_SCALE within 1920×1080) to fit any comp.
  const fit = Math.min(width / DESIGN_W, height / DESIGN_H);
  const scale = BASE_SCALE * fit * zoom;

  const p = shareProgress;
  const four = participants.length >= 4;
  const meetRects = four ? MEET_4 : MEET_2;
  const shareRects = four ? SHARE_4 : SHARE_2;
  const people = (participants.length ? participants : DEFAULT_PARTICIPANTS).slice(0, meetRects.length);
  const presenter = people.find((x) => x.active) ?? people[0] ?? DEFAULT_PARTICIPANTS[0];
  const initials = presenter.name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]).join('').toUpperCase();
  const labelSize = lerp(14, 12, p);
  const panelOpacity = clamp01(interpolate(p, [0.2, 0.85], [0, 1]));
  const panelScale = lerp(0.96, 1, clamp01(interpolate(p, [0.2, 1], [0, 1])));
  const tabOpacity = clamp01(interpolate(p, [0.1, 0.6], [0, 1]));

  return (
    <AbsoluteFill style={{display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: INTER}}>
      <div style={{
        position: 'relative', width: STAGE_W, height: STAGE_H,
        transform: `scale(${scale})`, transformOrigin: 'center center',
      }}>
        {/* Clipped UI window (rounded corners + gradient). The cursor sits OUTSIDE this so it
            isn't cropped when it overhangs the toolbar edge. */}
        <div style={{
          position: 'absolute', inset: 0,
          borderRadius: 12, overflow: 'hidden',
          boxShadow: '0 40px 100px rgba(0,0,0,0.65)',
        }}>
          {/* Meeting-window background gradient (bottom layer, behind tiles + chrome) */}
          <div style={{
            position: 'absolute', inset: 0,
            background: 'linear-gradient(180deg,#163a86 0%,#102c6c 32%,#081a42 70%,#0b2050 100%)',
          }} />
          {/* Shared slide — fades / scales in as the tiles move aside */}
          {panelOpacity > 0.001 ? (
            <div
              style={{
                position: 'absolute', left: 18, top: 70, width: 755, height: 560,
                opacity: panelOpacity, transform: `scale(${panelScale})`, transformOrigin: 'center center',
                borderRadius: 10, overflow: 'hidden', boxShadow: '0 8px 30px rgba(0,0,0,0.35)',
              }}
            >
              {/* placeholder — drop an <Img>/<OffthreadVideo> here for real shared content */}
              <div style={{width: '100%', height: '100%', background: '#000'}} />
            </div>
          ) : null}
          {/* Video tiles render before the chrome so the top bar + toolbar sit above them */}
          {people.map((part, i) => (
            <Tile
              key={i}
              rect={lerpRect(meetRects[i], shareRects[i], p)}
              name={part.name}
              active={!!part.active}
              labelSize={labelSize}
            />
          ))}
          {/* HTML chrome: top bar + toolbar with transparent stage background */}
          <div style={{position: 'absolute', inset: 0}} dangerouslySetInnerHTML={{__html: meetingHtml(INTER)}} />
          {/* "<name>'s screen" tab in the top bar, fades in with the share */}
          {tabOpacity > 0.001 ? (
            <div style={{
              position: 'absolute', left: 64, top: 9, opacity: tabOpacity,
              display: 'flex', alignItems: 'center', gap: 8,
              background: 'rgba(255,255,255,.17)', borderRadius: 9, padding: '5px 10px 5px 6px',
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: 6,
                background: 'linear-gradient(135deg,#c98f6b,#7a4a35)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: '#fff', fontSize: 10, fontWeight: 700,
              }}>{initials}</span>
              <span style={{color: '#fff', fontSize: 14, fontWeight: 600, whiteSpace: 'nowrap'}}>{presenter.name}&#39;s screen</span>
            </div>
          ) : null}
        </div>
        {/* Pointer that animates in and clicks "Share" — outside the clip so it can overhang the UI */}
        {cursorOpacity > 0.001 ? (
          <div style={{
            position: 'absolute', left: 0, top: 0, zIndex: 10,
            transform: `translate(${cursorX}px, ${cursorY}px) scale(${cursorScale})`,
            transformOrigin: 'top left',
            opacity: cursorOpacity,
            filter: 'drop-shadow(0 5px 9px rgba(0,0,0,.5)) drop-shadow(0 0 12px rgba(130,175,255,.28))',
          }}>
            <svg viewBox="0 0 938.07 1041.37" width={64} height="auto" style={{display: 'block'}} xmlns="http://www.w3.org/2000/svg">
              <path d="M90.03.04c16.97-.65,32.79,6.47,48.24,15.24,197.2,111.95,394.45,223.83,591.68,335.73,54.31,30.81,108.87,61.21,162.85,92.59,39.07,22.71,54.48,64.61,39.8,105.86-10.96,30.81-32.71,50.36-64.93,56.56-109.14,20.99-218.32,41.77-327.6,62-30.62,5.67-53.03,21.08-69.12,47.68-56.69,93.76-113.69,187.33-171,280.71-32.85,53.53-103.89,60.37-143.72,14.52-11.52-13.26-17.79-28.88-20.46-45.92-26.74-170.98-53.28-341.99-80-512.97C37.77,336.79,19.8,221.54,1.33,106.37-7.9,48.79,31.8-.09,90.03.04Z" fill="#ffffff"/>
            </svg>
          </div>
        ) : null}
      </div>
    </AbsoluteFill>
  );
};

const meetingHtml = (font: string) => `<style>
:root{--ico:#eef2fb;--lbl:#b7c1da;--green:#37b96b;--red:#e8493f;--gborder:#35c46a;}
*{box-sizing:border-box;margin:0;padding:0}
html,body{font-family:${JSON.stringify(font)},system-ui,sans-serif;-webkit-font-smoothing:antialiased;text-rendering:optimizeLegibility}
body{background:transparent}
.stage{width:1051px;height:756px;background:transparent;overflow:hidden;display:flex;flex-direction:column;color:var(--ico)}
.top{height:48px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:0 13px}
.tdots{display:flex;gap:9px}
.tdots i{width:11px;height:11px;border-radius:50%;border:1.5px solid #8b99c4;display:block}
.tright{display:flex;align-items:center;gap:9px;font-size:13px;color:#dfe5f4}
.enc{display:flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:6px;background:rgba(124,116,214,.28);padding:3px}
.enc svg{width:15px;height:15px;display:block}
.recb{display:flex;align-items:center;gap:6px;color:#fff;font-weight:600;font-size:12px;padding:3px 9px;border-radius:7px;background:rgba(255,255,255,.08)}
.recb .rdot{width:7px;height:7px;border-radius:50%;background:#e8493f;display:block}
.vsep{width:1px;height:15px;background:rgba(255,255,255,.22);display:block}
.views{display:flex;align-items:center;gap:7px;color:#eef2fb;font-size:13px}
.vlayout{display:flex;width:15px;height:15px}
.vlayout svg{width:15px;height:15px;display:block}
.bar{height:76px;flex:none;display:flex;align-items:center;justify-content:space-between;padding:0 4px}
.grp{display:flex;align-items:flex-start}
.grp.center{gap:1.5px}
.ctl{display:flex;flex-direction:column;align-items:center;gap:8px;flex:none;width:80px;cursor:pointer}
.ci{height:24px;display:flex;align-items:center;justify-content:center;color:var(--ico);position:relative}
.ci svg{height:24px;width:auto;max-width:34px;display:block}
.glyph{position:relative;display:flex;align-items:center;justify-content:center}
.cl{font-size:12.5px;color:var(--lbl);white-space:nowrap;line-height:1;transform:translateX(-7px)}
.ctl.share{position:relative}
.ctl.share::before{content:"";position:absolute;left:calc(50% - 7px);top:-7px;transform:translateX(-50%);width:60px;height:58px;border-radius:10px;background:rgba(255,255,255,.12)}
.ctl.share .ci,.ctl.share .cl{position:relative;z-index:1}
.count{font-size:13px;color:var(--lbl);margin-left:4px;line-height:1}
.caret{display:flex;align-items:center;justify-content:center;width:10px;height:10px;margin-left:4px}
.caret svg{width:10px;height:10px;display:block}
.badge{position:absolute;top:-7px;right:-12px;background:#f24c4c;color:#fff;font-size:11px;font-weight:700;min-width:18px;height:18px;border-radius:9px;display:flex;align-items:center;justify-content:center;padding:0 4px;line-height:1}
.dot{position:absolute;top:-3px;right:-4px;width:9px;height:9px;border-radius:50%;background:#f24c4c;display:block}
.end-glyph svg{height:26px}
</style>
<div class="stage">
  <div class="top">
    <div class="tdots"><i></i><i></i><i></i></div>
    <div class="tright">
      <span class="enc"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.828313 3.80959C0.85168 3.55542 1.0973 3.37443 1.36539 3.37707C3.8807 3.40184 6.54252 1.1319 7.56571 0.159581C7.78962 -0.0531944 8.21239 -0.0531935 8.4363 0.159583C9.45948 1.1319 12.1213 3.40185 14.6366 3.37707C14.9047 3.37443 15.1504 3.55542 15.1737 3.80959C15.8876 11.5756 11.3095 15.0739 8.05234 15.9829C8.0183 15.9924 7.98374 15.9924 7.9497 15.9829C4.69254 15.0739 0.114371 11.5756 0.828313 3.80959ZM12.3536 6.35355C12.5488 6.15829 12.5488 5.84171 12.3536 5.64645C12.1583 5.45118 11.8417 5.45118 11.6465 5.64645L7.04148 10.2514L5.39045 8.18765C5.21795 7.97202 4.9033 7.93706 4.68767 8.10957C4.47204 8.28207 4.43708 8.59672 4.60958 8.81235L6.60958 11.3123C6.69843 11.4234 6.83036 11.4914 6.97237 11.4992C7.11437 11.5071 7.25301 11.4541 7.35357 11.3536L12.3536 6.35355Z" fill="#00FF91"/></svg></span>
      <span class="recb"><span class="rdot"></span>REC</span>
      <span class="vsep"></span>
      <span class="views">Views<span class="vlayout"><svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M11.25 3.375C11.6642 3.375 12 3.03921 12 2.625L12 0.750001C12 0.335787 11.6642 5.09859e-07 11.25 4.91753e-07L9.375 4.09794e-07C8.96079 3.91688e-07 8.625 0.335787 8.625 0.75L8.625 2.625C8.625 3.03921 8.96079 3.375 9.375 3.375L11.25 3.375Z" fill="white"/><path d="M11.25 7.6875C11.6642 7.6875 12 7.35171 12 6.9375L12 5.0625C12 4.64829 11.6642 4.3125 11.25 4.3125L9.375 4.3125C8.96079 4.3125 8.625 4.64829 8.625 5.0625L8.625 6.9375C8.625 7.35171 8.96079 7.6875 9.375 7.6875L11.25 7.6875Z" fill="white"/><path d="M11.25 8.625C11.6642 8.625 12 8.96079 12 9.375L12 11.25C12 11.6642 11.6642 12 11.25 12L9.375 12C8.96079 12 8.625 11.6642 8.625 11.25L8.625 9.375C8.625 8.96079 8.96079 8.625 9.375 8.625L11.25 8.625Z" fill="white"/><path d="M7.125 12C7.53921 12 7.875 11.6642 7.875 11.25L7.875 0.75C7.875 0.335787 7.53921 3.29549e-07 7.125 3.11443e-07L0.750001 3.27834e-08C0.335787 1.46776e-08 5.09859e-07 0.335786 4.91753e-07 0.75L3.27834e-08 11.25C1.46776e-08 11.6642 0.335787 12 0.75 12L7.125 12Z" fill="white"/></svg></span></span>
    </div>
  </div>
  <div style="flex:1"></div>
  <div class="bar">
    <div class="grp left"><div class="ctl"><div class="ci"><span class="glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M7.5 4.5C7.5 2.01 9.51 0 12 0C14.49 0 16.5 2.01 16.5 4.5V12C16.5 14.49 14.49 16.5 12 16.5C9.51 16.5 7.5 14.49 7.5 12V4.5ZM12 15C13.65 15 15 13.65 15 12V4.5C15 2.85 13.65 1.5 12 1.5C10.35 1.5 9 2.85 9 4.5V12C9 13.65 10.35 15 12 15Z" fill="white"/><path d="M19.485 12.15C19.5 12.105 19.5 12.045 19.5 12C19.5 11.58 19.17 11.25 18.75 11.25C18.33 11.25 18 11.58 18 12C18 15.315 15.315 18 12 18C8.685 18 6 15.315 6 12C6 11.58 5.67 11.25 5.25 11.25C4.83 11.25 4.5 11.58 4.5 12C4.5 12.045 4.5 12.105 4.515 12.15C4.575 15.96 7.5 19.08 11.25 19.455V22.5H8.25C7.83 22.5 7.5 22.83 7.5 23.25C7.5 23.67 7.83 24 8.25 24H15.75C16.17 24 16.5 23.67 16.5 23.25C16.5 22.83 16.17 22.5 15.75 22.5H12.75V19.455C16.5 19.08 19.425 15.96 19.485 12.15Z" fill="white"/></svg></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">Audio</div></div><div class="ctl"><div class="ci"><span class="glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M12.3747 5.8125C13.9772 5.8125 15.2808 7.11595 15.2808 8.71875V16.7109C15.2808 17.1119 14.9549 17.4375 14.5543 17.4375H5.10923C3.50672 17.4375 2.20312 16.134 2.20312 14.5312V6.53906C2.20312 6.13815 2.52906 5.8125 2.92969 5.8125H12.3747ZM23.3842 5.55849C23.0123 5.38252 22.5867 5.42219 22.2561 5.66632L18.4783 8.49032C18.1576 8.73154 18.0923 9.18855 18.3335 9.50925C18.5733 9.82996 19.0318 9.89244 19.3496 9.65398L22.5469 7.26417V15.9858L19.3494 13.5962C19.0316 13.3577 18.5732 13.4202 18.3334 13.7409C18.0922 14.0616 18.1574 14.5186 18.4781 14.7598L22.256 17.5838C22.5865 17.828 23.0123 17.8676 23.384 17.6917C23.6793 17.5553 24 17.2232 24 16.7124V6.53761C24 6.02684 23.6793 5.69465 23.3842 5.55849ZM12.3747 4.35938H2.92969C1.72577 4.35938 0.75 5.33573 0.75 6.53906V14.5312C0.75 16.9386 2.70169 18.8906 5.10923 18.8906H14.5543C15.758 18.8906 16.7339 17.915 16.7339 16.7109V8.71875C16.7339 6.31136 14.7822 4.35938 12.3747 4.35938Z" fill="white"/></svg></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">Video</div></div></div>
    <div class="grp center"><div class="ctl"><div class="ci"><span class="glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M9 11.25C10.2586 11.25 11.398 11.7674 12.2139 12.5996C12.5038 12.8953 12.4987 13.3702 12.2031 13.6602C11.9074 13.95 11.4326 13.9459 11.1426 13.6504C10.5972 13.0941 9.83938 12.75 9 12.75H7.5C5.84315 12.75 4.5 14.0931 4.5 15.75V18C4.5 18.8284 5.17157 19.5 6 19.5H9C9.41421 19.5 9.75 19.8358 9.75 20.25C9.75 20.6642 9.41421 21 9 21H6C4.34315 21 3 19.6569 3 18V15.75C3 13.2647 5.01472 11.25 7.5 11.25H9ZM16.9688 14.25C19.1951 14.25 21 16.0549 21 18.2812C21 19.7828 19.7828 21 18.2812 21H13.2188C11.7172 21 10.5 19.7828 10.5 18.2812C10.5 16.0549 12.3049 14.25 14.5312 14.25H16.9688ZM14.5312 15.75C13.1333 15.75 12 16.8833 12 18.2812C12 18.9543 12.5457 19.5 13.2188 19.5H18.2812C18.9543 19.5 19.5 18.9543 19.5 18.2812C19.5 16.8833 18.3667 15.75 16.9688 15.75H14.5312ZM15.75 6.75C17.4069 6.75 18.75 8.09315 18.75 9.75C18.75 11.4069 17.4069 12.75 15.75 12.75C14.0931 12.75 12.75 11.4069 12.75 9.75C12.75 8.09315 14.0931 6.75 15.75 6.75ZM15.75 8.25C14.9216 8.25 14.25 8.92157 14.25 9.75C14.25 10.5784 14.9216 11.25 15.75 11.25C16.5784 11.25 17.25 10.5784 17.25 9.75C17.25 8.92157 16.5784 8.25 15.75 8.25ZM8.25 3.75C9.90685 3.75 11.25 5.09315 11.25 6.75C11.25 8.40685 9.90685 9.75 8.25 9.75C6.59315 9.75 5.25 8.40685 5.25 6.75C5.25 5.09315 6.59315 3.75 8.25 3.75ZM8.25 5.25C7.42157 5.25 6.75 5.92157 6.75 6.75C6.75 7.57843 7.42157 8.25 8.25 8.25C9.07843 8.25 9.75 7.57843 9.75 6.75C9.75 5.92157 9.07843 5.25 8.25 5.25Z" fill="white"/></svg></span><span class="count">3</span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">Participants</div></div><div class="ctl"><div class="ci"><span class="glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M9.29701 7.5C7.57927 7.49999 5.98769 7.70687 4.70886 7.95109C3.24992 8.22969 2.25 9.57056 2.25 11.1714V15C2.25 17.0711 3.92893 18.75 6 18.75H8.02007L8.18758 19.2701C8.35119 19.7781 8.40305 20.4191 8.21151 20.9937C9.17005 20.8227 10.2679 20.2073 11.0175 19.0837L11.2402 18.75H12.75C14.8211 18.75 16.5 17.0711 16.5 15V11.2002C16.5 9.54374 15.4283 8.15789 13.8957 7.90116C12.5922 7.68281 10.9931 7.50001 9.29701 7.5ZM4.4275 6.47771C5.7745 6.22048 7.46276 5.99999 9.29701 6C11.0966 6.00001 12.7812 6.19358 14.1435 6.42177C16.4976 6.81612 18 8.91586 18 11.2002V15C18 17.8995 15.6495 20.25 12.75 20.25H12.0267C10.317 22.4851 7.60183 22.9324 6.35494 22.9969C5.98316 23.0161 5.60256 22.7788 5.51294 22.3575C5.4277 21.9567 5.65149 21.5999 5.96668 21.4495C6.23293 21.3224 6.59601 21.0967 6.78849 20.5193C6.8142 20.4422 6.82934 20.3501 6.83319 20.25H6C3.1005 20.25 0.75 17.8995 0.75 15L0.75 11.1714C0.75 8.96929 2.15096 6.91245 4.4275 6.47771Z" fill="white"/><path fill-rule="evenodd" clip-rule="evenodd" d="M9.20884 2.70109C10.4877 2.45687 12.0793 2.24999 13.797 2.25C15.493 2.25001 17.0922 2.43281 18.3957 2.65116C19.9283 2.90789 21 4.29374 21 5.95023V9.75C21 10.8264 20.5465 11.7969 19.8201 12.4808C19.5 13.1689 19.5 13.1689 20.6134 13.7813C21.7664 12.8182 22.5 11.3698 22.5 9.75V5.95023C22.5 3.66586 20.9976 1.56612 18.6435 1.17177C17.2812 0.943579 15.5966 0.750006 13.797 0.75C11.9627 0.749993 10.2745 0.97048 8.92748 1.22771C7.45177 1.50952 6.34397 2.47293 5.7472 3.71569C5.50867 4.21241 5.94319 4.71018 6.49114 4.652C6.78832 4.62045 7.05485 4.42274 7.20292 4.16315C7.63173 3.41137 8.33863 2.86727 9.20884 2.70109Z" fill="white"/><path d="M5.625 12C6.24632 12 6.75 12.5037 6.75 13.125C6.75 13.7463 6.24632 14.25 5.625 14.25C5.00368 14.25 4.5 13.7463 4.5 13.125C4.5 12.5037 5.00368 12 5.625 12ZM9.375 12C9.99632 12 10.5 12.5037 10.5 13.125C10.5 13.7463 9.99632 14.25 9.375 14.25C8.75368 14.25 8.25 13.7463 8.25 13.125C8.25 12.5037 8.75368 12 9.375 12ZM13.125 12C13.7463 12 14.25 12.5037 14.25 13.125C14.25 13.7463 13.7463 14.25 13.125 14.25C12.5037 14.25 12 13.7463 12 13.125C12 12.5037 12.5037 12 13.125 12Z" fill="white"/></svg><span class="badge">1</span></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">Chat</div></div><div class="ctl"><div class="ci"><span class="glyph"><svg width="25" height="24" viewBox="0 0 25 24" fill="none"><path d="M10.2255 22.0418C9.6225 22.2689 8.9386 22.0789 8.52995 21.5709C7.34054 20.0921 5.63034 17.5145 3.39505 14.1456C3.15429 13.7827 2.90742 13.4106 2.65447 13.0298C0.840792 10.2991 0.310392 7.56619 1.19401 5.28443C2.08189 2.99166 4.22554 1.5989 6.79724 1.19997C9.03995 0.852076 10.991 2.04205 12.2514 3.12483C12.9097 3.69036 13.4588 4.29278 13.8662 4.80496C14.4812 4.57673 15.2518 4.34084 16.0986 4.19334C17.7199 3.91093 19.9902 3.89337 21.7548 5.35424C23.7782 7.0294 24.9426 9.34093 24.5797 11.7795C24.2186 14.2064 22.4146 16.291 19.5041 17.7096C14.7264 20.0408 11.9805 21.3808 10.2255 22.0418Z" fill="none" stroke="white" stroke-width="1.6"/></svg></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">React</div></div><div class="ctl share"><div class="ci"><span class="glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M21 2C22.6569 2 24 3.34315 24 5V18.5C24 20.1569 22.6569 21.5 21 21.5H3C1.34315 21.5 0 20.1569 0 18.5V5C0 3.34315 1.34315 2 3 2H21ZM12.5039 5.96875C12.2254 5.67741 11.7746 5.67741 11.4961 5.96875L6.75 10.96C6.47153 11.2514 6.47153 11.7242 6.75 12.0156L7.75879 13.0703C8.03726 13.3617 8.48813 13.3617 8.7666 13.0703L10.5742 11.1543V17.0039C10.5743 17.416 10.8933 17.75 11.2871 17.75H12.7129C13.1067 17.75 13.4257 17.416 13.4258 17.0039V11.1543L15.2334 13.0703C15.5119 13.3617 15.9627 13.3617 16.2412 13.0703L17.25 12.0156C17.5285 11.7242 17.5285 11.2514 17.25 10.96L12.5039 5.96875Z" fill="#00FF91"/></svg></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">Share</div></div><div class="ctl"><div class="ci"><span class="glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path d="M11.8301 5.22852C13.0202 8.44435 15.5556 10.9798 18.7715 12.1699L20.3389 12.75L18.7715 13.3301C15.5556 14.5202 13.0202 17.0556 11.8301 20.2715L11.25 21.8389L10.6699 20.2715C9.47981 17.0556 6.94435 14.5202 3.72852 13.3301L2.16016 12.75L3.72852 12.1699C6.94435 10.9798 9.47981 8.44435 10.6699 5.22852L11.25 3.66016L11.8301 5.22852Z" stroke="#FFD647" stroke-width="1.5"/><path d="M19.6084 1.7334C20.0642 2.9649 21.0351 3.93581 22.2666 4.3916L22.5586 4.5L22.2666 4.6084C21.0351 5.06419 20.0642 6.0351 19.6084 7.2666L19.5 7.55859L19.3916 7.2666C18.9358 6.0351 17.9649 5.06419 16.7334 4.6084L16.4404 4.5L16.7334 4.3916C17.9649 3.93581 18.9358 2.9649 19.3916 1.7334L19.5 1.44043L19.6084 1.7334Z" fill="#FFD647" stroke="#FFD647"/></svg></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">AI Companion</div></div><div class="ctl"><div class="ci"><span class="glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><rect x="0.75" y="0.75" width="22.5" height="22.5" rx="11.25" stroke="white" stroke-width="1.5"/><path d="M7.5 12C7.5 12.8284 6.82843 13.5 6 13.5C5.17157 13.5 4.5 12.8284 4.5 12C4.5 11.1716 5.17157 10.5 6 10.5C6.82843 10.5 7.5 11.1716 7.5 12Z" fill="white"/><path d="M13.5 12C13.5 12.8284 12.8284 13.5 12 13.5C11.1716 13.5 10.5 12.8284 10.5 12C10.5 11.1716 11.1716 10.5 12 10.5C12.8284 10.5 13.5 11.1716 13.5 12Z" fill="white"/><path d="M18 13.5C18.8284 13.5 19.5 12.8284 19.5 12C19.5 11.1716 18.8284 10.5 18 10.5C17.1716 10.5 16.5 11.1716 16.5 12C16.5 12.8284 17.1716 13.5 18 13.5Z" fill="white"/></svg><span class="dot"></span></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">More</div></div></div>
    <div class="grp right"><div class="ctl"><div class="ci"><span class="glyph end-glyph"><svg width="24" height="24" viewBox="0 0 24 24" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M17.1988 3H6.8012L1.60294 12L6.8012 21L17.1988 21L22.3971 12L17.1988 3ZM18.3059 1.9177C18.1566 1.65923 17.8807 1.5 17.5821 1.5H6.41787C6.11929 1.5 5.84339 1.65923 5.69409 1.9177L0.111969 11.5823C-0.0373232 11.8408 -0.0373227 12.1592 0.111969 12.4177L5.69409 22.0823C5.84339 22.3408 6.11929 22.5 6.41787 22.5L17.5821 22.5C17.8807 22.5 18.1566 22.3408 18.3059 22.0823L23.888 12.4177C24.0373 12.1592 24.0373 11.8408 23.888 11.5823L18.3059 1.9177Z" fill="#FF0055"/><path fill-rule="evenodd" clip-rule="evenodd" d="M15.9423 7.4572C15.5518 7.06668 14.9186 7.06668 14.5281 7.4572L12.0532 9.9321L9.57828 7.45721C9.18775 7.06669 8.55459 7.06669 8.16406 7.45721L7.45696 8.16432C7.06643 8.55484 7.06643 9.18801 7.45696 9.57853L9.93185 12.0534L7.457 14.5283C7.06648 14.9188 7.06648 15.552 7.457 15.9425L8.16411 16.6496C8.55463 17.0401 9.1878 17.0401 9.57832 16.6496L12.0532 14.1747L14.528 16.6496C14.9185 17.0401 15.5517 17.0401 15.9422 16.6496L16.6493 15.9425C17.0399 15.552 17.0399 14.9188 16.6493 14.5283L14.1745 12.0534L16.6494 9.57852C17.0399 9.188 17.0399 8.55483 16.6494 8.16431L15.9423 7.4572Z" fill="white" fill-opacity="0.4"/></svg></span><span class="caret"><svg width="10" height="10" viewBox="0 0 14 14" fill="none"><g opacity="0.5"><path fill-rule="evenodd" clip-rule="evenodd" d="M10.3389 8.9008C10.1299 9.10177 9.79753 9.09525 9.59656 8.88624L7 6.12982L4.40344 8.88625C4.20247 9.09525 3.87012 9.10177 3.66112 8.9008C3.45211 8.69983 3.4456 8.36749 3.64656 8.15848L6.62156 5.00848C6.72054 4.90554 6.85719 4.84736 7 4.84736C7.14281 4.84736 7.27945 4.90554 7.37844 5.00848L10.3534 8.15848C10.5544 8.36749 10.5479 8.69983 10.3389 8.9008Z" fill="#F7F9FA"/></g></svg></span></div><div class="cl">End</div></div></div>
  </div>
</div>`;
