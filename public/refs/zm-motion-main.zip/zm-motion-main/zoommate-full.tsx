/**
 * zoommate-full.tsx — the whole ZoomMate surface as a window: left rail, header
 * icons, title, composer, suggestion chips, and the agenda card running off the
 * bottom edge.
 *
 * The counterpart to `zoommate-simple`, which is the composer alone. Reach for
 * this when the story is about the product; reach for Simple when it is about
 * the prompt.
 *
 * THE FRAME. This is a window, 1213x833 in design units, and the content inside
 * it is deliberately taller than that. Two things follow, and both are the point
 * rather than side effects:
 *   • The rail runs the full height of the window and stops there — just below
 *     its last icon, the way a real app's rail meets the bottom of its frame.
 *   • The agenda card is cut off by the bottom edge. It is not a card that
 *     happens to be short; it is a longer card seen through a window, which is
 *     what makes the surface read as a product rather than a diagram.
 *
 * THE BEATS:
 *   • entrance  the surface assembles in staggered groups sliding in from the
 *               left: header icons, title, then composer and card together,
 *               then the chips one after another.
 *   • pan       the content glides up inside the window to reveal the rest of
 *               the card. The rail and header stay put, because they are chrome
 *               — in a real app the frame does not move when the content does.
 *
 * The pan distance defaults to exactly the content's overflow, so it comes to
 * rest with the card's end against the bottom edge rather than overshooting into
 * empty space.
 */
import type { CSSProperties, ReactNode } from "react";
import { Easing, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { ZOOMMATE_ICONS, type ZoomMateIconName } from "./zoommate-full-icons";

/** The window's own pixel dimensions; every layout number below is in these units. */
export const ZOOMMATE_FULL_NATIVE_WIDTH = 1213;
export const ZOOMMATE_FULL_NATIVE_HEIGHT = 833;
/** The content is taller than the window — that overflow is what the pan reveals. */
const CONTENT_HEIGHT = 1233;

const RAIL_WIDTH = 55;
const COLUMN_WIDTH = 600;

const ENTRANCE_EASE = Easing.bezier(0.25, 0.8, 0.13, 0.98);
const PAN_EASE = Easing.bezier(0.69, 0.0, 0.13, 0.98);
const ENTRANCE_SECONDS = 0.7;
const PAN_SECONDS = 1.1;

const FONT_STACK =
  '-apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Public Sans", "Liberation Sans", Arial, sans-serif';

const INK = "#202124";
const INK2 = "#3c4043";
const MUTED = "#80868b";
const LINE = "#eceef2";
const BLUE = "#2d72f6";

/** Rail icons and their y positions — six at the top, two pinned near the bottom. */
const RAIL_ITEMS: { icon: ZoomMateIconName; top: number; active?: boolean }[] = [
  { icon: "rail_panel", top: 12 },
  { icon: "rail_plus", top: 59, active: true },
  { icon: "rail_flow", top: 96 },
  { icon: "rail_docs", top: 132 },
  { icon: "rail_search", top: 168 },
  { icon: "rail_chat", top: 204 },
  { icon: "rail_puzzle", top: 753 },
  { icon: "rail_gear", top: 787 },
];

const HEADER_ITEMS: { icon: ZoomMateIconName; left: number }[] = [
  { icon: "header_compose", left: 1063 },
  { icon: "header_bell", left: 1099 },
  { icon: "header_apps", left: 1135 },
];

// ── Content ─────────────────────────────────────────────────────────────────────────

export interface ZoomMateChip {
  label: string;
  icon?: ZoomMateIconName;
  /** Renders the trailing chevron, for an overflow chip like "More". */
  chevron?: boolean;
}

export interface ZoomMateMeeting {
  title: string;
  /** e.g. "9:00 AM - 9:30 AM\u00a0\u00a0\u00a0Organizer: Kenji Park" */
  detail: string;
  /** Left accent: grey by default, green for live, dashed for tentative. */
  accent?: "grey" | "green" | "dashed";
  /** Marks it as happening now. */
  now?: boolean;
  /** Shows the recurring glyph beside the title. */
  recurring?: boolean;
  /** Trailing control: a "Review tasks" link, a blue Join button, or nothing. */
  action?: "review" | "join" | "none";
}

const DEFAULT_CHIPS: ZoomMateChip[] = [
  { label: "Drive meeting", icon: "chip_drive" },
  { label: "Build slides", icon: "chip_slides" },
  { label: "Draft document", icon: "chip_doc" },
  { label: "Create image", icon: "chip_image" },
  { label: "More", chevron: true },
];

const DEFAULT_MEETINGS: ZoomMateMeeting[] = [
  {
    title: "Omzo Health — Deal Team Sync",
    detail: "9:00 AM - 9:30 AM\u00a0\u00a0\u00a0Organizer: Kenji Park",
    action: "review",
  },
  {
    title: "Omzo Health QBR",
    detail: "10:30 AM - 12:00 PM\u00a0\u00a0\u00a0Organizer: Priya Anand",
    action: "review",
  },
  {
    title: "Weekly Product Standup",
    detail: "1:00 PM - 1:15 PM\u00a0\u00a0\u00a0Organizer: Marcus Webb",
    accent: "dashed",
    recurring: true,
    action: "none",
  },
  {
    title: "USAA — Customer Sync",
    detail: "2:00 PM - 2:30 PM\u00a0\u00a0\u00a0Organizer: Ellis Mercer",
    accent: "green",
    now: true,
    recurring: true,
    action: "join",
  },
  {
    title: "Northwind Health — Post-Outage Review",
    detail: "3:30 PM - 4:15 PM\u00a0\u00a0\u00a0Organizer: Sofia Duarte",
    action: "review",
  },
  {
    title: "Omzo Health — Contact Center Pilot",
    detail: "5:00 PM - 5:30 PM\u00a0\u00a0\u00a0Organizer: Nicole Lin",
    accent: "dashed",
    action: "none",
  },
];

// ── Timing ──────────────────────────────────────────────────────────────────────────

export interface ZoomMateFullSchedule {
  /** Frame the staggered entrance begins. Default 0. */
  entranceStartFrame?: number;
  /** Frames between each entrance group. Default 7. */
  staggerFrames?: number;
  /**
   * Frame the pan begins. Defaults to 0.7s after the last chip settles — the
   * surface needs a beat to read as assembled before it starts moving, or the
   * two moves blur into a single slide.
   */
  panStartFrame?: number;
  /**
   * How far the content travels upward, in design px. Defaults to exactly the
   * content's overflow, so it lands with the card's end against the bottom edge
   * instead of panning on into blank space.
   */
  panDistance?: number;
}

export interface ZoomMateFullBeats {
  entranceStart: number;
  /** The last chip has finished arriving. */
  entranceEnd: number;
  panStart: number;
  panEnd: number;
}

function resolve(schedule: ZoomMateFullSchedule, fps: number) {
  const {
    entranceStartFrame = 0,
    staggerFrames = 7,
    panStartFrame,
    panDistance = CONTENT_HEIGHT - ZOOMMATE_FULL_NATIVE_HEIGHT,
  } = schedule;
  const entranceDuration = ENTRANCE_SECONDS * fps;
  const entranceEnd = entranceStartFrame + 3 * staggerFrames + entranceDuration;
  return {
    entranceStartFrame,
    staggerFrames,
    entranceDuration,
    panDistance,
    panDuration: PAN_SECONDS * fps,
    entranceEnd,
    panStart: panStartFrame ?? Math.round(entranceEnd + 0.7 * fps),
  };
}

/** Every beat as a frame number. Needs fps: the motion is defined in seconds. */
export function zoomMateFullBeats(
  schedule: ZoomMateFullSchedule = {},
  fps = 30,
): ZoomMateFullBeats {
  const r = resolve(schedule, fps);
  return {
    entranceStart: r.entranceStartFrame,
    entranceEnd: Math.ceil(r.entranceEnd),
    panStart: r.panStart,
    panEnd: Math.ceil(r.panStart + r.panDuration),
  };
}

/** Total frames the sequence occupies, ending as the pan lands. */
export function zoomMateFullDuration(
  schedule: ZoomMateFullSchedule = {},
  fps = 30,
): number {
  return zoomMateFullBeats(schedule, fps).panEnd + 1;
}

// ── Component ───────────────────────────────────────────────────────────────────────

export interface ZoomMateFullProps {
  /** Title above the composer. Default "ZoomMate is ready to help". */
  title?: string;
  /** Line of context above the agenda list. */
  description?: string;
  /** Date row label. Default "Today, Aug 13". */
  dateLabel?: string;
  /** Right-hand summary on the date row. Default "6 meetings, 4h total". */
  summary?: string;
  /** Quick-action chips under the composer. */
  chips?: ZoomMateChip[];
  /** Rows in the agenda card. */
  meetings?: ZoomMateMeeting[];
  /** Tab labels. Default ["Agenda", "Suggestions"]. */
  tabs?: [string, string];
  /** Index of the active tab. Default 0. */
  activeTab?: number;
  /**
   * Window width in composition px; height follows the design's 1213:833 ratio.
   * Defaults to the largest size that fits the composition with a 10% margin.
   */
  width?: number;
  /** Show the left rail and header icons. Default true. */
  showChrome?: boolean;
  /** How far each entrance group travels, in design px. Default 90. */
  distance?: number;
  /** Rounded corners on the window, in design px. Default 0 — a flush frame. */
  cornerRadius?: number;
  schedule?: ZoomMateFullSchedule;
  style?: CSSProperties;
}

export function ZoomMateFull({
  title = "ZoomMate is ready to help",
  description = "Review Omzo Health's three open pricing questions before the 10:30 AM QBR.",
  dateLabel = "Today, Aug 13",
  summary = "6 meetings, 4h total",
  chips = DEFAULT_CHIPS,
  meetings = DEFAULT_MEETINGS,
  tabs = ["Agenda", "Suggestions"],
  activeTab = 0,
  width,
  showChrome = true,
  distance = 90,
  cornerRadius = 0,
  schedule = {},
  style,
}: ZoomMateFullProps) {
  const frame = useCurrentFrame();
  const { fps, width: compositionWidth, height: compositionHeight } = useVideoConfig();
  const r = resolve(schedule, fps);

  // Fit to whichever dimension binds. The window is 1213x833 — wider than 16:9 —
  // so sizing off the composition width alone overflows a 1080-tall frame and
  // silently crops the rail's bottom icons, which is exactly what we are here to
  // keep visible.
  const aspect = ZOOMMATE_FULL_NATIVE_WIDTH / ZOOMMATE_FULL_NATIVE_HEIGHT;
  const renderedWidth =
    width ?? Math.min(compositionWidth * 0.9, compositionHeight * 0.9 * aspect);
  const scale = renderedWidth / ZOOMMATE_FULL_NATIVE_WIDTH;
  const renderedHeight = renderedWidth / aspect;

  const panProgress = interpolate(
    frame,
    [r.panStart, r.panStart + r.panDuration],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: PAN_EASE },
  );
  const panY = -r.panDistance * panProgress;

  /** Entrance transform for a group, by its slot in the stagger. */
  const enter = (slot: number): CSSProperties => {
    const start = r.entranceStartFrame + slot * r.staggerFrames;
    const p = interpolate(frame, [start, start + r.entranceDuration], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
      easing: ENTRANCE_EASE,
    });
    return { opacity: p, transform: `translateX(${(1 - p) * -distance}px)` };
  };

  return (
    <div
      style={{
        position: "absolute",
        left: `calc(50% - ${renderedWidth / 2}px)`,
        top: `calc(50% - ${renderedHeight / 2}px)`,
        width: ZOOMMATE_FULL_NATIVE_WIDTH,
        height: ZOOMMATE_FULL_NATIVE_HEIGHT,
        transform: `scale(${scale})`,
        transformOrigin: "top left",
        // The window edge. Everything inside is clipped by it — the card runs
        // past the bottom on purpose.
        overflow: "hidden",
        borderRadius: cornerRadius,
        background:
          "radial-gradient(46% 44% at 40% 33%, rgba(158,190,240,.52) 0%, rgba(158,190,240,0) 100%), #ffffff",
        fontFamily: FONT_STACK,
        ...style,
      }}
    >
      {/* Chrome: rail and header. Fixed — a window frame does not travel with
          its content, which is why the pan below moves only the content layer. */}
      {showChrome && (
        <>
          <div
            style={{
              position: "absolute",
              left: 0,
              top: 0,
              width: RAIL_WIDTH,
              height: ZOOMMATE_FULL_NATIVE_HEIGHT,
              borderRight: "1px solid #EBEBEB",
              background: "#ffffff",
              boxSizing: "border-box",
              zIndex: 60,
            }}
          >
            {RAIL_ITEMS.map((item) => (
              <div
                key={item.icon}
                style={{
                  position: "absolute",
                  left: 11,
                  top: item.top,
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "#1A1A1A",
                  background: item.active ? "#EFEFEF" : "transparent",
                }}
              >
                <Icon name={item.icon} size={20} />
              </div>
            ))}
          </div>

          {HEADER_ITEMS.map((item) => (
            <div
              key={item.icon}
              style={{
                position: "absolute",
                top: 22,
                left: item.left,
                width: 16,
                height: 16,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#5E5E5E",
                zIndex: 60,
                ...enter(0),
              }}
            >
              <Icon name={item.icon} size={16} />
            </div>
          ))}
          <div
            style={{
              position: "absolute",
              top: 14,
              left: 1171,
              width: 32,
              height: 32,
              borderRadius: 9,
              background: "#0B0B0D",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              overflow: "hidden",
              color: "#3A3A3F",
              zIndex: 60,
              ...enter(0),
            }}
          >
            <Icon name="header_avatar" size={32} />
          </div>
        </>
      )}

      {/* Content — the layer that pans. Taller than the window by design. */}
      <div
        style={{
          position: "absolute",
          left: showChrome ? RAIL_WIDTH + 1 : 0,
          top: 0,
          right: 0,
          height: CONTENT_HEIGHT,
          transform: `translateY(${panY}px)`,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
        }}
      >
        <div
          style={{
            marginTop: 176,
            fontSize: 26,
            lineHeight: "32px",
            fontWeight: 400,
            color: INK,
            letterSpacing: "-0.3px",
            ...enter(1),
          }}
        >
          {title}
        </div>

        <div style={{ width: COLUMN_WIDTH, marginTop: 32, ...enter(2) }}>
          <div
            style={{
              width: COLUMN_WIDTH,
              height: 54,
              background: "#fff",
              border: "1px solid #e6e6ec",
              borderRadius: 27,
              display: "flex",
              alignItems: "center",
              padding: "0 10px",
              boxSizing: "border-box",
              boxShadow: "0 2px 6px rgba(20,30,80,.05)",
            }}
          >
            <span
              style={{
                width: 32,
                height: 32,
                borderRadius: "50%",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                color: "#5f6368",
                flex: "none",
              }}
            >
              <Icon name="input_plus" size={20} />
            </span>
            {/* Blink is driven off the frame, not a CSS animation — a renderer
                screenshots each frame independently and never sees CSS keyframes
                advance, so an animated caret would freeze at one phase. */}
            <span
              style={{
                width: 1.5,
                height: 20,
                background: INK2,
                marginLeft: 4,
                opacity: Math.floor(frame / fps / 0.55) % 2 === 0 ? 1 : 0,
              }}
            />
            <span
              style={{
                marginLeft: "auto",
                width: 34,
                height: 34,
                borderRadius: "50%",
                background:
                  "radial-gradient(circle at 20% 80%,#528fff 20%,#76b5ffe0,#99daffc2 90%)",
                color: "#fff",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                flex: "none",
              }}
            >
              <Icon name="input_mic" size={18} />
            </span>
          </div>
        </div>

        <div style={{ marginTop: 28, display: "flex", alignItems: "center", gap: 10 }}>
          {chips.map((chip, i) => (
            <span
              key={chip.label}
              style={{
                height: 36,
                display: "flex",
                alignItems: "center",
                gap: 8,
                padding: "0 15px",
                background: "#fff",
                border: "1px solid #e6e6ec",
                borderRadius: 19,
                fontSize: 14,
                color: INK2,
                whiteSpace: "nowrap",
                boxSizing: "border-box",
                // Chips cascade at half the group spacing, so the row reads as
                // one gesture rather than several separate arrivals.
                ...enter(3 + i * 0.5),
              }}
            >
              {chip.icon && <Icon name={chip.icon} size={16} />}
              {chip.label}
              {chip.chevron && (
                <span style={{ marginLeft: 1, color: "#5f6368", display: "flex" }}>
                  <Icon name="chip_more_chevron" size={16} />
                </span>
              )}
            </span>
          ))}
        </div>

        <div style={{ marginTop: "auto", width: COLUMN_WIDTH, ...enter(2) }}>
          <div style={{ display: "flex", alignItems: "flex-start", height: 40 }}>
            {tabs.map((label, i) => (
              <span
                key={label}
                style={{
                  position: "relative",
                  height: 55,
                  padding: "12px 24px 0",
                  flex: "none",
                  fontSize: 13,
                  fontWeight: 500,
                  lineHeight: "16px",
                  color: i === activeTab ? BLUE : MUTED,
                  background: i === activeTab ? "#ffffff" : "#f1f3f5",
                  border: `1px solid ${LINE}`,
                  borderRadius: 16,
                  boxSizing: "border-box",
                  marginLeft: i === 0 ? 0 : -11,
                  zIndex: i === activeTab ? 20 : 10,
                }}
              >
                {label}
              </span>
            ))}
          </div>
          <div
            style={{
              width: COLUMN_WIDTH,
              background: "#fff",
              border: `1px solid ${LINE}`,
              borderRadius: "0 16px 16px 16px",
              position: "relative",
              zIndex: 15,
              boxSizing: "border-box",
            }}
          >
            {/* Fixed height, as in the design. Without it the card shrink-wraps
                its rows, which pushes it down the column and leaves only a sliver
                showing above the window's edge instead of a proper cut-off. */}
            <div style={{ padding: 16, height: 706, overflow: "hidden", boxSizing: "border-box" }}>
              <div style={{ fontSize: 14, color: INK2, lineHeight: "18px", padding: 8 }}>
                {description}
              </div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  marginTop: 8,
                  padding: "4px 8px",
                  fontSize: 12,
                  lineHeight: "16px",
                  color: INK,
                }}
              >
                <span
                  style={{ display: "flex", alignItems: "center", gap: 4, fontWeight: 600 }}
                >
                  {dateLabel}
                  <Icon name="card_chevron" size={14} />
                </span>
                <span style={{ marginLeft: "auto", color: INK2, fontWeight: 600 }}>
                  {summary}
                </span>
              </div>
              {meetings.map((m) => (
                <MeetingRow key={m.title} meeting={m} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function MeetingRow({ meeting }: { meeting: ZoomMateMeeting }) {
  const { accent = "grey", action = "review" } = meeting;
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        padding: 8,
        borderRadius: 12,
      }}
    >
      <div
        style={{
          width: 4,
          height: 42,
          borderRadius: 2,
          flex: "none",
          // A dashed bar is a repeating gradient: border-style cannot dash a
          // 4px-wide block cleanly at this size.
          background:
            accent === "dashed"
              ? "repeating-linear-gradient(#34a853 0 5px, transparent 5px 9px)"
              : accent === "green"
              ? "#34a853"
              : "#c5cbd6",
        }}
      />
      <div style={{ flex: 1, minWidth: 0 }}>
        <div
          style={{
            fontSize: 14,
            lineHeight: "20px",
            color: INK,
            fontWeight: 600,
            display: "flex",
            alignItems: "center",
            gap: 9,
          }}
        >
          {meeting.title}
          {meeting.recurring && (
            <span style={{ color: "#e8467c", display: "flex" }}>
              <Icon name="card_recurring" size={14} />
            </span>
          )}
          {meeting.now && (
            <span
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 4,
                background: "#fde8ee",
                color: "#d6336c",
                fontSize: 11,
                fontWeight: 600,
                padding: "2px 8px",
                borderRadius: 11,
              }}
            >
              Now
            </span>
          )}
        </div>
        <div style={{ fontSize: 12, lineHeight: "16px", color: MUTED, marginTop: 2 }}>
          {meeting.detail}
        </div>
      </div>
      {action === "review" && (
        <span
          style={{
            color: BLUE,
            fontSize: 14,
            whiteSpace: "nowrap",
            height: 32,
            display: "inline-flex",
            alignItems: "center",
            padding: "0 12px",
            borderRadius: 6,
          }}
        >
          Review tasks
        </span>
      )}
      {action === "join" && (
        <span
          style={{
            background: BLUE,
            color: "#fff",
            borderRadius: 9,
            padding: "8px 15px",
            fontSize: 13.5,
            fontWeight: 500,
            display: "flex",
            alignItems: "center",
            gap: 7,
            whiteSpace: "nowrap",
          }}
        >
          <Icon name="card_join" size={16} />
          Join
        </span>
      )}
    </div>
  );
}

/**
 * Renders one icon. The stored markup is a complete <svg> sized to 100%, so the
 * span here is what decides how big it is and what colour it inherits.
 *
 * `dangerouslySetInnerHTML` is the pragmatic choice: this markup is a
 * build-time constant from our own design file, never user input, and inlining
 * it keeps the icons byte-identical to the source rather than redrawn by hand.
 */
function Icon({
  name,
  size,
  style,
}: {
  name: ZoomMateIconName;
  size: number;
  style?: CSSProperties;
}): ReactNode {
  return (
    <span
      style={{
        width: size,
        height: size,
        flex: "none",
        display: "block",
        lineHeight: 0,
        ...style,
      }}
      dangerouslySetInnerHTML={{ __html: ZOOMMATE_ICONS[name] }}
    />
  );
}
