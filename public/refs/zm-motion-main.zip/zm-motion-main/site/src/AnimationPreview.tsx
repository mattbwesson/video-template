import React, {useEffect, useRef, useState} from 'react';
import {Player, type PlayerRef} from '@remotion/player';
import type {AnimationEntry} from './registry';

// Which static backdrop image (if any) sits behind a preset. Text, UI, and transition
// presets render smaller content over an empty frame, so they read against the primary
// backdrop; scenes read against the secondary (slightly deeper) backdrop, so mockups
// (chat apps, forms) read as their own "device" on a stage. Backgrounds & Effects
// presets ARE the backdrop, so they get none. An entry with its own explicit
// `background` (e.g. the iMessage flow's light phone-screen backdrop) is a deliberate
// override — skip the image there so it isn't painted over. An entry can also pin a
// specific `backdrop: 1 | 2`, overriding the category default (e.g. whip-pan and
// push-through each get a different one of the two images, for variety).
function backdropSrcFor(entry: AnimationEntry): string | null {
  if (entry.background) return null;
  if (entry.backdrop === 1) return BACKDROP_SRC;
  if (entry.backdrop === 2) return BACKDROP_SRC_2;
  if (entry.category === 'text' || entry.category === 'ui' || entry.category === 'transition') {
    return BACKDROP_SRC;
  }
  if (entry.category === 'scene') return BACKDROP_SRC_2;
  return null;
}

const BACKDROP_SRC = '/preview-bg.jpg';
const BACKDROP_SRC_2 = '/preview-bg-2.jpg';

// A single preview. The Remotion <Player> mounts once the card nears the viewport
// (keeps dozens of players from booting at once). Default: paused on a poster
// frame, plays on hover. `autoPlay`: plays on mount and loops (hero showcase).
// A static backdrop image sits behind the animation at all times (not just on hover).
export function AnimationPreview({
  entry,
  autoPlay = false,
  className,
}: {
  entry: AnimationEntry;
  autoPlay?: boolean;
  className?: string;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const playerRef = useRef<PlayerRef>(null);
  const [mounted, setMounted] = useState(false);

  const fps = entry.fps ?? 30;
  const duration = Math.max(1, entry.durationInFrames ?? 90);
  const posterFrame = Math.min(
    duration - 1,
    entry.posterFrame ?? Math.floor(duration * 0.55),
  );

  const backdropSrc = backdropSrcFor(entry);
  const isHappy = entry.category === 'text' || entry.category === 'transition';

  // Mount the player when the card is near the viewport.
  useEffect(() => {
    const el = containerRef.current;
    if (!el || mounted) return;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setMounted(true);
          io.disconnect();
        }
      },
      {rootMargin: autoPlay ? '600px' : '300px'},
    );
    io.observe(el);
    return () => io.disconnect();
  }, [mounted, autoPlay]);

  const handleEnter = () => {
    if (autoPlay) return;
    const p = playerRef.current;
    if (!p) return;
    p.seekTo(0);
    p.play();
  };

  const handleLeave = () => {
    if (autoPlay) return;
    const p = playerRef.current;
    if (!p) return;
    p.pause();
    p.seekTo(posterFrame);
  };

  const classes = ['zm-preview', isHappy ? 'is-happy' : '', className ?? '']
    .filter(Boolean)
    .join(' ');

  return (
    <div
      ref={containerRef}
      className={classes}
      style={entry.background ? {background: entry.background} : undefined}
      onMouseEnter={handleEnter}
      onMouseLeave={handleLeave}
    >
      {backdropSrc ? <img className="zm-preview__bg" src={backdropSrc} alt="" /> : null}
      {mounted ? (
        <Player
          ref={playerRef}
          className="zm-preview__player"
          component={entry.component}
          inputProps={entry.inputProps ?? {}}
          durationInFrames={duration}
          fps={fps}
          compositionWidth={entry.width ?? 1280}
          compositionHeight={entry.height ?? 720}
          initialFrame={autoPlay ? 0 : posterFrame}
          autoPlay={autoPlay}
          loop
          controls={false}
          clickToPlay={false}
          doubleClickToFullscreen={false}
          spaceKeyToPlayOrPause={false}
          showVolumeControls={false}
          initiallyMuted
          numberOfSharedAudioTags={0}
          style={{width: '100%', height: '100%', background: 'transparent'}}
          errorFallback={() => <PreviewFailed name={entry.name} />}
          renderLoading={() => <div className="zm-preview__error">…</div>}
        />
      ) : null}
    </div>
  );
}

function PreviewFailed({name}: {name: string}) {
  return (
    <div className="zm-preview__error">
      preview unavailable
      <span style={{display: 'none'}}>{name}</span>
    </div>
  );
}
