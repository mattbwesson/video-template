// Object layout editor — drop shapes onto a screenshot of the frame you're
// working in, drag them exactly where you want them, then copy a prompt that
// states those positions precisely enough to rebuild.
//
// THE COORDINATE MODEL (one definition, used by the preview and the prompt
// alike, so the two can never disagree):
//
//   frame  = the positioning context: position: relative, 16:9
//   object = position: absolute, placed by its CENTRE
//            left: x%  top: y%            (% of frame width / height)
//            width: w%  height: h%        (% of frame width / height)
//            transform: translate(-50%, -50%) rotate(r deg)
//
// Percentages everywhere, never pixels, so a layout authored here holds at any
// frame size. The two things that genuinely can't be percentages — corner radius
// and font size — are quoted in px against a stated 1920x1080 reference frame,
// which is the convention a designer would hand over anyway.
//
// Positioning by CENTRE rather than by top-left is deliberate: "centred at 50%"
// is a fact you can state and check, whereas "left: 41%" is a number nobody can
// verify by eye.
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {PAGE_H, PAGE_W} from './zoomProfileScene';
import {
  Scene,
  SceneSprite,
  ShotSourceBar,
  regionUnder,
  useShot,
  type Rect,
} from './scene';

type Kind = 'rect' | 'circle' | 'pill' | 'text' | 'image';
type Obj = {
  id: number;
  kind: Kind;
  name: string;
  x: number; // centre, % of frame width
  y: number; // centre, % of frame height
  w: number; // % of frame width
  h: number; // % of frame height
  rotate: number; // degrees
  radius: number; // px at the 1920-wide reference frame; ignored by circle/pill
  color: string;
  text: string;
};

const ACCENT = '#c9f24d';
/** The reference frame radius and font size are quoted against. */
const REF_W = 1920;
const REF_H = 1080;
const FRAME_ASPECT = 16 / 9;
/** How close (in % of the frame) an edge or centre has to be before it snaps. */
const SNAP = 0.9;
const MAX_OBJECTS = 8;

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const round = (v: number, dp: number) => Number(v.toFixed(dp));
/** Height, in % of frame height, that renders square against a width in % of frame width. */
const squareH = (w: number) => w * FRAME_ASPECT;

const SWATCHES = ['#c9f24d', '#ffffff', '#0b5cff', '#f43f5e', '#22d3ee', '#12121a'];

const KINDS: {kind: Kind; label: string; make: (id: number) => Obj}[] = [
  {
    kind: 'rect',
    label: 'Rectangle',
    make: (id) => base(id, 'rect', 'Panel', {w: 26, h: 22, radius: 0}),
  },
  {
    kind: 'pill',
    label: 'Pill',
    make: (id) => base(id, 'pill', 'Badge', {w: 14, h: 7, text: 'New'}),
  },
  {
    kind: 'circle',
    label: 'Circle',
    make: (id) => base(id, 'circle', 'Dot', {w: 8, h: squareH(8)}),
  },
  {
    kind: 'text',
    label: 'Text',
    // Ink, not white: most screenshots people bring are light, and a white
    // default lands invisible on them.
    make: (id) => base(id, 'text', 'Caption', {w: 40, h: 8, text: 'Your text here', color: '#12121a'}),
  },
  {
    kind: 'image',
    label: 'Image slot',
    make: (id) => base(id, 'image', 'Image', {w: 24, h: 30, radius: 24}),
  },
];

function base(id: number, kind: Kind, name: string, patch: Partial<Obj> = {}): Obj {
  return {
    id,
    kind,
    name,
    x: 50,
    y: 50,
    w: 20,
    h: 16,
    rotate: 0,
    radius: 16,
    color: ACCENT,
    text: '',
    ...patch,
  };
}

/* --------------------------------------------------------------- geometry */

const leftOf = (o: Obj) => o.x - o.w / 2;
const topOf = (o: Obj) => o.y - o.h / 2;
const rectOf = (o: Obj): Rect => [leftOf(o) / 100, topOf(o) / 100, (o.x + o.w / 2) / 100, (o.y + o.h / 2) / 100];

/** Radius/size in px, mapped from the reference frame onto the live frame. */
const refPx = (v: number, framePx: number, refPx_: number) => (v / refPx_) * framePx;

/**
 * Snap one axis. Every edge and centre of the moving object is tested against
 * every candidate line, and the smallest correction inside the threshold wins —
 * so an object snaps by whichever of its own edges happens to be closest, not
 * only by its centre.
 */
function snapAxis(
  centre: number,
  size: number,
  lines: number[],
): {value: number; guide: number | null} {
  const anchors = [centre - size / 2, centre, centre + size / 2];
  let best: {delta: number; guide: number} | null = null;
  for (const a of anchors) {
    for (const l of lines) {
      const d = l - a;
      if (Math.abs(d) <= SNAP && (!best || Math.abs(d) < Math.abs(best.delta))) {
        best = {delta: d, guide: l};
      }
    }
  }
  return best ? {value: centre + best.delta, guide: best.guide} : {value: centre, guide: null};
}

/** Frame edges and centre, plus every other object's edges and centre. */
function snapLines(objs: Obj[], skipId: number) {
  const xs = [0, 50, 100];
  const ys = [0, 50, 100];
  for (const o of objs) {
    if (o.id === skipId) continue;
    xs.push(leftOf(o), o.x, o.x + o.w / 2);
    ys.push(topOf(o), o.y, o.y + o.h / 2);
  }
  return {xs, ys};
}

/* ------------------------------------------------------------------ prose */

const near = (a: number, b: number) => Math.abs(a - b) < 0.15;

/** The alignments worth stating outright, because they're intent, not numbers. */
function alignmentNotes(o: Obj): string[] {
  const notes: string[] = [];
  if (near(o.x, 50) && near(o.y, 50)) notes.push('dead centre of the frame');
  else {
    if (near(o.x, 50)) notes.push('horizontally centred');
    if (near(o.y, 50)) notes.push('vertically centred');
  }
  if (near(leftOf(o), 0)) notes.push('flush with the left edge');
  if (near(o.x + o.w / 2, 100)) notes.push('flush with the right edge');
  if (near(topOf(o), 0)) notes.push('flush with the top edge');
  if (near(o.y + o.h / 2, 100)) notes.push('flush with the bottom edge');
  return notes;
}

/** Rough position in words, for a backdrop the tool can't read. */
function positionWords(o: Obj): string {
  const row = o.y < 40 ? 'upper' : o.y > 60 ? 'lower' : '';
  const col = o.x < 40 ? 'left' : o.x > 60 ? 'right' : '';
  return [row, col].filter(Boolean).join(' ') || 'centre';
}

function describeObject(o: Obj, i: number, hasShot: boolean): string[] {
  const kind = KINDS.find((k) => k.kind === o.kind)!.label.toLowerCase();
  const head = `  ${i + 1}. "${o.name}" — ${kind} · ${o.w.toFixed(1)}% x ${o.h.toFixed(
    1,
  )}% · centre (${o.x.toFixed(1)}%, ${o.y.toFixed(1)}%)`;

  const bits: string[] = [];
  const over = hasShot ? null : regionUnder(rectOf(o));
  bits.push(over ? `over the ${over.toLowerCase()}` : `${positionWords(o)} of the frame`);
  bits.push(...alignmentNotes(o));
  if (o.rotate) bits.push(`rotated ${round(o.rotate, 1)}deg`);
  if (o.kind === 'text') {
    bits.push(`text "${o.text}"`, `${round(refPx(o.h, REF_H, 100), 0)}px type`, `colour ${o.color}`);
  } else if (o.kind === 'image') {
    bits.push('image placeholder', `radius ${round(o.radius, 0)}px`);
  } else {
    bits.push(`fill ${o.color}`);
    if (o.kind === 'pill') bits.push('fully rounded ends');
    else if (o.kind === 'circle') bits.push('circle');
    else if (o.radius) bits.push(`radius ${round(o.radius, 0)}px`);
    if (o.text) bits.push(`label "${o.text}"`);
  }
  return [head, `       ${bits.join(' · ')}`];
}

const slug = (s: string, i: number) =>
  s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '') || `obj-${i + 1}`;

function cssFor(objs: Obj[]): string {
  const L: string[] = [
    '.frame {',
    '  position: relative;',
    '  aspect-ratio: 16 / 9;',
    '  overflow: hidden;',
    '}',
  ];
  objs.forEach((o, i) => {
    const name = slug(o.name, i);
    L.push('');
    // The content rides in the comment so the rule is self-describing when it's
    // pasted somewhere the OBJECTS list above didn't follow.
    const content = o.text ? ` · ${o.kind === 'text' ? 'text' : 'label'} "${o.text}"` : '';
    L.push(`/* ${i + 1} — ${o.name}${content} */`);
    L.push(`.${name} {`);
    L.push('  position: absolute;');
    L.push(`  left: ${round(o.x, 2)}%;`);
    L.push(`  top: ${round(o.y, 2)}%;`);
    L.push(`  width: ${round(o.w, 2)}%;`);
    L.push(`  height: ${round(o.h, 2)}%;`);
    L.push(
      `  transform: translate(-50%, -50%)${o.rotate ? ` rotate(${round(o.rotate, 1)}deg)` : ''};`,
    );
    if (o.kind === 'circle') L.push('  border-radius: 50%;');
    else if (o.kind === 'pill') L.push('  border-radius: 999px;');
    // Only the kinds that actually paint a box carry a radius — a rounded
    // corner on a text object is noise the reader has to decide to ignore.
    else if (o.radius && (o.kind === 'rect' || o.kind === 'image')) {
      L.push(`  border-radius: ${round(o.radius, 0)}px;`);
    }
    if (o.kind === 'text') {
      L.push(`  color: ${o.color};`);
      L.push(`  font-size: ${round(refPx(o.h, REF_H, 100), 0)}px;`);
      L.push('  line-height: 1;');
      L.push('  display: flex;');
      L.push('  align-items: center;');
      L.push('  justify-content: center;');
    } else if (o.kind === 'image') {
      L.push('  background: #d9d9e0;');
    } else {
      L.push(`  background: ${o.color};`);
    }
    L.push('}');
  });
  return L.join('\n');
}

function buildPrompt(objs: Obj[], hasShot: boolean): string {
  const L: string[] = [];
  L.push(`OBJECT LAYOUT — ${objs.length} object${objs.length === 1 ? '' : 's'} on a 16:9 frame`);
  if (hasShot) L.push('Authored on top of a screenshot of the frame these sit in.');
  L.push('');
  L.push('COORDINATE MODEL');
  L.push('  The frame is the positioning context: position: relative, aspect-ratio: 16/9.');
  L.push('  Every object is placed by its CENTRE, in percentages of the frame — never pixels,');
  L.push('  so the layout holds at any frame size:');
  L.push('');
  L.push('    position: absolute;');
  L.push('    left: <x>%;   top: <y>%;      /* the object\'s CENTRE, not its corner */');
  L.push('    width: <w>%;  height: <h>%;   /* % of frame width / height */');
  L.push('    transform: translate(-50%, -50%) rotate(<r>deg);');
  L.push('');
  L.push(`  Corner radius and type size are px against a ${REF_W}x${REF_H} reference frame —`);
  L.push('  scale them with the frame if you render at another size.');
  L.push('  Objects are listed back to front: later entries paint on top of earlier ones.');
  L.push('  Where a note says an object is centred or flush with an edge, that is the intent;');
  L.push('  honour it exactly rather than reproducing the rounded percentage.');
  L.push('');
  L.push('OBJECTS');
  objs.forEach((o, i) => L.push(...describeObject(o, i, hasShot)));
  L.push('');
  L.push('CSS — the same layout, unambiguously');
  L.push(
    cssFor(objs)
      .split('\n')
      .map((l) => `  ${l}`)
      .join('\n'),
  );
  return L.join('\n');
}

/* ------------------------------------------------------------------ stage */

function ObjectBox({
  o,
  frame,
  selected,
  onPointerDown,
  onHandleDown,
}: {
  o: Obj;
  frame: {w: number; h: number};
  selected: boolean;
  onPointerDown: (e: React.PointerEvent | React.MouseEvent) => void;
  onHandleDown: (e: React.PointerEvent | React.MouseEvent) => void;
}) {
  const style: React.CSSProperties = {
    left: `${o.x}%`,
    top: `${o.y}%`,
    width: `${o.w}%`,
    height: `${o.h}%`,
    transform: `translate(-50%, -50%) rotate(${o.rotate}deg)`,
  };
  if (o.kind === 'circle') style.borderRadius = '50%';
  else if (o.kind === 'pill') style.borderRadius = 999;
  else if (o.radius) style.borderRadius = refPx(o.radius, frame.w, REF_W);

  if (o.kind === 'text') {
    style.color = o.color;
    style.fontSize = refPx(refPx(o.h, REF_H, 100), frame.h, REF_H);
  } else if (o.kind !== 'image') {
    style.background = o.color;
  }

  return (
    <div
      className={`zm-obj zm-obj--${o.kind}${selected ? ' is-selected' : ''}`}
      style={style}
      onPointerDown={onPointerDown}
      onMouseDown={onPointerDown}
    >
      {o.kind === 'text' ? <span className="zm-obj__text">{o.text}</span> : null}
      {o.kind !== 'text' && o.text ? <span className="zm-obj__label">{o.text}</span> : null}
      {selected ? (
        <span
          className="zm-obj__handle"
          onPointerDown={onHandleDown}
          onMouseDown={onHandleDown}
        />
      ) : null}
    </div>
  );
}

/* ----------------------------------------------------------------- editor */

function Slider({
  label,
  value,
  min,
  max,
  step,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix: string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="zm-cam-slider">
      <span className="zm-cam-slider__label">{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="zm-ease-slider"
      />
      <span className="zm-cam-slider__value">
        {value.toFixed(step < 1 ? 1 : 0)}
        {suffix}
      </span>
    </div>
  );
}

export function ObjectEditor() {
  const {shot, loadShot, clearShot} = useShot();
  const [objs, setObjs] = useState<Obj[]>(() => [KINDS[1].make(0)]);
  const [selectedId, setSelectedId] = useState<number | null>(0);
  const [copied, setCopied] = useState(false);
  const [guides, setGuides] = useState<{x: number | null; y: number | null}>({x: null, y: null});
  const [dropping, setDropping] = useState(false);
  const [frame, setFrame] = useState({w: 960, h: 540});

  const frameRef = useRef<HTMLDivElement>(null);
  // Live drag state. Kept in a ref so the window listeners never restart
  // mid-drag, which would drop the gesture the moment React re-rendered.
  const drag = useRef<{
    mode: 'move' | 'resize';
    id: number;
    px: number;
    py: number;
    start: Obj;
  } | null>(null);
  const objsRef = useRef(objs);
  objsRef.current = objs;

  const selected = objs.find((o) => o.id === selectedId) ?? null;
  const output = useMemo(() => buildPrompt(objs, !!shot), [objs, shot]);

  useEffect(() => {
    const el = frameRef.current;
    if (!el) return;
    const sync = () => {
      const r = el.getBoundingClientRect();
      setFrame({w: r.width, h: r.height});
    };
    sync();
    const ro = new ResizeObserver(sync);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const patch = useCallback((id: number, p: Partial<Obj>) => {
    setObjs((os) => os.map((o) => (o.id === id ? {...o, ...p} : o)));
  }, []);

  const patchSelected = useCallback(
    (p: Partial<Obj>) => {
      if (selectedId == null) return;
      patch(selectedId, p);
    },
    [patch, selectedId],
  );

  // One set of window listeners for the whole drag lifetime, pointer and mouse
  // both — some environments only dispatch one family.
  useEffect(() => {
    const move = (e: PointerEvent | MouseEvent) => {
      const d = drag.current;
      const el = frameRef.current;
      if (!d || !el) return;
      const r = el.getBoundingClientRect();
      const dx = ((e.clientX - d.px) / r.width) * 100;
      const dy = ((e.clientY - d.py) / r.height) * 100;

      if (d.mode === 'move') {
        const lines = snapLines(objsRef.current, d.id);
        const sx = snapAxis(d.start.x + dx, d.start.w, lines.xs);
        const sy = snapAxis(d.start.y + dy, d.start.h, lines.ys);
        setGuides({x: sx.guide, y: sy.guide});
        patch(d.id, {x: round(sx.value, 2), y: round(sy.value, 2)});
      } else {
        // Proportional about the top-left corner: the anchor stays put, so the
        // corner you're holding is the one that follows the cursor.
        const factor = Math.max(0.02, (d.start.w + dx) / d.start.w);
        const w = clamp(d.start.w * factor, 1, 200);
        const h = clamp(d.start.h * factor, 1, 200);
        patch(d.id, {
          w: round(w, 2),
          h: round(h, 2),
          x: round(d.start.x - d.start.w / 2 + w / 2, 2),
          y: round(d.start.y - d.start.h / 2 + h / 2, 2),
        });
      }
    };
    const up = () => {
      drag.current = null;
      setGuides({x: null, y: null});
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    window.addEventListener('pointercancel', up);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [patch]);

  const startDrag =
    (o: Obj, mode: 'move' | 'resize') => (e: React.PointerEvent | React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setSelectedId(o.id);
      drag.current = {mode, id: o.id, px: e.clientX, py: e.clientY, start: o};
    };

  // Wheel over the frame scales the selected object about its own centre.
  useEffect(() => {
    const el = frameRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      const o = objsRef.current.find((x) => x.id === selectedId);
      if (!o) return;
      e.preventDefault();
      const f = Math.exp(-e.deltaY / 500);
      patch(o.id, {w: round(clamp(o.w * f, 1, 200), 2), h: round(clamp(o.h * f, 1, 200), 2)});
    };
    el.addEventListener('wheel', onWheel, {passive: false});
    return () => el.removeEventListener('wheel', onWheel);
  }, [patch, selectedId]);

  // Arrow keys nudge; 0.1% with shift, for the last bit of placement.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const el = document.activeElement;
      if (el && /^(INPUT|TEXTAREA)$/.test(el.tagName)) return;
      const o = objsRef.current.find((x) => x.id === selectedId);
      if (!o) return;
      const step = e.shiftKey ? 0.1 : 1;
      const map: Record<string, [number, number]> = {
        ArrowLeft: [-step, 0],
        ArrowRight: [step, 0],
        ArrowUp: [0, -step],
        ArrowDown: [0, step],
      };
      const d = map[e.key];
      if (d) {
        e.preventDefault();
        patch(o.id, {x: round(o.x + d[0], 2), y: round(o.y + d[1], 2)});
      } else if (e.key === 'Backspace' || e.key === 'Delete') {
        e.preventDefault();
        setObjs((os) => os.filter((x) => x.id !== o.id));
        setSelectedId(null);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [patch, selectedId]);

  const addObject = (make: (id: number) => Obj) => {
    if (objs.length >= MAX_OBJECTS) return;
    setObjs((os) => {
      const id = os.reduce((m, o) => Math.max(m, o.id), -1) + 1;
      const made = make(id);
      // Stagger by how many objects already exist, so a new one never lands
      // exactly under the last. The name suffix counts same-kind objects, so
      // the emitted class names stay distinct.
      const dupes = os.filter((o) => o.kind === made.kind).length;
      const next = {
        ...made,
        name: dupes ? `${made.name} ${dupes + 1}` : made.name,
        x: clamp(made.x + os.length * 4, 0, 100),
        y: clamp(made.y + os.length * 4, 0, 100),
      };
      setSelectedId(id);
      return [...os, next];
    });
  };

  const duplicate = (o: Obj) => {
    if (objs.length >= MAX_OBJECTS) return;
    setObjs((os) => {
      const id = os.reduce((m, x) => Math.max(m, x.id), -1) + 1;
      setSelectedId(id);
      return [...os, {...o, id, name: `${o.name} copy`, x: clamp(o.x + 4, 0, 100), y: clamp(o.y + 4, 0, 100)}];
    });
  };

  const remove = (id: number) => {
    setObjs((os) => os.filter((o) => o.id !== id));
    setSelectedId((cur) => (cur === id ? null : cur));
  };

  const handleCopy = () => {
    const onCopied = () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    };
    navigator.clipboard?.writeText(output).then(onCopied, () => {
      const ta = document.createElement('textarea');
      ta.value = output;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        onCopied();
      } catch {
        // Clipboard unavailable — the text is on screen and selectable anyway.
      }
      document.body.removeChild(ta);
    });
  };

  return (
    <div className="zm-page">
      <div className="zm-wrap">
        <div className="zm-page-head">
          <div>
            <span className="zm-page-head__idx" style={{color: ACCENT}}>
              Tools — Object editor
            </span>
            <h1 className="zm-h1" style={{fontSize: 'clamp(32px,4vw,52px)', maxWidth: '20ch'}}>
              Object layout editor
            </h1>
            <p className="zm-lead">
              Paste or drop a screenshot of the frame you're working in, drop shapes onto it, and
              drag them where you want — they snap to the frame's edges, its centre, and to each
              other. Then copy a prompt that states every position as a percentage of the frame.
            </p>
          </div>
        </div>

        <div className="zm-cam-grid">
          <div className="zm-cam-left">
            <ShotSourceBar shot={shot} onLoad={loadShot} onClear={clearShot} />

            <div
              className={`zm-obj-stage${dropping ? ' is-dropping' : ''}`}
              onDragOver={(e) => {
                e.preventDefault();
                setDropping(true);
              }}
              onDragLeave={() => setDropping(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDropping(false);
                const file = Array.from(e.dataTransfer.files).find((f) =>
                  f.type.startsWith('image/'),
                );
                if (file) loadShot(file);
              }}
            >
              <SceneSprite />
              <div
                className="zm-obj-frame"
                ref={frameRef}
                onPointerDown={() => setSelectedId(null)}
                onMouseDown={() => setSelectedId(null)}
                style={
                  {
                    touchAction: 'none',
                    // The built-in page lays out at its natural size and is
                    // scaled to cover the frame; a screenshot uses object-fit.
                    '--zm-cam-k': String(Math.max(frame.w / PAGE_W, frame.h / PAGE_H)),
                  } as React.CSSProperties
                }
              >
                <div className="zm-cam-scene">
                  <Scene shot={shot} />
                </div>

                <div className="zm-obj-layer">
                  {objs.map((o) => (
                    <ObjectBox
                      key={o.id}
                      o={o}
                      frame={frame}
                      selected={o.id === selectedId}
                      onPointerDown={startDrag(o, 'move')}
                      onHandleDown={startDrag(o, 'resize')}
                    />
                  ))}
                  {guides.x != null ? (
                    <span className="zm-obj-guide zm-obj-guide--v" style={{left: `${guides.x}%`}} />
                  ) : null}
                  {guides.y != null ? (
                    <span className="zm-obj-guide zm-obj-guide--h" style={{top: `${guides.y}%`}} />
                  ) : null}
                </div>
              </div>

              {dropping ? <div className="zm-cam-drop">Drop the screenshot</div> : null}
            </div>

            <div className="zm-cam-presets">
              {KINDS.map((k) => (
                <button
                  key={k.kind}
                  className="zm-ease-add"
                  onClick={() => addObject(k.make)}
                  disabled={objs.length >= MAX_OBJECTS}
                >
                  + {k.label}
                </button>
              ))}
            </div>
          </div>

          <div className="zm-ease-panel">
            <div className="zm-obj-list">
              {objs.length === 0 ? (
                <span className="zm-cam-source__hint">No objects yet — add one below the frame.</span>
              ) : null}
              {objs.map((o, i) => (
                <button
                  key={o.id}
                  className={`zm-obj-row${o.id === selectedId ? ' is-active' : ''}`}
                  onClick={() => setSelectedId(o.id)}
                >
                  <span className="zm-obj-row__idx">{i + 1}</span>
                  <span className="zm-obj-row__swatch" style={{background: o.color}} />
                  <span className="zm-obj-row__name">{o.name}</span>
                  <span
                    className="zm-ease-segment__remove zm-obj-row__remove"
                    onClick={(e) => {
                      e.stopPropagation();
                      remove(o.id);
                    }}
                  >
                    ×
                  </span>
                </button>
              ))}
            </div>

            {selected ? (
              <>
                <div className="zm-cam-controls">
                  <div className="zm-cam-row">
                    <span className="zm-cam-slider__label">Name</span>
                    <input
                      className="zm-obj-input"
                      value={selected.name}
                      onChange={(e) => patchSelected({name: e.target.value})}
                    />
                  </div>
                  <Slider
                    label="Centre X"
                    value={selected.x}
                    min={-20}
                    max={120}
                    step={0.5}
                    suffix="%"
                    onChange={(x) => patchSelected({x})}
                  />
                  <Slider
                    label="Centre Y"
                    value={selected.y}
                    min={-20}
                    max={120}
                    step={0.5}
                    suffix="%"
                    onChange={(y) => patchSelected({y})}
                  />
                  <Slider
                    label="Width"
                    value={selected.w}
                    min={1}
                    max={120}
                    step={0.5}
                    suffix="%"
                    onChange={(w) =>
                      patchSelected(selected.kind === 'circle' ? {w, h: squareH(w)} : {w})
                    }
                  />
                  <Slider
                    label="Height"
                    value={selected.h}
                    min={1}
                    max={120}
                    step={0.5}
                    suffix="%"
                    onChange={(h) =>
                      patchSelected(selected.kind === 'circle' ? {h, w: h / FRAME_ASPECT} : {h})
                    }
                  />
                  <Slider
                    label="Rotate"
                    value={selected.rotate}
                    min={-180}
                    max={180}
                    step={1}
                    suffix="°"
                    onChange={(rotate) => patchSelected({rotate})}
                  />
                  {selected.kind === 'rect' || selected.kind === 'image' ? (
                    <Slider
                      label="Radius"
                      value={selected.radius}
                      min={0}
                      max={120}
                      step={1}
                      suffix="px"
                      onChange={(radius) => patchSelected({radius})}
                    />
                  ) : null}
                  <div className="zm-cam-row">
                    <span className="zm-cam-slider__label">
                      {selected.kind === 'text' ? 'Text' : 'Label'}
                    </span>
                    <input
                      className="zm-obj-input"
                      value={selected.text}
                      placeholder={selected.kind === 'text' ? 'Your text here' : 'optional'}
                      onChange={(e) => patchSelected({text: e.target.value})}
                    />
                  </div>
                  <div className="zm-cam-row">
                    <span className="zm-cam-slider__label">Colour</span>
                    <span className="zm-obj-swatches">
                      {SWATCHES.map((c) => (
                        <button
                          key={c}
                          className={`zm-obj-swatch${selected.color === c ? ' is-active' : ''}`}
                          style={{background: c}}
                          onClick={() => patchSelected({color: c})}
                        />
                      ))}
                    </span>
                  </div>
                  <div className="zm-cam-row">
                    <span className="zm-cam-readout">{alignmentNotes(selected)[0] ?? ''}</span>
                    <button className="zm-cam-reset" onClick={() => duplicate(selected)}>
                      Duplicate
                    </button>
                    <button className="zm-cam-reset" onClick={() => patchSelected({x: 50, y: 50})}>
                      Centre
                    </button>
                  </div>
                </div>
                <div className="zm-cam-leg zm-cam-leg--empty">
                  Drag to move, scroll to scale, corner handle to resize, arrow keys to nudge
                  (hold shift for 0.1%). Objects snap to the frame's edges and centre, and to
                  each other.
                </div>
              </>
            ) : (
              <div className="zm-cam-controls zm-cam-controls--locked">
                <b>Nothing selected.</b>
                <span>
                  Pick an object from the list, or click one in the frame. Add new ones with the
                  buttons under the frame.
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="zm-cam-output">
          <div className="zm-cam-output__head">
            <span className="zm-eyebrow">Prompt — paste this to an LLM</span>
            <button className="zm-btn zm-btn--ghost zm-ease-copy" onClick={handleCopy}>
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="zm-cam-output__body">{output}</pre>
        </div>
      </div>
    </div>
  );
}
