import React, {useEffect, useState} from 'react';
import {CATEGORIES, ENTRIES, entriesByCategory, type AnimationEntry} from './registry';
import {AnimationPreview} from './AnimationPreview';
import type {Route} from './useHashRoute';

const FEATURED_IDS = [
  'ecosystem-constellation',
  'infinite-bento-pan',
  'claude-chat',
  'icon-orbit-scene',
  'shader-mesh-gradient',
];

const featured: AnimationEntry[] = FEATURED_IDS.map(
  (id) => ENTRIES.find((e) => e.id === id)!,
).filter(Boolean);

function Showcase() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setI((v) => (v + 1) % featured.length), 5600);
    return () => clearInterval(t);
  }, []);
  const entry = featured[i];
  return (
    <div className="zm-showcase">
      <div className="zm-showcase__glow" />
      <div className="zm-showcase__frame">
        <div className="zm-showcase__bar">
          <span className="zm-showcase__dot" />
          <span className="zm-showcase__dot" />
          <span className="zm-showcase__dot" />
          <span className="zm-showcase__tag">{entry.id}</span>
        </div>
        <AnimationPreview key={entry.id} entry={entry} autoPlay />
      </div>
      <div
        style={{
          display: 'flex',
          gap: 7,
          justifyContent: 'center',
          marginTop: 16,
        }}
      >
        {featured.map((f, idx) => (
          <button
            key={f.id}
            onClick={() => setI(idx)}
            aria-label={f.name}
            style={{
              width: idx === i ? 26 : 8,
              height: 8,
              borderRadius: 999,
              border: 'none',
              cursor: 'pointer',
              background: idx === i ? 'var(--zm-accent)' : 'rgba(255,255,255,0.18)',
              transition: 'all .3s cubic-bezier(.22,1,.36,1)',
            }}
          />
        ))}
      </div>
    </div>
  );
}

export function HomePage({navigate}: {navigate: (r: Route) => void}) {
  return (
    <div className="zm-page">
      <div className="zm-wrap">
        {/* ---------------------------------------------------------- hero */}
        <section className="zm-hero">
          <div className="zm-hero__grid" />
          <div className="zm-hero__glow zm-hero__glow--a" />
          <div className="zm-hero__glow zm-hero__glow--b" />
          <div className="zm-hero__inner">
            <span className="zm-pill">
              <span className="zm-pill__tag">Live</span>
              Every preset plays right in your browser
              <span className="zm-pill__arrow">→</span>
            </span>

            <h1 className="zm-h1">
              The motion library for <em>Zoom</em> designers &amp; builders.
            </h1>

            <p className="zm-hero__sub">
              <strong>{ENTRIES.length} production-ready Remotion presets</strong> — text
              reveals, UI-component states, transitions, product flows and shaders. The
              motion a designer prototypes is the exact same code an engineer ships.
            </p>

            <div className="zm-cta-row">
              <button className="zm-btn zm-btn--primary" onClick={() => navigate('scene')}>
                Browse the library →
              </button>
              <a
                className="zm-btn zm-btn--ghost"
                href="https://github.com/mattbwesson/zm-motion"
                target="_blank"
                rel="noreferrer"
              >
                github:mattbwesson/zm-motion
              </a>
            </div>

            <Showcase />
          </div>
        </section>

        {/* --------------------------------------------------------- stats */}
        <div className="zm-stats">
          <Stat num={String(ENTRIES.length)} label="animation presets" />
          <Stat num={String(CATEGORIES.length)} label="categories" />
          <Stat num="100%" label="real Remotion code" />
          <Stat num="0" label="mockups to redline" />
        </div>

        {/* ---------------------------------------------------- who it's for */}
        <section className="zm-section">
          <div className="zm-section__head">
            <div>
              <span className="zm-eyebrow">Who it's for</span>
              <h2 className="zm-h2">One source of truth for product motion</h2>
            </div>
          </div>
          <div className="zm-personas">
            <div className="zm-persona">
              <span
                className="zm-persona__tag"
                style={{color: '#c9a3ff', borderColor: 'rgba(168,85,247,.4)'}}
              >
                Designers
              </span>
              <h3>Prototype motion, fast</h3>
              <p>
                Reach for a preset instead of keyframing from scratch. Text reveals,
                UI-component states, transitions and full product flows are ready to
                compose — tune the props, not the timeline.
              </p>
            </div>
            <div className="zm-persona">
              <span
                className="zm-persona__tag"
                style={{color: '#a3e635', borderColor: 'rgba(163,230,53,.4)'}}
              >
                Builders
              </span>
              <h3>Ship the exact same motion</h3>
              <p>
                Import the identical components into product code. No redlines, no “make
                it match the mock” — the spec and the implementation are one Remotion
                package.
              </p>
            </div>
          </div>
        </section>

        {/* ----------------------------------------------------- categories */}
        <section className="zm-section">
          <div className="zm-section__head">
            <div>
              <span className="zm-eyebrow">The library</span>
              <h2 className="zm-h2">Explore by category</h2>
            </div>
          </div>
          <div className="zm-cats">
            {CATEGORIES.map((c) => (
              <button
                key={c.id}
                className="zm-cat"
                style={{['--cat' as any]: c.accent}}
                onClick={() => navigate(c.id)}
              >
                <div className="zm-cat__top">
                  <span className="zm-cat__idx">{c.index}</span>
                  <span className="zm-cat__arrow">↗</span>
                </div>
                <h3>{c.label}</h3>
                <p>{c.blurb}</p>
                <div className="zm-cat__bar" />
                <div
                  style={{
                    marginTop: 14,
                    fontFamily: 'var(--zm-mono)',
                    fontSize: 11,
                    color: 'var(--zm-text-faint)',
                  }}
                >
                  {entriesByCategory(c.id).length} presets
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* -------------------------------------------------- getting started */}
        <section className="zm-section">
          <div className="zm-section__head">
            <div>
              <span className="zm-eyebrow">Getting started</span>
              <h2 className="zm-h2">Install &amp; drop in</h2>
            </div>
          </div>
          <div style={{display: 'grid', gap: 16}}>
            <div className="zm-code">
              <div className="zm-code__bar">terminal</div>
              <pre>
                <code>npm install github:mattbwesson/zm-motion</code>
              </pre>
            </div>
            <div className="zm-code">
              <div className="zm-code__bar">Player.tsx</div>
              <pre>
                <code>
                  <span className="tok-key">import</span> {'{Player}'}{' '}
                  <span className="tok-key">from</span>{' '}
                  <span className="tok-str">'@remotion/player'</span>;{'\n'}
                  <span className="tok-key">import</span> {'{ClaudeChat}'}{' '}
                  <span className="tok-key">from</span>{' '}
                  <span className="tok-str">'zm-motion/claude-chat'</span>;{'\n\n'}
                  {'<'}
                  <span className="tok-fn">Player</span>
                  {'\n'}
                  {'  component={ClaudeChat}'}
                  {'\n'}
                  {'  durationInFrames={160}'}
                  {'\n'}
                  {'  fps={30}'}
                  {'\n'}
                  {'  compositionWidth={1280}'}
                  {'\n'}
                  {'  compositionHeight={720}'}
                  {'\n'}
                  {'/>'};
                </code>
              </pre>
            </div>
          </div>
        </section>

        <footer className="zm-foot">
          Previews render the actual library components frame-by-frame with the Remotion
          Player. Built with the Astryx design system.
        </footer>
      </div>
    </div>
  );
}

function Stat({num, label}: {num: string; label: string}) {
  return (
    <div className="zm-stat">
      <div className="zm-stat__num">{num}</div>
      <div className="zm-stat__label">{label}</div>
    </div>
  );
}
