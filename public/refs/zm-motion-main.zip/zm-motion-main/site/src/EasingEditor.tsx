// Cubic-bezier curve editor — drag the two handles to shape a CSS
// `cubic-bezier(x1,y1,x2,y2)` timing function, then hit GO to preview it.
//
// "Add a curve" strings additional curves onto the timeline. They're drawn
// COMPOSITED into a single graph: with N curves, segment i carries progress
// from i/N to (i+1)/N, across a slice of the x axis proportional to its
// duration. So each segment still rises bottom-left -> top-right inside its
// own box, and the boxes tile diagonally into one continuous curve — no
// vertical flipping needed (that would only apply to the RETURN leg of the
// ping-pong, where progress runs 1 -> 0).
//
// Playback uses the Web Animations API, since a plain CSS transition can only
// ever carry a single easing function. No compare, no saved-curve library —
// just edit and preview.
import React, {useCallback, useEffect, useRef, useState} from 'react';

type Point = {x: number; y: number};
type Segment = {id: number; p1: Point; p2: Point; duration: number};
/** Where one segment lives in the composite graph, in global 0..1 curve space. */
type Box = {x0: number; x1: number; y0: number; y1: number};
type Range = {min: number; max: number};

const VB = 300; // svg viewBox is VB x VB
const PINK = '#ec4899';
const TEAL = '#22d3ee';
const BOX_PX = 34; // preview track box size, kept in sync with .zm-ease-track__box
const MAX_SEGMENTS = 2; // a chain longer than this stops being a quick thing to read/paste
/** How far a control point may sit outside its own box, in local (per-segment) units. */
const LOCAL_Y_MIN = -0.5;
const LOCAL_Y_MAX = 1.5;

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

/**
 * Visible y window. Padding is 0.5/N so that a single curve gets the familiar
 * -0.5..1.5 window, and a chain of N still leaves each segment the same HALF-BAND
 * of overshoot room in its own local units — the chain fills the graph instead of
 * shrinking into the middle of it.
 */
const yRange = (n: number): Range => {
  const pad = 0.5 / n;
  return {min: -pad, max: 1 + pad};
};

const toSvgX = (t: number) => t * VB;
const toSvgY = (y: number, r: Range) => ((r.max - y) / (r.max - r.min)) * VB;

// Percent-from-bottom equivalent of toSvgY, for the CSS-side preview dot (which
// is positioned with `bottom: %` in a plain HTML div, not SVG coordinates).
const toBottomPct = (y: number, r: Range) => ((y - r.min) / (r.max - r.min)) * 100;

/** The bare CSS timing function. Also fed to WAAPI as `easing`, so it must stay pure. */
function formatCurve(p1: Point, p2: Point): string {
  const n = (v: number) => (Math.round(v * 100) / 100).toFixed(2);
  return `cubic-bezier(${n(p1.x)}, ${n(p1.y)}, ${n(p2.x)}, ${n(p2.y)})`;
}

/** What gets shown and copied: the curve plus its duration, e.g. `cubic-bezier(…) 1000ms`. */
function formatCurveWithDuration(seg: Segment): string {
  return `${formatCurve(seg.p1, seg.p2)} ${Math.round(seg.duration * 1000)}ms`;
}

/**
 * What actually gets copied. A single curve copies bare, unchanged. Two curves copy
 * together as one block, each labeled "Part 1" / "Part 2" — plain enough that an LLM
 * (or a human) pasted only this text still knows it's two curves meant to run back to
 * back in order, not two unrelated options.
 */
function formatCopyText(segments: Segment[]): string {
  if (segments.length < 2) return formatCurveWithDuration(segments[0]);
  return segments.map((seg, i) => `Part ${i + 1}: ${formatCurveWithDuration(seg)}`).join('\n');
}

function defaultSegment(id: number, from?: Segment): Segment {
  return from
    ? {id, p1: {...from.p1}, p2: {...from.p2}, duration: from.duration}
    : {id, p1: {x: 0.81, y: -0.01}, p2: {x: 0.35, y: 1}, duration: 1};
}

/** Each segment's box: x by share of total DURATION, y by equal share of PROGRESS. */
function segmentBoxes(segments: Segment[]): Box[] {
  const total = segments.reduce((sum, s) => sum + s.duration, 0) || 1;
  const n = segments.length;
  let acc = 0;
  return segments.map((seg, i) => {
    const x0 = acc / total;
    acc += seg.duration;
    return {x0, x1: acc / total, y0: i / n, y1: (i + 1) / n};
  });
}

/** Local (per-segment, 0..1 with overshoot) -> global composite curve space. */
const toGlobal = (b: Box, p: Point): Point => ({
  x: b.x0 + p.x * (b.x1 - b.x0),
  y: b.y0 + p.y * (b.y1 - b.y0),
});

/** Global composite curve space -> local, for turning a drag back into control points. */
const toLocal = (b: Box, g: Point): Point => ({
  x: (g.x - b.x0) / (b.x1 - b.x0),
  y: (g.y - b.y0) / (b.y1 - b.y0),
});

/** One `C` command per segment, mapped into its box — the whole chain as one path. */
function segmentPath(seg: Segment, b: Box, r: Range): string {
  const c1 = toGlobal(b, seg.p1);
  const c2 = toGlobal(b, seg.p2);
  return (
    `M ${toSvgX(b.x0)},${toSvgY(b.y0, r)} ` +
    `C ${toSvgX(c1.x)},${toSvgY(c1.y, r)} ` +
    `${toSvgX(c2.x)},${toSvgY(c2.y, r)} ` +
    `${toSvgX(b.x1)},${toSvgY(b.y1, r)}`
  );
}

/**
 * Runs a set of WAAPI animations on `ref` whenever `atEnd` flips, and clears them
 * when `resetKey` changes. Always plays with `direction: 'normal'` — WAAPI's
 * `reverse` runs TIME backward through the easing, which inverts the curve's own
 * shape (an ease-out would suddenly play like an ease-in). Nobody applies a curve
 * that way, so instead `build(atEnd)` supplies keyframes with the SPATIAL target
 * mirrored for the return trip while every easing still runs forward, in its
 * original segment order — exactly how a real "animate back" would be authored.
 * Previous runs are always cancelled first — otherwise each GO click stacks
 * another finished-but-filling Animation on the element.
 */
function useChainPlayback(
  ref: React.RefObject<HTMLElement | null>,
  atEnd: boolean,
  resetKey: number,
  build: (atEnd: boolean) => {keyframes: Keyframe[]; totalMs: number}[],
) {
  const buildRef = useRef(build);
  buildRef.current = build;
  const animsRef = useRef<Animation[]>([]);
  const skipFirst = useRef(true);

  useEffect(() => {
    // Don't auto-play on mount — only an explicit GO click (which flips
    // `atEnd`) should trigger playback.
    if (skipFirst.current) {
      skipFirst.current = false;
      return;
    }
    const el = ref.current;
    if (!el) return;
    animsRef.current.forEach((a) => a.cancel());
    animsRef.current = buildRef.current(atEnd).map(({keyframes, totalMs}) =>
      el.animate(keyframes, {
        duration: totalMs,
        direction: 'normal',
        fill: 'forwards',
      }),
    );
  }, [atEnd, ref]);

  // Adding/removing a curve rescales the whole graph, so any filled-forwards
  // animation is now holding stale absolute values — drop it and let the
  // element fall back to its inline resting position.
  useEffect(() => {
    animsRef.current.forEach((a) => a.cancel());
    animsRef.current = [];
  }, [resetKey]);
}

function CurveGraph({
  segments,
  activeIndex,
  onSelectSegment,
  onChangeHandle,
  atEnd,
}: {
  segments: Segment[];
  activeIndex: number;
  onSelectSegment: (i: number) => void;
  onChangeHandle: (which: 'p1' | 'p2', p: Point) => void;
  atEnd: boolean;
}) {
  const svgRef = useRef<SVGSVGElement>(null);
  const dotRef = useRef<HTMLDivElement>(null);
  const dragging = useRef<'p1' | 'p2' | null>(null);

  const n = segments.length;
  const r = yRange(n);
  const boxes = segmentBoxes(segments);
  const activeBox = boxes[activeIndex];
  const active = segments[activeIndex];

  const activeBoxRef = useRef(activeBox);
  activeBoxRef.current = activeBox;
  const rangeRef = useRef(r);
  rangeRef.current = r;

  const pointFromEvent = useCallback((clientX: number, clientY: number): Point => {
    const rect = svgRef.current!.getBoundingClientRect();
    const range = rangeRef.current;
    // Pointer -> global curve space, then back down into the active segment's box.
    const gx = ((clientX - rect.left) / rect.width) * 1;
    const gy = range.max - ((clientY - rect.top) / rect.height) * (range.max - range.min);
    const local = toLocal(activeBoxRef.current, {x: gx, y: gy});
    return {
      x: clamp(local.x, 0, 1), // CSS requires control-point x within 0..1
      y: clamp(local.y, LOCAL_Y_MIN, LOCAL_Y_MAX),
    };
  }, []);

  useEffect(() => {
    // Bound to both pointer and plain mouse events — most input devices fire
    // both for a real drag, but some environments (e.g. automated/synthetic
    // input) only dispatch one or the other, so both are handled.
    const move = (e: PointerEvent | MouseEvent) => {
      if (!dragging.current) return;
      onChangeHandle(dragging.current, pointFromEvent(e.clientX, e.clientY));
    };
    const up = () => {
      dragging.current = null;
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    // A cancelled pointer (interrupted touch, gesture takeover) never sends
    // pointerup — without this the handle would stay glued to the cursor.
    window.addEventListener('pointercancel', up);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [pointFromEvent, onChangeHandle]);

  const startDrag = (handle: 'p1' | 'p2') => (e: React.PointerEvent | React.MouseEvent) => {
    e.preventDefault();
    dragging.current = handle;
  };

  // The dot traces the composite curve EXACTLY as drawn — always the same path,
  // regardless of which way the separate preview-track box happens to be
  // heading. It isn't standing in for "an element animating back"; it's a
  // direct readout of the curve itself, so it retraces identically on every
  // GO click. (x always sweeps left -> right, since x IS time and a curve
  // should never be read backward; y is never mirrored either, for the same
  // reason — a mirrored y would trace a DIFFERENT path than the one drawn.)
  // These have to be two separate WAAPI animations because a keyframe's
  // easing applies to every property in that interval — one shared list
  // couldn't keep x linear while y curves.
  useChainPlayback(dotRef, atEnd, n, () => {
    const bs = segmentBoxes(segments);
    const range = yRange(segments.length);
    const totalMs = Math.max(1, segments.reduce((sum, s) => sum + s.duration, 0) * 1000);
    const bottom: Keyframe[] = bs.map((b, i) => ({
      offset: clamp(b.x0, 0, 1),
      bottom: `${toBottomPct(b.y0, range)}%`,
      easing: formatCurve(segments[i].p1, segments[i].p2),
    }));
    bottom.push({offset: 1, bottom: `${toBottomPct(1, range)}%`});
    return [
      {keyframes: [{left: '0%'}, {left: '100%'}], totalMs},
      {keyframes: bottom, totalMs},
    ];
  });

  return (
    <div className="zm-ease-graph">
      <div className="zm-ease-graph__inner">
        <svg
          ref={svgRef}
          className="zm-ease-svg"
          viewBox={`0 0 ${VB} ${VB}`}
          style={{touchAction: 'none'}}
        >
          {/* One box per segment — click to make it the one you're editing. */}
          {boxes.map((b, i) => (
            <rect
              key={segments[i].id}
              x={toSvgX(b.x0)}
              y={toSvgY(b.y1, r)}
              width={toSvgX(b.x1) - toSvgX(b.x0)}
              height={toSvgY(b.y0, r) - toSvgY(b.y1, r)}
              fill={i === activeIndex ? 'rgba(255,255,255,0.05)' : 'rgba(255,255,255,0.02)'}
              stroke={i === activeIndex ? 'rgba(255,255,255,0.22)' : 'rgba(255,255,255,0.08)'}
              style={{cursor: i === activeIndex ? 'default' : 'pointer'}}
              onClick={() => onSelectSegment(i)}
            />
          ))}

          {/* Overall linear reference, corner to corner across the whole chain. */}
          <line
            x1={toSvgX(0)}
            y1={toSvgY(0, r)}
            x2={toSvgX(1)}
            y2={toSvgY(1, r)}
            stroke="rgba(255,255,255,0.14)"
            strokeDasharray="3 4"
            pointerEvents="none"
          />

          {n > 1
            ? boxes.map((b, i) => (
                <text
                  key={`label-${segments[i].id}`}
                  x={toSvgX(b.x0) + 6}
                  y={toSvgY(b.y1, r) + 14}
                  fill={i === activeIndex ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.28)'}
                  fontSize={11}
                  fontFamily="ui-monospace, monospace"
                  pointerEvents="none"
                >
                  {i + 1}
                </text>
              ))
            : null}

          {/* Whole chain dimmed, then the active segment overdrawn bright. */}
          <path
            d={segments.map((seg, i) => segmentPath(seg, boxes[i], r)).join(' ')}
            fill="none"
            stroke="rgba(255,255,255,0.3)"
            strokeWidth={2}
            strokeLinecap="round"
            pointerEvents="none"
          />
          <path
            d={segmentPath(active, activeBox, r)}
            fill="none"
            stroke="#f5f5f7"
            strokeWidth={2.5}
            strokeLinecap="round"
            pointerEvents="none"
          />

          {/* Handle arms + endpoints, for the active segment only. */}
          <line
            x1={toSvgX(activeBox.x0)}
            y1={toSvgY(activeBox.y0, r)}
            x2={toSvgX(toGlobal(activeBox, active.p1).x)}
            y2={toSvgY(toGlobal(activeBox, active.p1).y, r)}
            stroke={PINK}
            strokeWidth={1.5}
            pointerEvents="none"
          />
          <line
            x1={toSvgX(activeBox.x1)}
            y1={toSvgY(activeBox.y1, r)}
            x2={toSvgX(toGlobal(activeBox, active.p2).x)}
            y2={toSvgY(toGlobal(activeBox, active.p2).y, r)}
            stroke={TEAL}
            strokeWidth={1.5}
            pointerEvents="none"
          />
          <circle
            cx={toSvgX(activeBox.x0)}
            cy={toSvgY(activeBox.y0, r)}
            r={5}
            fill="#0d0d11"
            stroke="#f5f5f7"
            strokeWidth={2}
            pointerEvents="none"
          />
          <circle
            cx={toSvgX(activeBox.x1)}
            cy={toSvgY(activeBox.y1, r)}
            r={5}
            fill="#0d0d11"
            stroke="#f5f5f7"
            strokeWidth={2}
            pointerEvents="none"
          />
          <circle
            cx={toSvgX(toGlobal(activeBox, active.p1).x)}
            cy={toSvgY(toGlobal(activeBox, active.p1).y, r)}
            r={7}
            fill={PINK}
            stroke="#0d0d11"
            strokeWidth={2}
            className="zm-ease-handle"
            onPointerDown={startDrag('p1')}
            onMouseDown={startDrag('p1')}
          />
          <circle
            cx={toSvgX(toGlobal(activeBox, active.p2).x)}
            cy={toSvgY(toGlobal(activeBox, active.p2).y, r)}
            r={7}
            fill={TEAL}
            stroke="#0d0d11"
            strokeWidth={2}
            className="zm-ease-handle"
            onPointerDown={startDrag('p2')}
            onMouseDown={startDrag('p2')}
          />
        </svg>
        <div
          ref={dotRef}
          className="zm-ease-dot"
          style={{left: '0%', bottom: `${toBottomPct(0, r)}%`}}
        />
      </div>
    </div>
  );
}

/**
 * Keyframes for the whole chain on the preview track: each segment gets an equal
 * slice of horizontal travel (matching its progress band in the graph) and its own
 * easing, with offsets placed by that segment's share of the total duration. On the
 * return trip (`reverse`), the box still travels right -> left, but only the
 * SPATIAL target is mirrored — every easing still runs forward in the same segment
 * order, so a curve's character (e.g. ease-out staying fast-then-slow) never
 * flips just because the box is heading back to the start.
 */
function buildTrackKeyframes(segments: Segment[], reverse: boolean): {keyframes: Keyframe[]; totalMs: number} {
  const boxes = segmentBoxes(segments);
  const pct = (frac: number) => `calc((100% - ${BOX_PX}px) * ${frac})`;
  const target = (frac: number) => (reverse ? 1 - frac : frac);
  const keyframes: Keyframe[] = boxes.map((b, i) => ({
    offset: clamp(b.x0, 0, 1),
    left: pct(target(b.y0)),
    easing: formatCurve(segments[i].p1, segments[i].p2),
  }));
  keyframes.push({offset: 1, left: pct(target(1))});
  const totalMs = Math.max(1, segments.reduce((sum, s) => sum + s.duration, 0) * 1000);
  return {keyframes, totalMs};
}

function PreviewTrack({segments, atEnd}: {segments: Segment[]; atEnd: boolean}) {
  const boxRef = useRef<HTMLDivElement>(null);
  useChainPlayback(boxRef, atEnd, segments.length, (goingToEnd) => [
    buildTrackKeyframes(segments, !goingToEnd),
  ]);
  return (
    <div className="zm-ease-track">
      <div ref={boxRef} className="zm-ease-track__box" style={{left: 0}} />
    </div>
  );
}

export function EasingEditor() {
  const [segments, setSegments] = useState<Segment[]>([defaultSegment(0)]);
  const [activeIndex, setActiveIndex] = useState(0);
  const [atEnd, setAtEnd] = useState(false);
  const [copied, setCopied] = useState(false);

  const active = segments[activeIndex];
  // What you see in the box is exactly what Copy puts on the clipboard.
  const copyText = formatCopyText(segments);
  const totalDuration = segments.reduce((sum, seg) => sum + seg.duration, 0);

  const updateActive = useCallback(
    (patch: Partial<Segment>) => {
      setSegments((segs) => segs.map((seg, i) => (i === activeIndex ? {...seg, ...patch} : seg)));
    },
    [activeIndex],
  );

  const handleChangeHandle = useCallback(
    (which: 'p1' | 'p2', p: Point) => updateActive({[which]: p}),
    [updateActive],
  );

  const handleAddCurve = () => {
    if (segments.length >= MAX_SEGMENTS) return;
    const newIndex = segments.length;
    setSegments((segs) => {
      // Derived from the current segments rather than a module-level counter —
      // a mutable module counter can drift out of sync with component state
      // (e.g. across a Vite HMR reload) and hand out an id that collides with
      // an existing segment's React key.
      const nextId = segs.reduce((max, s) => Math.max(max, s.id), -1) + 1;
      return [...segs, defaultSegment(nextId, segs[segs.length - 1])];
    });
    setActiveIndex(newIndex);
    setAtEnd(false); // chain changed — send the preview back to the start
  };

  const handleRemoveCurve = (idx: number) => {
    if (segments.length <= 1) return;
    setSegments((segs) => segs.filter((_, i) => i !== idx));
    setActiveIndex((i) => {
      if (idx < i) return i - 1;
      if (idx === i) return Math.max(0, i - 1);
      return i;
    });
    setAtEnd(false);
  };

  const handleCopy = () => {
    const onCopied = () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    };
    navigator.clipboard?.writeText(copyText).then(onCopied, () => {
      // Permission denied / API unavailable — fall back to the old
      // select-and-execCommand trick so the button still works.
      const textarea = document.createElement('textarea');
      textarea.value = copyText;
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      try {
        document.execCommand('copy');
        onCopied();
      } catch {
        // Nothing more we can do — leave the button as-is.
      }
      document.body.removeChild(textarea);
    });
  };

  // Toggles direction rather than always resetting to the start — so the
  // preview box/dot glides back and forth across the same GO button instead
  // of snapping back to the left every time.
  const handleGo = () => setAtEnd((v) => !v);

  return (
    <div className="zm-page">
      <div className="zm-wrap">
        <div className="zm-page-head">
          <div>
            <span className="zm-page-head__idx" style={{color: TEAL}}>
              Tools — Easing editor
            </span>
            <h1 className="zm-h1" style={{fontSize: 'clamp(32px,4vw,52px)', maxWidth: '20ch'}}>
              Cubic-bezier editor
            </h1>
            <p className="zm-lead">
              Drag the two handles to shape the curve. Add a curve to string another one onto the
              timeline — each takes its own band of the graph — then hit GO to preview the whole
              chain as one seamless animation.
            </p>
          </div>
        </div>

        <div className="zm-ease-grid">
          <CurveGraph
            segments={segments}
            activeIndex={activeIndex}
            onSelectSegment={setActiveIndex}
            onChangeHandle={handleChangeHandle}
            atEnd={atEnd}
          />

          <div className="zm-ease-panel">
            <div className="zm-ease-segments">
              {segments.map((seg, i) => (
                <button
                  key={seg.id}
                  className={`zm-ease-segment${i === activeIndex ? ' is-active' : ''}`}
                  onClick={() => setActiveIndex(i)}
                >
                  {i + 1}
                  {segments.length > 1 ? (
                    <span
                      className="zm-ease-segment__remove"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveCurve(i);
                      }}
                    >
                      ×
                    </span>
                  ) : null}
                </button>
              ))}
              {segments.length < MAX_SEGMENTS ? (
                <button className="zm-ease-add" onClick={handleAddCurve}>
                  + Add a curve
                </button>
              ) : null}
            </div>

            <div className="zm-ease-eq">
              <code className="zm-ease-eq__text">
                {segments.length > 1
                  ? segments.map((seg, i) => <div key={seg.id}>{`Part ${i + 1}: ${formatCurveWithDuration(seg)}`}</div>)
                  : copyText}
              </code>
              <button className="zm-btn zm-btn--ghost zm-ease-copy" onClick={handleCopy}>
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>

            <div className="zm-ease-duration">
              <span className="zm-ease-duration__label">
                {segments.length > 1 ? `Segment ${activeIndex + 1} duration` : 'Duration'}
              </span>
              <input
                type="range"
                min={0.2}
                max={3}
                step={0.1}
                value={active.duration}
                onChange={(e) => updateActive({duration: Number(e.target.value)})}
                className="zm-ease-slider"
              />
              <span className="zm-ease-duration__value">{active.duration.toFixed(1)}s</span>
            </div>

            <div className="zm-ease-go-row">
              <button className="zm-btn zm-btn--primary zm-ease-go" onClick={handleGo}>
                GO
              </button>
              {segments.length > 1 ? (
                <span className="zm-ease-total">
                  {segments.length} curves chained · {totalDuration.toFixed(1)}s total
                </span>
              ) : null}
            </div>

            <PreviewTrack segments={segments} atEnd={atEnd} />
          </div>
        </div>
      </div>
    </div>
  );
}
