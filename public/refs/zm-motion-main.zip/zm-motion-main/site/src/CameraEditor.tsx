// Camera move editor — point the camera at a screenshot of the shot you already
// have, set a few keyframes of pan/zoom/roll, preview the move, then copy a
// prompt precise enough that an LLM can rebuild it without guessing.
//
// THE RELATIVE MODEL — the thing that makes this tool useful.
// The screenshot a user brings is a frame out of an animation that may ALREADY
// be panning or pushing. So K1 is not "scale 1 at the origin"; K1 is "whatever
// the camera is doing at that frame", and every number the tool emits is
// relative to it. That is why K1 is locked to identity here: it isn't a shot you
// author, it's the shot you already have. K2 onward are deltas from it.
//
// The prompt therefore asks for a NEW OUTER WRAPPER around the existing scene
// rather than an edit to it. Nesting composes the two transforms automatically,
// which is the only instruction robust enough to survive an LLM that can't see
// the existing animation code.
//
// THE TRANSFORM (one definition, used by the preview and the prompt alike, so
// the two can never disagree):
//
//   camera frame  = a fixed-size, overflow:hidden box
//   move layer    = a child sized EXACTLY to the frame, carrying only this move
//   transform-origin: 50% 50%
//   transform: translate(x%, y%) rotate(rotate deg) scale(scale)
//
// x/y are percentages of the move layer's own box — and since that box IS the
// frame, they're resolution-independent, and a `%` translate never gets scaled
// by the trailing scale() (percentages resolve against the untransformed border
// box). Order is fixed: translate, then rotate, then scale.
//
// The values describe the SCENE, because that's what you actually write in code.
// Camera language is the inverse and only appears in prose: scene right = camera
// pans left.
//
// Deliberately narrow elsewhere: one easing for every leg, one output format. A
// knob that only ever gets left on its default makes the tool harder to read.
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {PAGE_H, PAGE_W} from './zoomProfileScene';
import {
  REGIONS,
  Scene,
  SceneSprite,
  ShotSourceBar,
  useShot,
  type Rect,
  type Shot,
} from './scene';

type Key = {
  id: number;
  x: number; // % of frame width, scene shifted right when positive
  y: number; // % of frame height, scene shifted down when positive
  scale: number;
  rotate: number; // degrees, scene rotated clockwise when positive
  /** Seconds to travel INTO this key from the previous one. Unused on key 0. */
  inDuration: number;
};
type Vec = {x: number; y: number};

const MAX_KEYS = 4;
const MIN_KEYS = 2;
const ACCENT = '#c9f24d';

const X_RANGE = 90; // slider bound, % of frame width
const Y_RANGE = 90;
const SCALE_MIN = 0.4;
const SCALE_MAX = 4;
const ROTATE_RANGE = 25;

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const round = (v: number, dp: number) => Number(v.toFixed(dp));

/** Every leg, always. Not configurable — see the note at the top of the file. */
const EASE_CSS = 'cubic-bezier(0.4, 0, 0.2, 1)';

/**
 * Inverse of the transform: where in the scene does the frame's center land?
 * Screen offset of scene point p (center-origin, in frame fractions) is
 * `t + scale · R(θ) · p`; the frame center is offset 0, so `p = -R(-θ)·t/scale`.
 */
function framedPoint(k: Key): Vec {
  const t = {x: k.x / 100, y: k.y / 100};
  const rad = (-k.rotate * Math.PI) / 180;
  const cos = Math.cos(rad);
  const sin = Math.sin(rad);
  const px = (-(t.x * cos - t.y * sin)) / k.scale;
  const py = (-(t.x * sin + t.y * cos)) / k.scale;
  return {x: px + 0.5, y: py + 0.5};
}

/** The frame's footprint in scene space. Roll is ignored — see framedRegion. */
function visibleRect(k: Key): Rect {
  const c = framedPoint(k);
  const half = 0.5 / k.scale;
  return [c.x - half, c.y - half, c.x + half, c.y + half];
}

/** True when the frame reaches past the scene, i.e. past what the shot shows. */
function showsPastScene(k: Key): boolean {
  const v = visibleRect(k);
  return v[0] < -0.002 || v[1] < -0.002 || v[2] > 1.002 || v[3] > 1.002;
}

/**
 * What the shot is ON, for the built-in scene. Deliberately not "whatever sits
 * under the frame's centre point" — a shot pushed to the top of the page has the
 * privacy banner filling most of the frame while its centre still lands in the
 * header. Scored instead on coverage x share: how much of the region you can
 * SEE, times how much of the FRAME it takes up. Neither alone works — coverage
 * alone always crowns the smallest fully-visible region (the profile photo would
 * win every wide shot), and share alone always crowns the biggest. Roll is
 * ignored; it barely moves the answer and squaring off a rotated rect isn't
 * worth it.
 */
function framedRegion(k: Key): string {
  const c = framedPoint(k);
  if (c.x < -0.5 || c.x > 1.5 || c.y < -0.5 || c.y > 1.5) return 'off-scene';
  // A near-1x camera isn't really "on" anything — it's holding the whole frame.
  if (k.scale < 1.15) return 'whole frame';
  const vis: Rect = visibleRect(k);
  const visArea = Math.max(1e-6, (vis[2] - vis[0]) * (vis[3] - vis[1]));

  let best = {label: 'whole frame', score: 0};
  for (const r of REGIONS) {
    const w = Math.max(0, Math.min(vis[2], r.rect[2]) - Math.max(vis[0], r.rect[0]));
    const h = Math.max(0, Math.min(vis[3], r.rect[3]) - Math.max(vis[1], r.rect[1]));
    const inter = w * h;
    if (!inter) continue;
    const regionArea = (r.rect[2] - r.rect[0]) * (r.rect[3] - r.rect[1]);
    const score = (inter / regionArea) * (inter / visArea);
    if (score > best.score) best = {label: r.label, score};
  }
  return best.label;
}

/**
 * Where the shot sits, in words, for a scene the tool can't read. Position only
 * — that a wide shot reaches past the reference is said by the warning chip and
 * by the prompt's own note, and a third copy here just made every label wrap.
 */
function framedPosition(k: Key): string {
  if (k.scale < 1.15 && !showsPastScene(k)) return 'the same framing';
  const c = framedPoint(k);
  const row = c.y < 0.4 ? 'upper' : c.y > 0.6 ? 'lower' : '';
  const col = c.x < 0.4 ? 'left' : c.x > 0.6 ? 'right' : '';
  return [row, col].filter(Boolean).join(' ') || 'centre';
}

const framedLabel = (k: Key, hasShot: boolean) =>
  hasShot ? framedPosition(k) : framedRegion(k);

const transformOf = (k: Pick<Key, 'x' | 'y' | 'scale' | 'rotate'>) =>
  `translate(${round(k.x, 1)}%, ${round(k.y, 1)}%) rotate(${round(k.rotate, 1)}deg) scale(${round(
    k.scale,
    3,
  )})`;

const totalDuration = (keys: Key[]) => keys.slice(1).reduce((sum, k) => sum + k.inDuration, 0);

/** Absolute start time of each key, in seconds. */
function keyTimes(keys: Key[]): number[] {
  let acc = 0;
  return keys.map((k, i) => {
    if (i > 0) acc += k.inDuration;
    return acc;
  });
}

/** WAAPI keyframes for the whole move. */
function waapiKeyframes(keys: Key[]): Keyframe[] {
  const total = totalDuration(keys) || 1;
  const times = keyTimes(keys);
  return keys.map((k, i) => ({
    offset: clamp(times[i] / total, 0, 1),
    transform: transformOf(k),
    ...(i < keys.length - 1 ? {easing: EASE_CSS} : {}),
  }));
}

function nextId(keys: Key[]) {
  return keys.reduce((max, k) => Math.max(max, k.id), -1) + 1;
}

/** K1 is always identity — it IS the existing shot, not a shot you author. */
function makeKey(id: number, patch: Partial<Key> = {}): Key {
  return {id, x: 0, y: 0, scale: 1, rotate: 0, inDuration: 1.2, ...patch};
}

/**
 * Starting points, not scene knowledge. Each one is plain geometry relative to
 * the shot you already have, so they still mean the same thing after the scene
 * behind them changes. K1 is identity in every one of them, by definition.
 */
const PRESETS: {label: string; build: () => Key[]}[] = [
  {label: 'Push in', build: () => [makeKey(0), makeKey(1, {scale: 1.6, inDuration: 1.2})]},
  {label: 'Pull back', build: () => [makeKey(0), makeKey(1, {scale: 0.75, inDuration: 1.2})]},
  {
    label: 'Pan right',
    build: () => [makeKey(0), makeKey(1, {x: -18, scale: 1.4, inDuration: 1.4})],
  },
];

/* ------------------------------------------------------------------ prose */

/** One leg, in plain English — the half of the spec a human actually reads. */
function describeLeg(a: Key, b: Key, hasShot: boolean): string {
  const parts: string[] = [];
  const dScale = b.scale - a.scale;
  if (Math.abs(dScale) > 0.02) {
    parts.push(
      `${dScale > 0 ? 'push in' : 'pull out'} ${a.scale.toFixed(2)}x -> ${b.scale.toFixed(2)}x`,
    );
  }
  // Camera language is the inverse of the scene transform.
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const dirs: string[] = [];
  if (Math.abs(dx) > 1) dirs.push(dx > 0 ? 'left' : 'right');
  if (Math.abs(dy) > 1) dirs.push(dy > 0 ? 'up' : 'down');
  if (dirs.length) parts.push(`camera moves ${dirs.join(' and ')}`);
  const dRot = b.rotate - a.rotate;
  if (Math.abs(dRot) > 0.5) {
    parts.push(
      `camera rolls ${dRot > 0 ? 'counter-clockwise' : 'clockwise'} ${Math.abs(dRot).toFixed(1)}deg`,
    );
  }
  if (!parts.length) parts.push('holds still');
  const sentence = parts.join(', ');
  const on = framedLabel(b, hasShot).toLowerCase();
  const ending = on === 'the same framing' ? '' : `, ending on the ${on}`;
  return `${sentence.charAt(0).toUpperCase()}${sentence.slice(1)}${ending} — ${b.inDuration.toFixed(
    2,
  )}s.`;
}

function buildPrompt(keys: Key[], hasShot: boolean): string {
  const total = totalDuration(keys);
  const times = keyTimes(keys);
  const L: string[] = [];

  L.push(`CAMERA MOVE — ${keys.length} keyframes, ${total.toFixed(2)}s total`);
  if (hasShot) {
    L.push('Authored against a screenshot of the frame this move starts on.');
  }
  L.push('');
  L.push('WHAT K1 IS — READ THIS FIRST');
  L.push('  K1 is not a reset, and not "scale 1 at the origin". It is the shot exactly as it');
  L.push('  already stands at the frame this move begins on, including any pan, zoom or roll');
  L.push('  your existing animation has applied by then. Every number below is RELATIVE to');
  L.push('  that shot: at t=0 this move contributes nothing at all.');
  L.push('');
  L.push('WHAT HAPPENS');
  keys.slice(1).forEach((k, i) => L.push(`  ${i + 1}. ${describeLeg(keys[i], k, hasShot)}`));
  L.push('');
  L.push('HOW TO BUILD IT');
  L.push('  Add ONE new wrapper around the scene you already have and put this move on it.');
  L.push('  Do not edit, reset or replace the transform that is already there — nesting is');
  L.push('  what makes the existing motion and this move compose:');
  L.push('');
  L.push('    <div class="camera-move">      <!-- new: carries only the move below -->');
  L.push('      ... your existing scene, untouched, with all the motion it already has ...');
  L.push('    </div>');
  L.push('');
  L.push('    .camera-move {');
  L.push('      transform-origin: 50% 50%;');
  L.push('      transform: translate(x%, y%) rotate(<rotate>deg) scale(<scale>);');
  L.push('    }');
  L.push('');
  L.push('  Function order is fixed: translate, then rotate, then scale.');
  L.push('  x and y are percentages of the wrapper\'s own box (= the visible frame), so the');
  L.push('  move is resolution-independent, and the trailing scale() never multiplies them.');
  L.push('  Values describe the SCENE. The camera reads inverted: scene right = camera pans');
  L.push('  left, scene down = camera tilts up. Nothing else is animated.');
  L.push(`  Every leg eases with ${EASE_CSS} — the same curve throughout, no exceptions.`);
  L.push('');
  L.push('KEYFRAMES — all relative to K1');
  keys.forEach((k, i) => {
    if (i > 0) L.push(`      | ${k.inDuration.toFixed(2)}s`);
    const note = i === 0 ? 'the existing shot, unchanged' : `framed on: ${framedLabel(k, hasShot)}`;
    L.push(`  t=${times[i].toFixed(2)}s  K${i + 1}  ${transformOf(k)}   ${note}`);
  });
  if (keys.some(showsPastScene)) {
    L.push('');
    L.push('  Note: this move reaches outside the reference screenshot. That is intentional');
    L.push('  when the existing shot is already pushed in — the extra area is scene the');
    L.push('  reference frame was cropping, not empty space.');
  }
  L.push('');
  L.push('CSS — the same move, unambiguously');
  L.push(
    buildCss(keys)
      .split('\n')
      .map((l) => `  ${l}`)
      .join('\n'),
  );
  return L.join('\n');
}

function buildCss(keys: Key[]): string {
  const total = totalDuration(keys) || 1;
  const times = keyTimes(keys);
  const stops = keys
    .map((k, i) => {
      const pct = round((times[i] / total) * 100, 2);
      const timing = i < keys.length - 1 ? `\n    animation-timing-function: ${EASE_CSS};` : '';
      return `  ${pct}% {${timing}\n    transform: ${transformOf(k)};\n  }`;
    })
    .join('\n');
  return [
    '/* The new wrapper. Everything it contains keeps whatever it already did. */',
    '.camera-move {',
    '  transform-origin: 50% 50%;',
    `  animation: camera-move ${total.toFixed(2)}s both;`,
    '}',
    '',
    "/* A stop's animation-timing-function eases the interval that FOLLOWS it. */",
    '@keyframes camera-move {',
    stops,
    '}',
  ].join('\n');
}

/* ------------------------------------------------------------------ stage */

function Stage({
  keys,
  activeIndex,
  shot,
  locked,
  onDrag,
  onZoom,
  onDropFile,
  registerScene,
}: {
  keys: Key[];
  activeIndex: number;
  shot: Shot | null;
  locked: boolean;
  onDrag: (delta: Vec) => void;
  onZoom: (factor: number) => void;
  onDropFile: (file: File) => void;
  registerScene: (el: HTMLDivElement | null) => void;
}) {
  const stageRef = useRef<HTMLDivElement>(null);
  const frameRef = useRef<HTMLDivElement>(null);
  const drag = useRef<{px: number; py: number} | null>(null);
  const [dropping, setDropping] = useState(false);
  const active = keys[activeIndex];
  const transform = transformOf(active);

  // The built-in page lays out at its natural size and is scaled to COVER the
  // frame. Measured rather than expressed in CSS because container units can't
  // produce a unitless scale() factor. A screenshot uses object-fit instead.
  useEffect(() => {
    const stage = stageRef.current;
    const frame = frameRef.current;
    if (!stage || !frame) return;
    const sync = () => {
      const r = frame.getBoundingClientRect();
      stage.style.setProperty('--zm-cam-k', String(Math.max(r.width / PAGE_W, r.height / PAGE_H)));
    };
    sync();
    const ro = new ResizeObserver(sync);
    ro.observe(frame);
    return () => ro.disconnect();
  }, []);

  useEffect(() => {
    const move = (e: PointerEvent | MouseEvent) => {
      const start = drag.current;
      const frame = frameRef.current;
      if (!start || !frame) return;
      const rect = frame.getBoundingClientRect();
      // Pixels -> % of frame, so a drag maps 1:1 onto the emitted numbers.
      onDrag({
        x: ((e.clientX - start.px) / rect.width) * 100,
        y: ((e.clientY - start.py) / rect.height) * 100,
      });
      drag.current = {px: e.clientX, py: e.clientY};
    };
    const up = () => {
      drag.current = null;
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    // A cancelled pointer (interrupted touch, gesture takeover) never sends
    // pointerup — without this the scene would stay glued to the cursor.
    window.addEventListener('pointercancel', up);
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
      window.removeEventListener('pointercancel', up);
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [onDrag]);

  // Wheel-to-zoom needs a non-passive listener to suppress page scroll, which
  // React's synthetic onWheel can't guarantee.
  useEffect(() => {
    const frame = frameRef.current;
    if (!frame) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      onZoom(Math.exp(-e.deltaY / 400));
    };
    frame.addEventListener('wheel', onWheel, {passive: false});
    return () => frame.removeEventListener('wheel', onWheel);
  }, [onZoom]);

  const startDrag = (e: React.PointerEvent | React.MouseEvent) => {
    if (locked) return;
    e.preventDefault();
    drag.current = {px: e.clientX, py: e.clientY};
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDropping(false);
    const file = Array.from(e.dataTransfer.files).find((f) => f.type.startsWith('image/'));
    if (file) onDropFile(file);
  };

  return (
    <div
      className={`zm-cam-stage${dropping ? ' is-dropping' : ''}`}
      ref={stageRef}
      onDragOver={(e) => {
        e.preventDefault();
        setDropping(true);
      }}
      onDragLeave={() => setDropping(false)}
      onDrop={onDrop}
    >
      <SceneSprite />

      <div
        className={`zm-cam-frame${locked ? ' is-locked' : ''}`}
        ref={frameRef}
        onPointerDown={startDrag}
        onMouseDown={startDrag}
        style={{touchAction: 'none'}}
      >
        <div className="zm-cam-scene" style={{transform}} ref={registerScene}>
          <Scene shot={shot} />
        </div>
      </div>

      {/* Furniture sits above the scene and never intercepts the drag. */}
      <div className="zm-cam-overlay">
        <span className="zm-cam-overlay__label">
          K{activeIndex + 1} · {active.scale.toFixed(2)}x ·{' '}
          {activeIndex === 0 ? 'the shot as it is' : framedLabel(active, !!shot)}
        </span>
        {showsPastScene(active) ? (
          <span className="zm-cam-overlay__warn">
            reaches past the reference — fine if your shot is already pushed in
          </span>
        ) : null}
      </div>

      {dropping ? <div className="zm-cam-drop">Drop the screenshot</div> : null}
    </div>
  );
}

/* ----------------------------------------------------------------- editor */

function Slider({
  label,
  value,
  min,
  max,
  step,
  suffix,
  onChange,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  suffix: string;
  onChange: (v: number) => void;
}) {
  return (
    <div className="zm-cam-slider">
      <span className="zm-cam-slider__label">{label}</span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="zm-ease-slider"
      />
      <span className="zm-cam-slider__value">
        {step < 0.1 ? value.toFixed(2) : value.toFixed(1)}
        {suffix}
      </span>
    </div>
  );
}

export function CameraEditor() {
  const [keys, setKeys] = useState<Key[]>(() => PRESETS[0].build());
  // Opens on K1 so the first thing you read is what K1 means. Applying a preset
  // moves to K2, which is the keyframe you can actually edit.
  const [activeIndex, setActiveIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [copied, setCopied] = useState(false);

  const {shot, loadShot, clearShot} = useShot();
  const sceneRef = useRef<HTMLDivElement | null>(null);
  const animsRef = useRef<Animation[]>([]);

  const active = keys[activeIndex];
  const total = totalDuration(keys);
  // K1 is the shot you already have, so there is nothing on it to edit.
  const locked = activeIndex === 0;

  const output = useMemo(() => buildPrompt(keys, !!shot), [keys, shot]);

  const stop = useCallback(() => {
    animsRef.current.forEach((a) => {
      a.onfinish = null;
      a.cancel();
    });
    animsRef.current = [];
    setPlaying(false);
  }, []);

  // A filling-forwards animation outlives the element otherwise; every edit
  // path calls stop() itself, this only covers unmount.
  useEffect(() => stop, [stop]);

  const registerScene = useCallback((el: HTMLDivElement | null) => {
    sceneRef.current = el;
  }, []);

  const play = useCallback(() => {
    stop();
    const el = sceneRef.current;
    if (!el) return;
    const anim = el.animate(waapiKeyframes(keys), {
      duration: Math.max(1, total * 1000),
      fill: 'forwards',
    });
    animsRef.current = [anim];
    setPlaying(true);
    // Land on the last key so the static view after playback matches the final
    // frame — no snap back to whatever was being edited.
    anim.onfinish = () => {
      setActiveIndex(keys.length - 1);
      stop();
    };
  }, [keys, stop, total]);

  const updateActive = useCallback(
    (patch: Partial<Key>) => {
      if (activeIndex === 0) return;
      stop();
      setKeys((ks) => ks.map((k, i) => (i === activeIndex ? {...k, ...patch} : k)));
    },
    [activeIndex, stop],
  );

  const handleDrag = useCallback(
    (delta: Vec) => {
      if (activeIndex === 0) return;
      stop();
      setKeys((ks) =>
        ks.map((k, i) =>
          i === activeIndex
            ? {
                ...k,
                x: clamp(k.x + delta.x, -X_RANGE, X_RANGE),
                y: clamp(k.y + delta.y, -Y_RANGE, Y_RANGE),
              }
            : k,
        ),
      );
    },
    [activeIndex, stop],
  );

  const handleZoom = useCallback(
    (factor: number) => {
      if (activeIndex === 0) return;
      stop();
      setKeys((ks) =>
        ks.map((k, i) => {
          if (i !== activeIndex) return k;
          // Zoom about the frame centre: holding the framed scene point fixed
          // means the translation scales with it. Cap the zoom at the point
          // where that translation would hit its own clamp — otherwise the
          // clamp silently slides the shot onto something else.
          const room = (v: number, limit: number) => (v === 0 ? Infinity : limit / Math.abs(v));
          const maxScale = Math.min(
            SCALE_MAX,
            k.scale * Math.min(room(k.x, X_RANGE), room(k.y, Y_RANGE)),
          );
          const scale = clamp(k.scale * factor, SCALE_MIN, Math.max(SCALE_MIN, maxScale));
          const ratio = scale / k.scale;
          return {...k, scale, x: k.x * ratio, y: k.y * ratio};
        }),
      );
    },
    [activeIndex, stop],
  );

  const addKey = () => {
    if (keys.length >= MAX_KEYS) return;
    stop();
    // Clones the last key, so a new keyframe starts from the current shot.
    setKeys((ks) => [...ks, {...ks[ks.length - 1], id: nextId(ks)}]);
    setActiveIndex(keys.length);
  };

  const removeKey = (idx: number) => {
    if (idx === 0 || keys.length <= MIN_KEYS) return;
    stop();
    setKeys((ks) => ks.filter((_, i) => i !== idx));
    setActiveIndex((i) => (idx <= i ? Math.max(1, i - 1) : i));
  };

  const applyPreset = (build: () => Key[]) => {
    stop();
    setKeys(build());
    setActiveIndex(1);
  };

  const handleCopy = () => {
    const onCopied = () => {
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    };
    navigator.clipboard?.writeText(output).then(onCopied, () => {
      const ta = document.createElement('textarea');
      ta.value = output;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
        onCopied();
      } catch {
        // Clipboard unavailable — the text is on screen and selectable anyway.
      }
      document.body.removeChild(ta);
    });
  };

  return (
    <div className="zm-page">
      <div className="zm-wrap">
        <div className="zm-page-head">
          <div>
            <span className="zm-page-head__idx" style={{color: ACCENT}}>
              Tools — Camera editor
            </span>
            <h1 className="zm-h1" style={{fontSize: 'clamp(32px,4vw,52px)', maxWidth: '20ch'}}>
              Camera move editor
            </h1>
            <p className="zm-lead">
              Paste or drop a screenshot of the frame you're animating from — that becomes K1,
              whatever your camera is already doing there. Drag to pan and scroll to zoom the
              keyframes that follow, then copy a prompt that describes the move relative to it.
            </p>
          </div>
        </div>

        <div className="zm-cam-grid">
          <div className="zm-cam-left">
            <ShotSourceBar shot={shot} onLoad={loadShot} onClear={clearShot} />

            <Stage
              keys={keys}
              activeIndex={activeIndex}
              shot={shot}
              locked={locked}
              onDrag={handleDrag}
              onZoom={handleZoom}
              onDropFile={loadShot}
              registerScene={registerScene}
            />

            <div className="zm-cam-presets">
              {PRESETS.map((p) => (
                <button key={p.label} className="zm-ease-add" onClick={() => applyPreset(p.build)}>
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          <div className="zm-ease-panel">
            <div className="zm-ease-segments">
              {keys.map((k, i) => (
                <button
                  key={k.id}
                  className={`zm-ease-segment${i === activeIndex ? ' is-active' : ''}`}
                  onClick={() => {
                    stop();
                    setActiveIndex(i);
                  }}
                >
                  K{i + 1}
                  {i > 0 && keys.length > MIN_KEYS ? (
                    <span
                      className="zm-ease-segment__remove"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeKey(i);
                      }}
                    >
                      ×
                    </span>
                  ) : null}
                </button>
              ))}
              {keys.length < MAX_KEYS ? (
                <button className="zm-ease-add" onClick={addKey}>
                  + Add keyframe
                </button>
              ) : null}
            </div>

            {locked ? (
              <div className="zm-cam-controls zm-cam-controls--locked">
                <b>K1 is the shot you already have.</b>
                <span>
                  It's whatever your camera is doing at this frame — pan, zoom, roll and all — so
                  there's nothing here to set. Everything you author on K2 onward is emitted
                  relative to it.
                </span>
              </div>
            ) : (
              <div className="zm-cam-controls">
                <Slider
                  label="Pan X"
                  value={active.x}
                  min={-X_RANGE}
                  max={X_RANGE}
                  step={0.5}
                  suffix="%"
                  onChange={(x) => updateActive({x})}
                />
                <Slider
                  label="Pan Y"
                  value={active.y}
                  min={-Y_RANGE}
                  max={Y_RANGE}
                  step={0.5}
                  suffix="%"
                  onChange={(y) => updateActive({y})}
                />
                <Slider
                  label="Scale"
                  value={active.scale}
                  min={SCALE_MIN}
                  max={SCALE_MAX}
                  step={0.01}
                  suffix="x"
                  onChange={(scale) => updateActive({scale})}
                />
                <Slider
                  label="Roll"
                  value={active.rotate}
                  min={-ROTATE_RANGE}
                  max={ROTATE_RANGE}
                  step={0.5}
                  suffix="°"
                  onChange={(rotate) => updateActive({rotate})}
                />
                <div className="zm-cam-row">
                  <span className="zm-cam-slider__label">Ends on</span>
                  <span className="zm-cam-readout">{framedLabel(active, !!shot)}</span>
                  <button
                    className="zm-cam-reset"
                    onClick={() => updateActive({x: 0, y: 0, scale: 1, rotate: 0})}
                  >
                    Match K1
                  </button>
                </div>
              </div>
            )}

            <div className="zm-cam-leg">
              <span className="zm-eyebrow">
                Leg K{Math.max(1, activeIndex)} → K{Math.max(2, activeIndex + 1)}
              </span>
              <Slider
                label="Duration"
                value={keys[Math.max(1, activeIndex)].inDuration}
                min={0.1}
                max={3}
                step={0.1}
                suffix="s"
                onChange={(inDuration) =>
                  setKeys((ks) => {
                    stop();
                    const at = Math.max(1, activeIndex);
                    return ks.map((k, i) => (i === at ? {...k, inDuration} : k));
                  })
                }
              />
              <div className="zm-cam-row zm-cam-leg__note">
                Eases with {EASE_CSS}, like every other leg.
              </div>
            </div>

            <div className="zm-ease-go-row">
              <button className="zm-btn zm-btn--primary zm-ease-go" onClick={playing ? stop : play}>
                {playing ? 'STOP' : 'PLAY'}
              </button>
              <span className="zm-ease-total">
                {keys.length} keyframes · {total.toFixed(2)}s total
              </span>
            </div>
          </div>
        </div>

        <div className="zm-cam-output">
          <div className="zm-cam-output__head">
            <span className="zm-eyebrow">Prompt — paste this to an LLM</span>
            <button className="zm-btn zm-btn--ghost zm-ease-copy" onClick={handleCopy}>
              {copied ? 'Copied' : 'Copy'}
            </button>
          </div>
          <pre className="zm-cam-output__body">{output}</pre>
        </div>
      </div>
    </div>
  );
}
