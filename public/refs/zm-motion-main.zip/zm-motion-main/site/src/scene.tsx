// Shared backdrop for the authoring tools: the thing you point a camera at, or
// lay objects on top of. Both the camera editor and the object editor need the
// same three things — a user-supplied screenshot, a built-in fallback so the
// tool works cold, and names for the parts of that fallback — so they live here
// rather than in two copies that drift.
import React, {useCallback, useEffect, useRef, useState} from 'react';
import {ZOOM_PROFILE_HTML, ZOOM_SPRITE} from './zoomProfileScene';

/** A user-supplied screenshot standing in for the frame they're working from. */
export type Shot = {url: string; name: string};

/** Normalized rect in scene space: [x0, y0, x1, y1], each 0..1. */
export type Rect = [number, number, number, number];

/**
 * Named regions of the BUILT-IN scene, measured off the rendered page rather
 * than eyeballed. They let a tool say "over the sidebar" instead of "at 11%,
 * 54%". A user screenshot gets positional language instead — nothing here can
 * know what's in someone else's image.
 */
export const REGIONS: {id: string; label: string; rect: Rect}[] = [
  {id: 'header', label: 'Header', rect: [0, 0, 1, 0.085]},
  {id: 'sidebar', label: 'Sidebar', rect: [0, 0.085, 0.221, 1]},
  {id: 'banner', label: 'Privacy notice', rect: [0.221, 0.1, 1, 0.3]},
  {id: 'photo', label: 'Profile photo', rect: [0.245, 0.317, 0.338, 0.485]},
  {id: 'profile', label: 'Profile card', rect: [0.221, 0.3, 1, 0.72]},
  {id: 'personal', label: 'Personal information', rect: [0.221, 0.72, 1, 1]},
];

export const intersectionArea = (a: Rect, b: Rect) =>
  Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0])) *
  Math.max(0, Math.min(a[3], b[3]) - Math.max(a[1], b[1]));

/**
 * What a small thing is sitting ON. Scored by the share of the THING that each
 * region covers — the question for an object is "what is underneath me", not
 * "how much of that region can I see", which is the camera's question.
 */
export function regionUnder(rect: Rect): string | null {
  const area = Math.max(1e-6, (rect[2] - rect[0]) * (rect[3] - rect[1]));
  let best: {label: string; share: number} | null = null;
  for (const r of REGIONS) {
    const share = intersectionArea(rect, r.rect) / area;
    if (share > 0.4 && (!best || share > best.share)) best = {label: r.label, share};
  }
  return best ? best.label : null;
}

/**
 * What the camera is pointed at: the user's screenshot when they've given one,
 * otherwise a built-in Zoom page. Both fill a 16:9 frame — screenshots arrive
 * near-16:9 already, so `cover` crops a hair at most.
 */
export function Scene({shot}: {shot: Shot | null}) {
  if (shot) return <img className="zm-cam-shot" src={shot.url} alt="" draggable={false} />;
  return <div className="zm-cam-page" dangerouslySetInnerHTML={{__html: ZOOM_PROFILE_HTML}} />;
}

/** The icon sprite the built-in page references. One per stage is enough —
 *  `use href="#id"` resolves document-wide. Hidden by its own 0x0 absolute svg,
 *  NOT display:none, which can stop some browsers resolving into the subtree. */
export function SceneSprite() {
  return <div dangerouslySetInnerHTML={{__html: ZOOM_SPRITE}} />;
}

/**
 * Screenshot plumbing: upload, drop, and paste-anywhere, plus the object-URL
 * lifecycle. Revokes the old URL on replace and the last one on unmount, or a
 * session of trying screenshots leaks every one of them.
 */
export function useShot() {
  const [shot, setShot] = useState<Shot | null>(null);
  const shotRef = useRef<Shot | null>(null);
  shotRef.current = shot;

  const loadShot = useCallback((file: File) => {
    if (!file.type.startsWith('image/')) return;
    const url = URL.createObjectURL(file);
    setShot((prev) => {
      if (prev) URL.revokeObjectURL(prev.url);
      return {url, name: file.name || 'pasted image'};
    });
  }, []);

  const clearShot = useCallback(() => {
    setShot((prev) => {
      if (prev) URL.revokeObjectURL(prev.url);
      return null;
    });
  }, []);

  useEffect(
    () => () => {
      if (shotRef.current) URL.revokeObjectURL(shotRef.current.url);
    },
    [],
  );

  // Paste anywhere on the page — the most common way a screenshot arrives.
  // Ignored while a text field has focus so it can't hijack a normal paste.
  useEffect(() => {
    const onPaste = (e: ClipboardEvent) => {
      const el = document.activeElement as HTMLInputElement | null;
      if (el && /^(INPUT|TEXTAREA)$/.test(el.tagName) && el.type !== 'range') return;
      const file = Array.from(e.clipboardData?.files ?? []).find((f) =>
        f.type.startsWith('image/'),
      );
      if (!file) return;
      e.preventDefault();
      loadShot(file);
    };
    window.addEventListener('paste', onPaste);
    return () => window.removeEventListener('paste', onPaste);
  }, [loadShot]);

  return {shot, loadShot, clearShot};
}

/** The "where does the backdrop come from" strip both tools put above the stage. */
export function ShotSourceBar({
  shot,
  onLoad,
  onClear,
}: {
  shot: Shot | null;
  onLoad: (file: File) => void;
  onClear: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  return (
    <div className="zm-cam-source">
      <span className="zm-cam-source__name">{shot ? shot.name : 'Built-in Zoom profile page'}</span>
      <input
        ref={fileRef}
        type="file"
        accept="image/*"
        style={{display: 'none'}}
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) onLoad(file);
          e.target.value = ''; // so the same file can be picked twice
        }}
      />
      <button className="zm-cam-reset" onClick={() => fileRef.current?.click()}>
        Upload screenshot
      </button>
      {shot ? (
        <button className="zm-cam-reset" onClick={onClear}>
          Use built-in
        </button>
      ) : (
        <span className="zm-cam-source__hint">or paste / drop one anywhere</span>
      )}
    </div>
  );
}
