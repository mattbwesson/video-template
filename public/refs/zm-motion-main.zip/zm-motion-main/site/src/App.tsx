import React, {useEffect, useRef} from 'react';
import {
  CATEGORIES,
  entriesByCategory,
  FPS_DEFAULT,
  INTENSITY_ROW_ENTRIES,
  type AnimationEntry,
  type Category,
  type CategoryId,
} from './registry';
import {AnimationPreview} from './AnimationPreview';
import {HomePage} from './HomePage';
import {EasingEditor} from './EasingEditor';
import {CameraEditor} from './CameraEditor';
import {ObjectEditor} from './ObjectEditor';
import {useHashRoute, type Route} from './useHashRoute';

function AnimationTile({entry}: {entry: AnimationEntry}) {
  const fps = entry.fps ?? FPS_DEFAULT;
  const duration = entry.durationInFrames ?? 90;
  const seconds = (duration / fps).toFixed(1);
  return (
    <article className="zm-tile">
      <AnimationPreview entry={entry} />
      <div className="zm-tile__foot">
        <div style={{minWidth: 0}}>
          <div className="zm-tile__name">{entry.name}</div>
          <div className="zm-tile__id">{entry.id}</div>
        </div>
        <span className="zm-tile__time">{seconds}s</span>
      </div>
    </article>
  );
}

// Match-cut intensity comparison: three looping rows (hard/medium/soft), each the same
// directional match cut traveling left -> right then back, only `intensity` changes between
// them — so the size of the excised cut is the one visible difference, side by side.
function IntensityShowcase() {
  return (
    <div className="zm-intensity">
      <span className="zm-eyebrow">Match cut intensity</span>
      <p className="zm-lead" style={{margin: '4px 0 0', maxWidth: '70ch'}}>
        Every match-cut preset takes an <code>intensity</code> — how much of the transition gets
        skipped. Always an instant jump, never an animated pass through the skipped band.
      </p>
      <div className="zm-intensity__rows">
        {INTENSITY_ROW_ENTRIES.map((entry) => (
          <div className="zm-intensity-row" key={entry.id}>
            <div className="zm-intensity-row__info">
              <div className="zm-intensity-row__label">{entry.name}</div>
              <div className="zm-intensity-row__blurb">{entry.blurb}</div>
            </div>
            <AnimationPreview entry={entry} autoPlay className="zm-intensity-row__preview" />
          </div>
        ))}
      </div>
    </div>
  );
}

function CategoryPage({category}: {category: Category}) {
  const entries = entriesByCategory(category.id);
  return (
    <div className="zm-page">
      <div className="zm-wrap">
        <div className="zm-page-head">
          <div>
            <span className="zm-page-head__idx" style={{color: category.accent}}>
              {category.index} — {category.label}
            </span>
            <h1 className="zm-h1" style={{fontSize: 'clamp(32px,4vw,52px)', maxWidth: '20ch'}}>
              {category.label}
            </h1>
            <p className="zm-lead">{category.blurb}</p>
          </div>
          <span className="zm-tile__time" style={{fontSize: 13}}>
            {entries.length} presets
          </span>
        </div>
        {category.id === 'transition' ? <IntensityShowcase /> : null}
        <div className="zm-grid">
          {entries.map((entry) => (
            <AnimationTile key={entry.id} entry={entry} />
          ))}
        </div>
        <Footer />
      </div>
    </div>
  );
}

export function Footer() {
  return (
    <footer className="zm-foot">
      Previews render the actual library components frame-by-frame with the Remotion
      Player. Built with the Astryx design system · <code>github:mattbwesson/zm-motion</code>
    </footer>
  );
}

function Sidebar({route, navigate}: {route: Route; navigate: (r: Route) => void}) {
  return (
    <aside className="zm-sidebar">
      <a className="zm-brand" href="#" onClick={() => navigate('home')}>
        <span className="zm-brand__mark" />
        <span style={{display: 'flex', flexDirection: 'column', lineHeight: 1.25}}>
          <span className="zm-brand__name">zm-motion</span>
          <span className="zm-brand__sub">Zoom Motion</span>
        </span>
      </a>

      <nav className="zm-nav">
        <button
          className={`zm-nav__item${route === 'home' ? ' is-active' : ''}`}
          onClick={() => navigate('home')}
        >
          <span className="zm-nav__dot" />
          Home
        </button>

        <span className="zm-nav__label">Library</span>
        {CATEGORIES.map((c) => (
          <button
            key={c.id}
            className={`zm-nav__item${route === c.id ? ' is-active' : ''}`}
            onClick={() => navigate(c.id)}
            style={route === c.id ? {color: '#fff'} : undefined}
          >
            <span className="zm-nav__dot" style={{color: c.accent}} />
            {c.label}
            <span className="zm-nav__count">{entriesByCategory(c.id).length}</span>
          </button>
        ))}

        <span className="zm-nav__label">Tools</span>
        <button
          className={`zm-nav__item${route === 'easing' ? ' is-active' : ''}`}
          onClick={() => navigate('easing')}
          style={route === 'easing' ? {color: '#fff'} : undefined}
        >
          <span className="zm-nav__dot" style={{color: '#22d3ee'}} />
          Easing editor
        </button>
        <button
          className={`zm-nav__item${route === 'camera' ? ' is-active' : ''}`}
          onClick={() => navigate('camera')}
          style={route === 'camera' ? {color: '#fff'} : undefined}
        >
          <span className="zm-nav__dot" style={{color: '#c9f24d'}} />
          Camera editor
        </button>
        <button
          className={`zm-nav__item${route === 'objects' ? ' is-active' : ''}`}
          onClick={() => navigate('objects')}
          style={route === 'objects' ? {color: '#fff'} : undefined}
        >
          <span className="zm-nav__dot" style={{color: '#f43f5e'}} />
          Object editor
        </button>
      </nav>

      <div className="zm-sidebar__foot">
        <a
          className="zm-sidebar__link"
          href="https://github.com/mattbwesson/zm-motion"
          target="_blank"
          rel="noreferrer"
        >
          ↗ GitHub repository
        </a>
        <span className="zm-sidebar__meta">Remotion · React · Astryx</span>
      </div>
    </aside>
  );
}

function MobileTopbar({route, navigate}: {route: Route; navigate: (r: Route) => void}) {
  return (
    <div className="zm-topbar">
      <button
        className={`zm-topbar__chip${route === 'home' ? ' is-active' : ''}`}
        onClick={() => navigate('home')}
      >
        zm-motion
      </button>
      {CATEGORIES.map((c) => (
        <button
          key={c.id}
          className={`zm-topbar__chip${route === c.id ? ' is-active' : ''}`}
          onClick={() => navigate(c.id)}
        >
          {c.label}
        </button>
      ))}
      <button
        className={`zm-topbar__chip${route === 'easing' ? ' is-active' : ''}`}
        onClick={() => navigate('easing')}
      >
        Easing editor
      </button>
      <button
        className={`zm-topbar__chip${route === 'camera' ? ' is-active' : ''}`}
        onClick={() => navigate('camera')}
      >
        Camera editor
      </button>
      <button
        className={`zm-topbar__chip${route === 'objects' ? ' is-active' : ''}`}
        onClick={() => navigate('objects')}
      >
        Object editor
      </button>
    </div>
  );
}

export function App() {
  const [route, navigate] = useHashRoute();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({top: 0});
    window.scrollTo({top: 0});
  }, [route]);

  const category = CATEGORIES.find((c) => c.id === route) as Category | undefined;

  return (
    <div className="zm-shell">
      <Sidebar route={route} navigate={navigate} />
      <main className="zm-main" ref={scrollRef}>
        <MobileTopbar route={route} navigate={navigate} />
        {route === 'easing' ? (
          <EasingEditor />
        ) : route === 'camera' ? (
          <CameraEditor />
        ) : route === 'objects' ? (
          <ObjectEditor />
        ) : route === 'home' || !category ? (
          <HomePage navigate={navigate} />
        ) : (
          <CategoryPage key={category.id} category={category} />
        )}
      </main>
    </div>
  );
}
