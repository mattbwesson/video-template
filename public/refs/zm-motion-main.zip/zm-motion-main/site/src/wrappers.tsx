// Preview wrappers.
//
// Many zm-motion primitives don't animate on their own — the shadcn-style UI
// components are STATE-DRIVEN: you pass them either a discrete `state` (static)
// or an animated `style` object produced by their sibling `use-*-transition`
// hook. These wrappers wire each one to a looping frame-driven schedule so the
// gallery can show a live preview. Transition presentations (whipPan/pushThrough)
// are staged inside a <TransitionSeries>. All wrappers take no props (everything
// is baked in) so the registry can hand them straight to <Player>.

import React from 'react';
import {
  AbsoluteFill,
  Easing,
  interpolate,
  Sequence,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {
  TransitionSeries,
  linearTiming,
  type TransitionPresentation,
} from '@remotion/transitions';
import type {Step} from './motion/lib';

// primitives
import {Button} from './motion/button';
import {Input} from './motion/input';
import {Switch} from './motion/switch';
import {Slider} from './motion/slider';
import {Progress} from './motion/progress';
import {Toast} from './motion/toast';
import {Tabs} from './motion/tabs';
import {Accordion} from './motion/accordion';
import {Stepper} from './motion/stepper';
import {Sheet} from './motion/sheet';
import {Select} from './motion/select';
import {SelectItem} from './motion/select-item';
import {DropdownMenu} from './motion/dropdown-menu';
import {DropdownMenuItem} from './motion/dropdown-menu-item';
import {CommandMenu} from './motion/command-menu';
import {CommandMenuItem} from './motion/command-menu-item';
import {MessageBubble} from './motion/message-bubble';
import {Resizable} from './motion/resizable';
import {Cursor} from './motion/cursor';
import {Backdrop} from './motion/backdrop';
import {RippleDotGrid} from './motion/orbit-animation/RippleDotGrid';
import {ZoomMeetingScene} from './motion/zoom-meeting';
import {whipPan} from './motion/whip-pan';
import {pushThrough} from './motion/push-through';
import {SparkleMaskOutro} from './motion/sparkle-mask-outro';
import {SilkySmooth, silkySmoothDuration} from './motion/silky-smooth';
import {ZoomMateSimple, zoomMateSimpleDuration} from './motion/zoommate-simple';
import {ZoomMateFull, zoomMateFullDuration} from './motion/zoommate-full';
import {MessageDockReveal, messageDockRevealDuration} from './motion/message-dock-reveal';
import {CtaPills, ctaPillsDuration} from './motion/cta-pills';
import {DashboardNavZoom, dashboardNavZoomDuration} from './motion/dashboard-nav-zoom';
import {MatchCut} from './motion/match-cut';
import {TypewriterTrackingMatchCut} from './motion/typewriter-tracking-match-cut';

// transition hooks
import {useButtonTransition} from './motion/use-button-transition';
import {useInputTransition} from './motion/use-input-transition';
import {useSwitchTransition} from './motion/use-switch-transition';
import {useSliderTransition} from './motion/use-slider-transition';
import {useProgressTransition} from './motion/use-progress-transition';
import {useToastTransition} from './motion/use-toast-transition';
import {useTabsTransition} from './motion/use-tabs-transition';
import {useAccordionTransition} from './motion/use-accordion-transition';
import {useStepperTransition} from './motion/use-stepper-transition';
import {useSheetTransition} from './motion/use-sheet-transition';
import {useSelectTransition} from './motion/use-select-transition';
import {useSelectItemTransition} from './motion/use-select-item-transition';
import {useDropdownMenuTransition} from './motion/use-dropdown-menu-transition';
import {useDropdownMenuItemTransition} from './motion/use-dropdown-menu-item-transition';
import {useCommandMenuTransition} from './motion/use-command-menu-transition';
import {useCommandMenuItemTransition} from './motion/use-command-menu-item-transition';
import {useMessageBubbleTransition} from './motion/use-message-bubble-transition';
import {useCursorPath} from './motion/use-cursor-path';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

// Centers in-flow (inline / inline-flex) previews. Filler components that are
// already position:absolute self-center regardless.
function Center({
  children,
  background = 'transparent',
}: {
  children: React.ReactNode;
  background?: string;
}) {
  return (
    <AbsoluteFill
      style={{
        alignItems: 'center',
        justifyContent: 'center',
        background,
      }}
    >
      {children}
    </AbsoluteFill>
  );
}

// ---------------------------------------------------------------------------
// UI components — state-machine driven (Step<State>[])
// ---------------------------------------------------------------------------

export const ButtonDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'idle'},
    {at: 18, state: 'hover'},
    {at: 34, state: 'press'},
    {at: 46, state: 'loading'},
    {at: 96, state: 'success'},
    {at: 140, state: 'idle'},
  ];
  const style = useButtonTransition(steps, {variant: 'default'});
  return <Button label="Continue" style={style} />;
};

export const InputDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'idle'},
    {at: 16, state: 'hover'},
    {at: 28, state: 'active'},
    {at: 40, state: 'typing'},
    {at: 150, state: 'blur'},
    {at: 168, state: 'idle'},
  ];
  const style = useInputTransition(steps, {});
  return <Input style={style} value="hello@remotion.dev" fullWidth={false} />;
};

export const SwitchDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'unchecked'},
    {at: 24, state: 'checked'},
    {at: 78, state: 'unchecked'},
  ];
  const style = useSwitchTransition(steps, {});
  return <Switch style={style} label="Enable notifications" />;
};

export const ToastDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'hidden'},
    {at: 12, state: 'visible'},
    {at: 96, state: 'hidden'},
  ];
  const style = useToastTransition(steps, {});
  return (
    <Center>
      <Toast
        style={style}
        title="Changes saved"
        description="Your profile has been updated."
        variant="success"
      />
    </Center>
  );
};

export const AccordionDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'closed'},
    {at: 20, state: 'opened'},
    {at: 90, state: 'closed'},
  ];
  const style = useAccordionTransition(steps, {});
  return <Accordion style={style} />;
};

export const SheetDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'closed'},
    {at: 16, state: 'opened'},
    {at: 108, state: 'closed'},
  ];
  const style = useSheetTransition(steps, {});
  return <Sheet style={style} />;
};

export const TabsDemo: React.FC = () => {
  const items = ['Account', 'Password', 'Settings'];
  const steps: Step<string>[] = [
    {at: 0, state: items[0]},
    {at: 28, state: items[1]},
    {at: 60, state: items[2]},
    {at: 96, state: items[0]},
  ];
  const style = useTabsTransition(steps, {items});
  const frame = useCurrentFrame();
  // Discrete active tab for the panel cross-fade.
  const active =
    frame >= 96 ? items[0] : frame >= 60 ? items[2] : frame >= 28 ? items[1] : items[0];
  return <Tabs state={active} style={style} items={items} />;
};

// ---------------------------------------------------------------------------
// UI components — value / index driven (custom Step types)
// ---------------------------------------------------------------------------

export const SliderDemo: React.FC = () => {
  const style = useSliderTransition(
    [
      {at: 0, value: 15, thumbState: 'idle'},
      {at: 18, thumbState: 'hover'},
      {at: 26, thumbState: 'press'},
      {at: 30, value: 82, duration: 40},
      {at: 92, thumbState: 'idle'},
      {at: 96, value: 15, duration: 30},
    ],
    {},
  );
  return (
    <Center>
      <Slider style={style} width={360} showValue />
    </Center>
  );
};

export const ProgressDemo: React.FC = () => {
  const style = useProgressTransition(
    [
      {at: 0, value: 0},
      {at: 8, value: 100, duration: 70},
    ],
    {},
  );
  return (
    <Center>
      <Progress style={style} width={360} showLabel />
    </Center>
  );
};

export const StepperDemo: React.FC = () => {
  const style = useStepperTransition(
    [
      {at: 0, index: 0},
      {at: 24, index: 1},
      {at: 60, index: 2},
      {at: 100, index: 0},
    ],
    {},
  );
  return (
    <Center>
      <Stepper style={style} steps={['Account', 'Plan', 'Done']} />
    </Center>
  );
};

export const ResizableDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const ratio = interpolate(
    frame,
    [0, 30, 70, 110],
    [0.5, 0.28, 0.72, 0.5],
    {...clamp, easing: Easing.inOut(Easing.ease)},
  );
  const handleState = frame > 14 && frame < 112 ? 'hover' : 'idle';
  return (
    <Center>
      <Resizable ratio={ratio} handleState={handleState} width={440} height={240} />
    </Center>
  );
};

// ---------------------------------------------------------------------------
// UI components — open/close menus (container style + fixed highlight)
// ---------------------------------------------------------------------------

export const SelectDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'closed'},
    {at: 16, state: 'opened'},
    {at: 110, state: 'closed'},
  ];
  const style = useSelectTransition(steps, {});
  const frame = useCurrentFrame();
  const highlightedIndex = frame < 40 ? 0 : frame < 70 ? 1 : 2;
  return (
    <Select
      style={style}
      selectedIndex={frame > 96 ? 2 : -1}
      highlightedIndex={frame > 20 && frame < 110 ? highlightedIndex : -1}
    />
  );
};

export const DropdownMenuDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'closed'},
    {at: 16, state: 'opened'},
    {at: 110, state: 'closed'},
  ];
  const style = useDropdownMenuTransition(steps, {});
  const frame = useCurrentFrame();
  const highlightedIndex = frame < 45 ? 0 : frame < 72 ? 1 : frame < 96 ? 2 : 3;
  return (
    <DropdownMenu
      style={style}
      highlightedIndex={frame > 20 && frame < 110 ? highlightedIndex : -1}
    />
  );
};

export const CommandMenuDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'closed'},
    {at: 14, state: 'opened'},
    {at: 130, state: 'closed'},
  ];
  const style = useCommandMenuTransition(steps, {});
  const frame = useCurrentFrame();
  const query = 'set'.slice(0, Math.max(0, Math.floor((frame - 30) / 8)));
  const highlightedIndex = frame < 80 ? 0 : 1;
  return (
    <CommandMenu
      style={style}
      query={frame > 26 ? query : ''}
      highlightedIndex={frame > 40 && frame < 128 ? highlightedIndex : -1}
    />
  );
};

// ---------------------------------------------------------------------------
// UI sub-items (idle -> hover -> selected/press)
// ---------------------------------------------------------------------------

export const SelectItemDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'idle'},
    {at: 18, state: 'hover'},
    {at: 40, state: 'press'},
    {at: 52, state: 'selected'},
    {at: 96, state: 'idle'},
  ];
  const style = useSelectItemTransition(steps, {});
  return <SelectItem style={style} label="Banana" />;
};

export const DropdownMenuItemDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'idle'},
    {at: 18, state: 'hover'},
    {at: 46, state: 'press'},
    {at: 60, state: 'idle'},
  ];
  const style = useDropdownMenuItemTransition(steps, {});
  return <DropdownMenuItem style={style} label="Profile" />;
};

export const CommandMenuItemDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'idle'},
    {at: 18, state: 'hover'},
    {at: 46, state: 'selected'},
    {at: 96, state: 'idle'},
  ];
  const style = useCommandMenuItemTransition(steps, {});
  return <CommandMenuItem style={style} label="Settings" icon="settings" shortcut="⌘," />;
};

export const MessageBubbleDemo: React.FC = () => {
  const steps: Step<any>[] = [
    {at: 0, state: 'hidden'},
    {at: 14, state: 'visible'},
  ];
  const style = useMessageBubbleTransition(steps, {});
  return (
    <Center>
      <MessageBubble style={style} variant="outgoing" reaction="❤️">
        See you there!
      </MessageBubble>
    </Center>
  );
};

// ---------------------------------------------------------------------------
// Cursor path (standalone pointer)
// ---------------------------------------------------------------------------

export const CursorDemo: React.FC = () => {
  const style = useCursorPath([
    {at: 0, x: 240, y: 200},
    {at: 30, x: 900, y: 260, click: true},
    {at: 70, x: 640, y: 520, click: true},
    {at: 110, x: 240, y: 200},
  ]);
  return (
    <AbsoluteFill
      style={{
        background:
          'radial-gradient(circle at 50% 40%, #fafafa 0%, #ececf0 100%)',
      }}
    >
      <Cursor variant="pointer" style={style} size={34} />
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------------------
// Backdrop (matte frame around content)
// ---------------------------------------------------------------------------

export const BackdropDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const scale = interpolate(frame, [0, 40], [0.96, 1], {
    ...clamp,
    easing: Easing.out(Easing.cubic),
  });
  return (
    <Backdrop
      fill={{
        type: 'gradient',
        value: 'linear-gradient(135deg, #0ea5e9 0%, #7c3aed 100%)',
      }}
    >
      <AbsoluteFill
        style={{
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <span
          style={{
            fontSize: 72,
            fontWeight: 700,
            color: '#ffffff',
            letterSpacing: '-0.03em',
            transform: `scale(${scale})`,
          }}
        >
          Backdrop
        </span>
      </AbsoluteFill>
    </Backdrop>
  );
};

// ---------------------------------------------------------------------------
// RippleDotGrid (manual frame prop)
// ---------------------------------------------------------------------------

export const RippleDotGridDemo: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: '#04040a'}}>
      <RippleDotGrid frame={frame} fullBleed burst />
    </AbsoluteFill>
  );
};

// ---------------------------------------------------------------------------
// ZoomMeeting (interpolate shareProgress)
// ---------------------------------------------------------------------------

export const ZoomMeetingDemo: React.FC = () => {
  const frame = useCurrentFrame();
  const shareProgress = interpolate(frame, [40, 110], [0, 1], {
    ...clamp,
    easing: Easing.inOut(Easing.ease),
  });
  return (
    <ZoomMeetingScene
      participants={[
        {name: 'Ellana Parker', active: true},
        {name: 'Lianna Mitchell'},
      ]}
      shareProgress={shareProgress}
    />
  );
};

// ---------------------------------------------------------------------------
// Transition presentations (whipPan / pushThrough) staged in a series
// ---------------------------------------------------------------------------

// An inset card, not a full-bleed fill — leaves the preview's backdrop image visible
// around it (a full-bleed panel would paint over the backdrop entirely, which is why
// whip-pan/push-through never showed it before).
function Panel({label, background}: {label: string; background: string}) {
  return (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
      <div
        style={{
          width: '76%',
          height: '76%',
          borderRadius: 28,
          background,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#ffffff',
          fontSize: 80,
          fontWeight: 700,
          letterSpacing: '-0.03em',
          boxShadow: '0 24px 60px -20px rgba(0,0,0,0.55)',
        }}
      >
        {label}
      </div>
    </AbsoluteFill>
  );
}

function makeTransitionDemo(
  presentation: TransitionPresentation<any>,
): React.FC {
  const Demo: React.FC = () => (
    <TransitionSeries>
      <TransitionSeries.Sequence durationInFrames={40}>
        <Panel label="1" background="#7c3aed" />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition
        presentation={presentation}
        timing={linearTiming({durationInFrames: 16})}
      />
      <TransitionSeries.Sequence durationInFrames={40}>
        <Panel label="2" background="#0ea5e9" />
      </TransitionSeries.Sequence>
      <TransitionSeries.Transition
        presentation={presentation}
        timing={linearTiming({durationInFrames: 16})}
      />
      <TransitionSeries.Sequence durationInFrames={40}>
        <Panel label="1" background="#7c3aed" />
      </TransitionSeries.Sequence>
    </TransitionSeries>
  );
  return Demo;
}

export const WhipPanDemo = makeTransitionDemo(whipPan({direction: 'left'}));
export const PushThroughDemo = makeTransitionDemo(pushThrough({}));

// Sparkle mask outro — the numbered panel collapses into the sparkle, which then
// plays its flip and rests. Timings shared with the registry so the preview's
// durationInFrames always matches (use sparkleMaskOutroDuration(...) there).
export const sparkleMaskOutroDemoTimings = {holdBefore: 8, holdAfter: 24};
export const SparkleMaskOutroDemo: React.FC = () => (
  <SparkleMaskOutro
    holdBefore={sparkleMaskOutroDemoTimings.holdBefore}
    outgoing={<Panel label="1" background="#7c3aed" />}
  />
);

// ---------------------------------------------------------------------------
// Match cuts — velocity-continuous scale + directional cuts (see match-cut.tsx)
// Reuses the same purple→blue numbered Panel as the whip-pan/push-through
// demos above, so all four transition previews read as one consistent set.
// ---------------------------------------------------------------------------

const BLUE = '#0ea5e9';
const PINK = '#ec4899';

// The one shared "matched feature" for every match-cut demo — a rounded cube — so all
// four cards read as one consistent set. `dot` adds an off-center marker; only the
// rotational demo needs it (to make the spin legible), so it's opt-in and every other
// demo below renders the plain cube.
const RoundedCube: React.FC<{color: string; dot?: boolean; size?: number}> = ({
  color,
  dot = false,
  size = 180,
}) => (
  <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
    <div
      style={{
        width: size,
        height: size,
        // Keep the corner rounding proportional so a smaller cube doesn't read as a
        // different shape — 28/180 is the ratio the full-size demos use.
        borderRadius: (28 / 180) * size,
        background: color,
        display: dot ? 'flex' : undefined,
        justifyContent: dot ? 'center' : undefined,
        paddingTop: dot ? (16 / 180) * size : undefined,
        boxSizing: 'border-box',
      }}
    >
      {dot && (
        <div
          style={{
            width: (18 / 180) * size,
            height: (18 / 180) * size,
            borderRadius: '50%',
            background: '#ffffff',
          }}
        />
      )}
    </div>
  </AbsoluteFill>
);

// Scale: the SAME match-cut timing as the directional whip, but the motion is SCALE — one
// continuous push THROUGH the blue cube into the pink one. On the shared cubic-bezier, the
// blue (outgoing) cube grows from its size to 5×, while the pink (incoming) cube is revealed
// growing from a point up to that same original size — so its final size matches the
// outgoing's starting size (the match). The excised middle 20% (the fast scaling where
// the two would cross) is the hard cut, hidden by the fast motion exactly as the pan hides
// the seam. direction: 'out' would reverse it (outgoing recedes, incoming settles from big).
export const ScaleMatchCutDemo: React.FC = () => (
  <MatchCut
    mode="scale"
    outgoing={<RoundedCube color={BLUE} />}
    incoming={<RoundedCube color={PINK} />}
    holdBefore={18}
    transitionDurationInFrames={20}
    holdAfter={22}
    scale={{direction: 'in', scaleFactor: 5}}
  />
);

// Directional: a whip pan of BOTH cubes together on one cubic-bezier curve, with
// the middle 20% of the motion cut out (the motion jumps 40%→60% of its time). The
// pink cube enters from the left as the blue one exits — the seam-crossing centre is
// excised, so it reads as a hard snap cut. angleDeg 180 would reverse it (enter from
// the right instead).
export const DirectionalMatchCutDemo: React.FC = () => (
  <MatchCut
    mode="directional"
    outgoing={<RoundedCube color={BLUE} />}
    incoming={<RoundedCube color={PINK} />}
    holdBefore={18}
    transitionDurationInFrames={16}
    holdAfter={22}
    directional={{angleDeg: 0}}
  />
);

// Round-trip intensity rows: one continuous loop, box travels left -> right (blue exits,
// pink enters and settles), then right -> left back to start (pink exits, blue re-enters and
// settles) — two directional match cuts back to back in a single <Sequence>, same intensity
// on both legs. angleDeg 180 on the return leg is the exact mirror of angleDeg 0, so the loop
// lands back on blue-centered exactly where it began.
const INTENSITY_ROW_LEG_FRAMES = 56; // holdBefore(18) + transition(16) + holdAfter(22)
/** ~a quarter of the rendered size these cubes used to be. Sized against the strip's own
 *  composition height (see INTENSITY_ROW_ENTRIES in registry.tsx) — the Player scales the
 *  whole composition to fit, so what controls the on-screen size is this cube's RATIO to the
 *  composition height, not its absolute value. */
const INTENSITY_CUBE = 44;

const IntensityRow: React.FC<{intensity: 'hard' | 'medium' | 'soft'}> = ({intensity}) => (
  <AbsoluteFill>
    <Sequence from={0} durationInFrames={INTENSITY_ROW_LEG_FRAMES}>
      <MatchCut
        mode="directional"
        outgoing={<RoundedCube color={BLUE} size={INTENSITY_CUBE} />}
        incoming={<RoundedCube color={PINK} size={INTENSITY_CUBE} />}
        holdBefore={18}
        transitionDurationInFrames={16}
        holdAfter={22}
        directional={{angleDeg: 0}}
        intensity={intensity}
      />
    </Sequence>
    <Sequence from={INTENSITY_ROW_LEG_FRAMES} durationInFrames={INTENSITY_ROW_LEG_FRAMES}>
      <MatchCut
        mode="directional"
        outgoing={<RoundedCube color={PINK} size={INTENSITY_CUBE} />}
        incoming={<RoundedCube color={BLUE} size={INTENSITY_CUBE} />}
        holdBefore={18}
        transitionDurationInFrames={16}
        holdAfter={22}
        directional={{angleDeg: 180}}
        intensity={intensity}
      />
    </Sequence>
  </AbsoluteFill>
);

export const matchCutIntensityRowDurationInFrames = INTENSITY_ROW_LEG_FRAMES * 2;

export const MatchCutHardIntensityRowDemo: React.FC = () => <IntensityRow intensity="hard" />;
export const MatchCutMediumIntensityRowDemo: React.FC = () => <IntensityRow intensity="medium" />;
export const MatchCutSoftIntensityRowDemo: React.FC = () => <IntensityRow intensity="soft" />;

// Directional-scale: DIRECTIONAL and SCALE combined — both translate and scale off the
// SAME shared disp value. The blue cube travels left while growing to 3×; at the cut
// the pink cube appears already partway along that same leftward line and already
// partway grown, continuing until it settles at rest — one continuous move-and-grow
// straight through the hard cut. Both axes reverse independently: angleDeg for travel
// (0/180 = left/right, 90/270 = up/down), direction: 'in'|'out' for scale.
export const DirectionalScaleMatchCutDemo: React.FC = () => (
  <MatchCut
    mode="directional-scale"
    outgoing={<RoundedCube color={BLUE} />}
    incoming={<RoundedCube color={PINK} />}
    holdBefore={18}
    transitionDurationInFrames={30}
    holdAfter={22}
    directionalScale={{angleDeg: 180, direction: 'in', scaleFactor: 3, travelDistance: 1}}
  />
);

// Rotational: the same match-cut timing, but the motion is ROTATION on its own
// anticipate/overshoot curve. The blue cube spins through two full turns (0°→720°);
// at the cut the pink cube is already spinning at the same rate and simply carries
// the turn onward — the excised middle 20% (the fastest, most-blurred part of the
// spin) hides the handoff. direction: 'ccw' would reverse the spin.
export const RotationalMatchCutDemo: React.FC = () => (
  <MatchCut
    mode="rotational"
    outgoing={<RoundedCube color={BLUE} dot />}
    incoming={<RoundedCube color={PINK} dot />}
    holdBefore={18}
    transitionDurationInFrames={26}
    holdAfter={22}
    rotational={{direction: 'cw', totalDegrees: 720}}
  />
);

// Scale-rotational: SCALE and ROTATIONAL combined, on the rotational curve — both grow
// and spin off the SAME shared disp value. The blue cube grows to 3× while spinning
// through two full turns (0°→720°); at the cut the pink cube is already partway grown
// and partway spun, continuing until it settles at rest — one continuous spin-and-grow
// straight through the hard cut. Both axes reverse independently: direction: 'in'|'out'
// for scale, rotationDirection: 'cw'|'ccw' for spin.
export const ScaleRotationalMatchCutDemo: React.FC = () => (
  <MatchCut
    mode="scale-rotational"
    outgoing={<RoundedCube color={BLUE} dot />}
    incoming={<RoundedCube color={PINK} dot />}
    holdBefore={18}
    transitionDurationInFrames={30}
    holdAfter={22}
    scaleRotational={{direction: 'in', scaleFactor: 3, rotationDirection: 'cw', totalDegrees: 720}}
  />
);

// Perspective: a REAL 3D rotation (perspective + rotateY) — not a scale fake. The blue
// cube turns face-on to edge-on on the shared anticipate/overshoot curve; the cut fires
// at the exact instant it's genuinely edge-on (90° of the 180° flip), where real
// foreshortening makes it narrowest — not at a fixed time fraction like the other match
// cuts. The pink cube picks up at that same edge-on angle and turns on through to
// face-on, so it reads as one continuous flip through two different cubes. direction:
// 'ccw' would reverse the turn; axis: 'x' would flip it top-to-bottom instead.
export const PerspectiveMatchCutDemo: React.FC = () => (
  <MatchCut
    mode="perspective"
    outgoing={<RoundedCube color={BLUE} />}
    incoming={<RoundedCube color={PINK} />}
    holdBefore={18}
    transitionDurationInFrames={30}
    holdAfter={22}
    perspective={{axis: 'y', direction: 'cw', totalDegrees: 180, perspectivePx: 900}}
  />
);

// Typewriter tracking match cut: a sentence types itself on-screen while a horizontally
// tracking camera follows the cursor; once typing finishes, a hard match cut — placed
// mid-pull, while the camera is actively moving backward — reveals the whole sentence via
// a real 3D dolly-back. One continuous camera journey (TYPE -> TRACK -> HARD CUT ->
// DOLLY BACK -> REVEAL), not two stitched animations. See
// typewriter-tracking-match-cut.tsx for the full design writeup.
export const TypewriterTrackingMatchCutDemo: React.FC = () => (
  <TypewriterTrackingMatchCut text="Generate a core IT equipment sheet" />
);

// Silky smooth — enters, holds, then exits in reverse, so the loop shows both
// halves. Timing is shared with the registry so the preview can't outlast it.
export const silkySmoothDemoTiming = {
  text: 'Motion that never\narrives, it settles',
  exitStartFrame: 46,
};
export const silkySmoothDemoDuration = (fps: number) =>
  silkySmoothDuration(silkySmoothDemoTiming, fps) + 8;
export const SilkySmoothDemo: React.FC = () => (
  <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center'}}>
    <SilkySmooth {...silkySmoothDemoTiming} fontSize={72} color="#ffffff" />
  </AbsoluteFill>
);

// ZoomMate composer. Scaled down to fit the preview card — the component is laid
// out at its native 1200px, so the wrapper zooms rather than reflows it.
export const zoomMateSimplePrompt =
  "QBR with ACME is tomorrow at 9! What did we commit to, what's shifted, and what should I be ready to answer?";
export const zoomMateSimpleDemoDuration = zoomMateSimpleDuration() + 20;
export const ZoomMateSimpleDemo: React.FC = () => (
  <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', background: '#f4f6fb'}}>
    <div style={{transform: 'scale(0.62)', transformOrigin: 'center center'}}>
      <ZoomMateSimple prompt={zoomMateSimplePrompt} />
    </div>
  </AbsoluteFill>
);

// The full ZoomMate surface — rail and header icons in shot, then the pan.
export const zoomMateFullDemoDuration = zoomMateFullDuration({}, 30) + 12;
export const ZoomMateFullDemo: React.FC = () => (
  <AbsoluteFill style={{background: '#ffffff'}}>
    <ZoomMateFull />
  </AbsoluteFill>
);

// Message docks into the sidebar while the deck editor slides in from the
// right, then a cursor clicks down the slide thumbnails. Everything is the
// component's own default content — the point of the preview is that the whole
// surface ships with it.
export const messageDockRevealDemoDuration = messageDockRevealDuration() + 24;
export const MessageDockRevealDemo: React.FC = () => (
  <AbsoluteFill
    style={{
      background: 'linear-gradient(135deg,#ffffff 0%,#edf4ff 55%,#dbe9ff 100%)',
    }}
  >
    <MessageDockReveal />
  </AbsoluteFill>
);

// Glass pills pop in on camera cuts, then arc into the centre mark.
export const ctaPillsDemoDuration = ctaPillsDuration() + 18;
export const CtaPillsDemo: React.FC = () => (
  <AbsoluteFill style={{background: 'linear-gradient(140deg,#1b0a3a,#3b1178 60%,#5a1aa8)'}}>
    <CtaPills
      showAura
      centerElement={
        <div style={{fontSize: 76, fontWeight: 700, color: '#fff', letterSpacing: '-0.02em'}}>HQ</div>
      }
    />
  </AbsoluteFill>
);

// Camera pushes into a Zoom dashboard's left nav while the selection pill
// slides onto a submenu row. Let it settle rather than the source's own
// mid-zoom cut — the settled version is the more useful default demo.
export const dashboardNavZoomDemoDuration = dashboardNavZoomDuration();
export const DashboardNavZoomDemo: React.FC = () => (
  <AbsoluteFill style={{background: '#0a0a12'}}>
    <DashboardNavZoom />
  </AbsoluteFill>
);
