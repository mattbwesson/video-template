import React from 'react';
import {AbsoluteFill} from 'remotion';

// self-contained text presets
import {BottomUpLetters} from './motion/bottom-up-letters';
import {PerCharacterRise} from './motion/per-character-rise';
import {SoftBlurIn} from './motion/soft-blur-in';
import {SpringScaleIn} from './motion/spring-scale-in';
import {StaggeredFadeUp} from './motion/staggered-fade-up';
import {ShortSlideRight} from './motion/short-slide-right';
import {ShortSlideDown} from './motion/short-slide-down';
import {KineticCenterBuild} from './motion/kinetic-center-build';
import {TrackingIn} from './motion/tracking-in';
import {Typewriter} from './motion/typewriter';
import {SlotMachineRoll} from './motion/slot-machine-roll';
import {RollingNumber} from './motion/rolling-number';
import {RolodexFlip} from './motion/rolodex-flip';
import {SharedAxisZ} from './motion/shared-axis-z';
import {InlineHighlight} from './motion/inline-highlight';
import {MarkerHighlight} from './motion/marker-highlight';
import {ShimmerSweep} from './motion/shimmer-sweep';
import {LineByLineSlide} from './motion/line-by-line-slide';
import {MaskRevealUp} from './motion/mask-reveal-up';

// backgrounds
import {ShaderGrainGradient} from './motion/shader-grain-gradient';
import {ShaderMeshGradient} from './motion/shader-mesh-gradient';
import {PerspectiveMarquee} from './motion/perspective-marquee';
import {BlobBackground} from './motion/orbit-animation/BlobBackground';

// scenes
import {typewriterTrackingMatchCutDuration} from './motion/typewriter-tracking-match-cut';
import {sparkleMaskOutroDuration} from './motion/sparkle-mask-outro';
import {EcosystemConstellation} from './motion/ecosystem-constellation';
import {InfiniteBentoPan} from './motion/infinite-bento-pan';
import {IconOrbitScene} from './motion/orbit-animation/IconOrbitScene';

// hook/interaction-driven wrappers
import {
  RippleDotGridDemo,
  ZoomMeetingDemo,
  WhipPanDemo,
  PushThroughDemo,
  SparkleMaskOutroDemo,
  sparkleMaskOutroDemoTimings,
  SilkySmoothDemo,
  silkySmoothDemoDuration,
  ZoomMateSimpleDemo,
  zoomMateSimpleDemoDuration,
  ZoomMateFullDemo,
  zoomMateFullDemoDuration,
  MessageDockRevealDemo,
  messageDockRevealDemoDuration,
  CtaPillsDemo,
  ctaPillsDemoDuration,
  DashboardNavZoomDemo,
  dashboardNavZoomDemoDuration,
  ScaleMatchCutDemo,
  DirectionalMatchCutDemo,
  MatchCutHardIntensityRowDemo,
  MatchCutMediumIntensityRowDemo,
  MatchCutSoftIntensityRowDemo,
  matchCutIntensityRowDurationInFrames,
  DirectionalScaleMatchCutDemo,
  RotationalMatchCutDemo,
  ScaleRotationalMatchCutDemo,
  PerspectiveMatchCutDemo,
  TypewriterTrackingMatchCutDemo,
} from './wrappers';

export type CategoryId = 'text' | 'ui' | 'transition' | 'scene' | 'background';

export interface Category {
  id: CategoryId;
  label: string;
  blurb: string;
  index: string;
  accent: string;
}

export const CATEGORIES: Category[] = [
  {id: 'text', label: 'Text', blurb: 'Per-letter, per-word and number reveals.', index: '01', accent: '#a855f7'},
  {id: 'ui', label: 'UI Components', blurb: 'Animated shadcn-style interface primitives.', index: '02', accent: '#3b82f6'},
  {id: 'transition', label: 'Transitions', blurb: 'Scene-to-scene cuts and content wrappers.', index: '03', accent: '#22d3ee'},
  {id: 'scene', label: 'Scenes & Flows', blurb: 'Self-contained product mini-flows.', index: '04', accent: '#c9f24d'},
  {id: 'background', label: 'Backgrounds & Effects', blurb: 'Shaders, gradients and ambient motion.', index: '05', accent: '#ec4899'},
];

export interface AnimationEntry {
  id: string;
  name: string;
  category: CategoryId;
  component: React.FC<any>;
  inputProps?: Record<string, unknown>;
  durationInFrames?: number;
  fps?: number;
  width?: number;
  height?: number;
  posterFrame?: number;
  background?: string;
  /** Which static backdrop image to use, overriding the category default (see
   *  backdropSrcFor in AnimationPreview.tsx). 1 = preview-bg.jpg, 2 = preview-bg-2.jpg. */
  backdrop?: 1 | 2;
  blurb?: string;
}

const FPS = 30;
const DARK = '#0a0a12';
// Text presets render over the dark video backdrop, so their ink is light.
const TEXT_LIGHT = '#f4f4f7';

// Bind fixed props into a zero-prop component with a STABLE identity (defined at
// module scope) so <Player> never remounts it.
function bind<P extends object>(Comp: React.ComponentType<P>, props: P): React.FC {
  const Bound: React.FC = () => <Comp {...(props as P)} />;
  return Bound;
}

// Center an in-flow preview (inline spans etc.). Transparent by default so the
// preview's video/solid backdrop shows through.
function centered(node: React.ReactNode, background = 'transparent'): React.FC {
  const C: React.FC = () => (
    <AbsoluteFill style={{alignItems: 'center', justifyContent: 'center', background}}>
      {node}
    </AbsoluteFill>
  );
  return C;
}

// A couple of one-off wrappers that live better here than in wrappers.tsx.
const RolodexFlipDemo = centered(
  <span style={{fontSize: 84, fontWeight: 700, color: TEXT_LIGHT, letterSpacing: '-0.03em'}}>
    <RolodexFlip items={['Design', 'Build', 'Ship', 'Scale']} interval={22} />
  </span>,
);

export const ENTRIES: AnimationEntry[] = [
  // ---------------------------------------------------------------- text
  {id: 'bottom-up-letters', name: 'Bottom-up letters', category: 'text', component: bind(BottomUpLetters, {text: 'Motion', color: TEXT_LIGHT}), durationInFrames: 70},
  {id: 'per-character-rise', name: 'Per-character rise', category: 'text', component: bind(PerCharacterRise, {text: 'Rise up', color: TEXT_LIGHT}), durationInFrames: 70},
  {id: 'soft-blur-in', name: 'Soft blur in', category: 'text', component: bind(SoftBlurIn, {text: 'Focus', color: TEXT_LIGHT}), durationInFrames: 80},
  {id: 'spring-scale-in', name: 'Spring scale in', category: 'text', component: bind(SpringScaleIn, {text: 'Pop in words', color: TEXT_LIGHT}), durationInFrames: 70},
  {id: 'staggered-fade-up', name: 'Staggered fade up', category: 'text', component: bind(StaggeredFadeUp, {text: 'Fade me up', color: TEXT_LIGHT}), durationInFrames: 70},
  {id: 'short-slide-right', name: 'Short slide right', category: 'text', component: bind(ShortSlideRight, {text: 'Slide right', color: TEXT_LIGHT}), durationInFrames: 70},
  {id: 'short-slide-down', name: 'Short slide down', category: 'text', component: bind(ShortSlideDown, {text: 'one two three', color: TEXT_LIGHT}), durationInFrames: 90},
  {id: 'kinetic-center-build', name: 'Kinetic center build', category: 'text', component: bind(KineticCenterBuild, {text: 'Build from center', color: TEXT_LIGHT}), durationInFrames: 90},
  {id: 'tracking-in', name: 'Tracking in', category: 'text', component: bind(TrackingIn, {text: 'TRACKING', color: TEXT_LIGHT}), durationInFrames: 70},
  {id: 'typewriter', name: 'Typewriter', category: 'text', component: bind(Typewriter, {text: 'Hello, world.', color: TEXT_LIGHT, cursorColor: TEXT_LIGHT}), durationInFrames: 110},
  {id: 'slot-machine-roll', name: 'Slot machine roll', category: 'text', component: bind(SlotMachineRoll, {from: '$99', to: '$199', color: TEXT_LIGHT}), durationInFrames: 80},
  {id: 'rolling-number', name: 'Rolling number', category: 'text', component: bind(RollingNumber, {from: 0, to: 24813, color: TEXT_LIGHT}), durationInFrames: 90},
  {id: 'rolodex-flip', name: 'Rolodex flip', category: 'text', component: RolodexFlipDemo, durationInFrames: 100},
  {id: 'shared-axis-z', name: 'Shared axis Z', category: 'text', component: bind(SharedAxisZ, {fromText: 'Before', toText: 'After', color: TEXT_LIGHT}), durationInFrames: 60},
  {id: 'inline-highlight', name: 'Inline highlight', category: 'text', component: bind(InlineHighlight, {before: 'Make it ', highlight: 'pop', after: '.', baseColor: TEXT_LIGHT}), durationInFrames: 90},
  {id: 'marker-highlight', name: 'Marker highlight', category: 'text', component: bind(MarkerHighlight, {before: 'This is ', highlight: 'important', baseColor: TEXT_LIGHT}), durationInFrames: 80},
  {id: 'silky-smooth', name: 'Silky smooth', category: 'text', component: SilkySmoothDemo, durationInFrames: silkySmoothDemoDuration(30), posterFrame: 22},
  {id: 'shimmer-sweep', name: 'Shimmer sweep', category: 'text', component: bind(ShimmerSweep, {text: 'SHIMMER', baseColor: '#8b8b95', shineColor: '#ffffff'}), durationInFrames: 90},
  {id: 'line-by-line-slide', name: 'Line-by-line slide', category: 'text', component: bind(LineByLineSlide, {text: 'design\nbuild\nship', color: TEXT_LIGHT}), durationInFrames: 100},
  {id: 'mask-reveal-up', name: 'Mask reveal up', category: 'text', component: bind(MaskRevealUp, {text: 'reveal\nfrom mask', color: TEXT_LIGHT}), durationInFrames: 100},

  // ---------------------------------------------------------------- ui
  // The interaction primitives (Button, Input, Switch, … and their
  // use-*Transition hooks) are all still exported from the library; only their
  // gallery entries were removed. Re-add by importing the demo wrappers from
  // ./wrappers, which are also still there.
  // These three keep `backdrop: 2` — the deeper plate scenes get by default —
  // because they're still product mockups that need to read as their own device
  // on a stage, and the category default for `ui` is the lighter one.
  {id: 'message-dock-reveal', name: 'Artifact Creation', category: 'ui', component: MessageDockRevealDemo, durationInFrames: messageDockRevealDemoDuration, posterFrame: 58},
  {id: 'zoommate-full', name: 'ZoomMate full', category: 'ui', component: ZoomMateFullDemo, durationInFrames: zoomMateFullDemoDuration, posterFrame: 50, backdrop: 2},
  {id: 'zoommate-simple', name: 'ZoomMate simple', category: 'ui', component: ZoomMateSimpleDemo, durationInFrames: zoomMateSimpleDemoDuration, posterFrame: 130, backdrop: 2},
  {id: 'zoom-meeting', name: 'Zoom meeting', category: 'ui', component: ZoomMeetingDemo, durationInFrames: 150, backdrop: 2},

  // ---------------------------------------------------------------- transition
  {id: 'whip-pan', name: 'Whip pan', category: 'transition', component: WhipPanDemo, durationInFrames: 88, backdrop: 1},
  {id: 'push-through', name: 'Push through', category: 'transition', component: PushThroughDemo, durationInFrames: 88, backdrop: 2},
  {id: 'sparkle-mask-outro', name: 'Sparkle mask outro', category: 'transition', component: SparkleMaskOutroDemo, durationInFrames: sparkleMaskOutroDuration(sparkleMaskOutroDemoTimings), posterFrame: sparkleMaskOutroDuration(sparkleMaskOutroDemoTimings) - 4},
  {id: 'match-cut-scale', name: 'Match cut · scale', category: 'transition', component: ScaleMatchCutDemo, durationInFrames: 62, posterFrame: 14},
  {id: 'match-cut-directional', name: 'Match cut · directional', category: 'transition', component: DirectionalMatchCutDemo, durationInFrames: 56, posterFrame: 12},
  {id: 'match-cut-directional-scale', name: 'Match cut · directional + scale', category: 'transition', component: DirectionalScaleMatchCutDemo, durationInFrames: 72, posterFrame: 14},
  {id: 'match-cut-rotational', name: 'Match cut · rotational', category: 'transition', component: RotationalMatchCutDemo, durationInFrames: 66, posterFrame: 14},
  {id: 'match-cut-scale-rotational', name: 'Match cut · scale + rotation', category: 'transition', component: ScaleRotationalMatchCutDemo, durationInFrames: 72, posterFrame: 14},
  {id: 'match-cut-perspective', name: 'Match cut · perspective', category: 'transition', component: PerspectiveMatchCutDemo, durationInFrames: 72, posterFrame: 14},

  // ---------------------------------------------------------------- scene
  {id: 'ecosystem-constellation', name: 'Ecosystem constellation', category: 'scene', component: bind(EcosystemConstellation, {centerLabel: 'Z'}), durationInFrames: 120},
  {id: 'infinite-bento-pan', name: 'Infinite bento pan', category: 'scene', component: bind(InfiniteBentoPan, {}), durationInFrames: 300},
  {id: 'icon-orbit-scene', name: 'Icon orbit scene', category: 'scene', component: bind(IconOrbitScene, {}), durationInFrames: 300},
  {id: 'typewriter-tracking-match-cut', name: 'Typewriter tracking match cut', category: 'scene', component: TypewriterTrackingMatchCutDemo, durationInFrames: Math.round(typewriterTrackingMatchCutDuration({text: 'Generate a core IT equipment sheet'})), posterFrame: Math.round(typewriterTrackingMatchCutDuration({text: 'Generate a core IT equipment sheet'})) - 2},
  {id: 'cta-pills', name: 'CTA pills', category: 'scene', component: CtaPillsDemo, durationInFrames: ctaPillsDemoDuration, posterFrame: 168},
  {id: 'dashboard-nav-zoom', name: 'Dashboard nav zoom', category: 'scene', component: DashboardNavZoomDemo, durationInFrames: dashboardNavZoomDemoDuration, posterFrame: 60},

  // ---------------------------------------------------------------- background
  {id: 'shader-mesh-gradient', name: 'Shader mesh gradient', category: 'background', component: bind(ShaderMeshGradient, {}), durationInFrames: 120, background: DARK},
  {id: 'shader-grain-gradient', name: 'Shader grain gradient', category: 'background', component: bind(ShaderGrainGradient, {}), durationInFrames: 120, background: DARK},
  {id: 'perspective-marquee', name: 'Perspective marquee', category: 'background', component: bind(PerspectiveMarquee, {}), durationInFrames: 120, background: '#050505'},
  {id: 'blob-background', name: 'Blob background', category: 'background', component: bind(BlobBackground, {bgColor: '#030305', blobColor: '#0b1f4d'}), durationInFrames: 120, background: DARK},
  {id: 'ripple-dot-grid', name: 'Ripple dot grid', category: 'background', component: RippleDotGridDemo, durationInFrames: 60, background: '#04040a'},
];

export function entriesByCategory(cat: CategoryId): AnimationEntry[] {
  return ENTRIES.filter((e) => e.category === cat);
}

// Intensity comparison rows, shown as a narrow banner strip above the Transitions grid (not
// part of ENTRIES / the preset count) — each is a single round-trip loop (box travels left ->
// right, then right -> left back to start) on the same directional match cut, varying only
// `intensity`, so the three rows put the size of the excised cut side by side. `background:
// 'transparent'` skips the category's default backdrop image/dot-grid (see backdropSrcFor in
// AnimationPreview.tsx) — just the boxes, no backdrop.
//
// The 1280x48 composition is a deliberately extreme 26:1 strip. <Player> scales a composition
// to CONTAIN it, so a squarer composition in a wide short row would letterbox — the box would
// travel a narrow band in the middle instead of the full width. Matching the composition's
// aspect to the row's keeps the travel edge-to-edge. Keep this in sync with
// .zm-intensity-row__preview's height in global.css.
export const INTENSITY_ROW_ENTRIES: AnimationEntry[] = [
  {id: 'match-cut-intensity-row-hard', name: 'Hard', category: 'transition', component: MatchCutHardIntensityRowDemo, durationInFrames: matchCutIntensityRowDurationInFrames, width: 1280, height: 64, background: 'transparent', blurb: 'Skips 25% — the most abrupt cut, for small or isolated subjects.'},
  {id: 'match-cut-intensity-row-medium', name: 'Medium', category: 'transition', component: MatchCutMediumIntensityRowDemo, durationInFrames: matchCutIntensityRowDurationInFrames, width: 1280, height: 64, background: 'transparent', blurb: 'Skips 20% — the general-purpose default.'},
  {id: 'match-cut-intensity-row-soft', name: 'Soft', category: 'transition', component: MatchCutSoftIntensityRowDemo, durationInFrames: matchCutIntensityRowDurationInFrames, width: 1280, height: 64, background: 'transparent', blurb: 'Skips 15% — the most subtle cut, for full-frame or complex shots.'},
];

export const FPS_DEFAULT = FPS;
