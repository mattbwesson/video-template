import {useCallback, useEffect, useState} from 'react';
import type {CategoryId} from './registry';

export type Route = 'home' | CategoryId | 'easing' | 'camera' | 'objects';

const VALID: Route[] = [
  'home',
  'text',
  'ui',
  'transition',
  'scene',
  'background',
  'easing',
  'camera',
  'objects',
];

function parse(): Route {
  const h = window.location.hash.replace(/^#\/?/, '');
  return (VALID as string[]).includes(h) ? (h as Route) : 'home';
}

export function useHashRoute(): [Route, (r: Route) => void] {
  const [route, setRoute] = useState<Route>(parse);

  useEffect(() => {
    const onHash = () => setRoute(parse());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);

  const navigate = useCallback((r: Route) => {
    window.location.hash = r === 'home' ? '' : `#${r}`;
    setRoute(r);
  }, []);

  return [route, navigate];
}
