import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';

// The vendored motion components live under src/motion (see scripts/sync-motion.mjs).
export default defineConfig({
  plugins: [react()],
  // Remotion + React + astryx must each resolve to a SINGLE instance across the
  // app and the vendored lib. Without deduping react here, deep astryx subpath
  // imports (AppShell/SideNav) pull a second React and throw "Invalid hook call".
  resolve: {
    dedupe: ['react', 'react-dom', 'react/jsx-runtime', 'remotion', '@remotion/player'],
  },
  // Pre-bundle the astryx subpaths we import so their internal `import 'react'`
  // shares the app's optimized React instance (fixes dev-only hook errors).
  optimizeDeps: {
    include: [
      'react',
      'react-dom',
      'react/jsx-runtime',
      '@astryxdesign/core/theme',
      '@astryxdesign/core/AppShell',
      '@astryxdesign/core/SideNav',
      '@astryxdesign/core/Card',
      '@astryxdesign/core/Grid',
      '@astryxdesign/core/Badge',
      '@astryxdesign/core/Heading',
      '@astryxdesign/core/Text',
      '@astryxdesign/theme-neutral/built',
    ],
  },
  server: {
    host: true,
    port: 5173,
  },
  build: {
    target: 'es2022',
    chunkSizeWarningLimit: 2000,
  },
});
