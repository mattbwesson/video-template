// Vendors the zm-motion library (the repo root) into site/src/motion so the
// gallery can bundle the animation components. The components import each other
// and their helpers with RELATIVE paths (./lib/..., ./use-*-transition, ./whip-pan),
// so we copy the whole flat library tree verbatim to preserve those imports.
//
// Run automatically by predev/prebuild. The vendored copy is gitignored — the
// library at the repo root stays the single source of truth.
import {
  cpSync,
  mkdirSync,
  rmSync,
  readdirSync,
  readFileSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import {dirname, join, resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));
const repoRoot = resolve(here, '..', '..');
const dest = resolve(here, '..', 'src', 'motion');

// Directories at the repo root that are part of the library.
// sparkle-frames holds the PNG sequence sparkle-mask-outro.tsx resolves relatively.
const LIB_DIRS = ['lib', 'orbit-animation', 'sparkle-frames'];
// Everything else we copy is loose .ts/.tsx files at the root.
const EXCLUDE = new Set(['site', 'node_modules', '.git']);

rmSync(dest, {recursive: true, force: true});
mkdirSync(dest, {recursive: true});

let files = 0;
for (const entry of readdirSync(repoRoot)) {
  if (EXCLUDE.has(entry)) continue;
  const src = join(repoRoot, entry);
  const s = statSync(src);
  if (s.isDirectory()) {
    if (LIB_DIRS.includes(entry)) {
      cpSync(src, join(dest, entry), {recursive: true});
      files++;
    }
    continue;
  }
  if (entry.endsWith('.ts') || entry.endsWith('.tsx')) {
    cpSync(src, join(dest, entry));
    files++;
  }
}

// The gallery renders text presets over a dark video background, so the few
// text components that hard-code an opaque container background are patched to
// be transparent (scoped to those files only — product-UI scenes keep white).
const TRANSPARENT_BG_FILES = [
  'staggered-fade-up.tsx',
  'slot-machine-roll.tsx',
  'typewriter.tsx',
  'tracking-in.tsx',
  'rgb-glitch-text.tsx',
  'marker-highlight.tsx',
  'inline-highlight.tsx',
  'shimmer-sweep.tsx',
];
for (const f of TRANSPARENT_BG_FILES) {
  const p = join(dest, f);
  let code = readFileSync(p, 'utf8');
  code = code
    .split('background: "white"')
    .join('background: "transparent"')
    .split('background: "#fafafa"')
    .join('background: "transparent"');
  writeFileSync(p, code);
}
console.log(`[sync-motion] made ${TRANSPARENT_BG_FILES.length} text bgs transparent`);

// Marker so it's obvious this tree is generated.
writeFileSync(
  join(dest, 'GENERATED.md'),
  '# Generated\n\nThis directory is copied from the zm-motion library root by ' +
    '`scripts/sync-motion.mjs`. Do not edit here — edit the library at the repo root.\n',
);

console.log(`[sync-motion] copied ${files} top-level entries -> src/motion`);
