import React from 'react';
import {
  AbsoluteFill, Easing, interpolate, spring, useCurrentFrame, useVideoConfig,
} from 'remotion';
import {BlobBackground} from './BlobBackground';
import {RippleDotGrid} from './RippleDotGrid';

// Rebuild of the ZVA "icons in a row → orbit" beat. Nine Zoom product icons pop in as a
// horizontal row flanking the central Primerica emblem, then lerp into a tilted, spinning
// ellipse orbit with depth-based blur/scale. Self-contained, driven by the local frame.
//
// Icon order: closest-to-centre first on each side.
// Left (4):  Phone, Meetings, Clips, My Notes
// Right (5): Team Chat, Scheduler, Whiteboard, AI Companion (sparkle), Surveys

const N_LEFT  = 4;
const N_RIGHT = 5;

// Central emblem sits on a white rounded tile so it reads on the dark bokeh.
const CENTER_TILE = 150;
const CENTER_GUTTER_PX = 52;

const BOX_PX = 88;
const GAP_PX = 44;

const ICON_START_SCALE = 3;
const ICON_END_SCALE = 1.1;
const ICON_ZOOM_DURATION_S = 0.7;
const POP_LEAD_BEFORE_ZOOM_END = 14;
const PAIR_STAGGER = 3;

const ROW_HOLD_AFTER_SETTLE = 10; // frames the formed row holds before orbiting
const ORBIT_TRANSITION_FRAMES = 58;

// Ellipse radii (px); wide horizontal ellipse then tilted in 2D.
const ORBIT_RADIUS_X_PX = 680;
const ORBIT_RADIUS_Y_PX = 200;
const ORBIT_TILT_RAD = (15 * Math.PI) / 180;
const ORBIT_BLUR_MAX_PX = 3.2;
const ORBIT_DEPTH_SCALE = 0.14;
const ORBIT_SPIN_RAD_PER_FRAME = 0.0104;
const ORBIT_MOVE_SCALE_END = 1.1;

const SCENE_FADE = [0, 7] as const;

// Consolidate: the orbiting icons rush back into the centre, and a dot-grid wave ripples out from
// the impact. Local frame 170 = global 2400.
const CONSOLIDATE_START = 170;
const OUTRO_FRAMES = 20;
const RIPPLE_LEAD = 9; // ripple bursts once the icons have nearly converged

// Emblem exit: after everything has collapsed and the ripple fades, the Primerica tile rises and
// fades to clear the frame for the hero cards scene. Global 2500 = local 270.
const EXIT_START  = 270;
const EXIT_FRAMES = 20;

// Placeholder icons — self-contained inline shapes (no /public assets), so this
// component transports to any project as pure code. Swap these specs (or restore
// <Img> tiles) for real brand icons. Order: closest-to-centre first per side.
// Left (4): index 0..3   Right (5): index 4..8
type IconSpec = {color: string; shape: 'circle' | 'square' | 'diamond'};
const ALL: IconSpec[] = [
  {color: '#2D8CFF', shape: 'circle'},  // 0 closest left
  {color: '#5B6BF5', shape: 'square'},  // 1
  {color: '#7C5CF0', shape: 'diamond'}, // 2
  {color: '#12B76A', shape: 'circle'},  // 3 farthest left
  {color: '#F59E0B', shape: 'square'},  // 4 closest right
  {color: '#EF4444', shape: 'diamond'}, // 5
  {color: '#06B6D4', shape: 'circle'},  // 6
  {color: '#EC4899', shape: 'square'},  // 7
  {color: '#8B5CF6', shape: 'diamond'}, // 8 farthest right
];

const GLYPH_STYLE: Record<IconSpec['shape'], React.CSSProperties> = {
  circle: {borderRadius: '50%'},
  square: {borderRadius: 10},
  diamond: {borderRadius: 6, transform: 'rotate(45deg)'},
};

// One placeholder "app tile": a rounded square in the spec colour with a white
// inner glyph, so each icon stays visually distinct as it orbits.
const PlaceholderIcon: React.FC<{spec: IconSpec}> = ({spec}) => (
  <div
    style={{
      width: '100%', height: '100%', borderRadius: 22,
      background: spec.color,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      boxShadow: 'inset 0 -8px 16px rgba(0,0,0,.18)',
    }}
  >
    <div style={{width: '46%', height: '46%', background: 'rgba(255,255,255,.94)', ...GLYPH_STYLE[spec.shape]}} />
  </div>
);

function popScale(localFrame: number, startFrame: number, pairIndex: number, fps: number): number {
  const frame = localFrame - (startFrame + pairIndex * PAIR_STAGGER);
  if (frame < 0) return 0;
  return spring({frame, fps, config: {damping: 11, stiffness: 260, mass: 0.35}});
}

function horizontalXY(index: number, centerScale: number): {x: number; y: number} {
  const halfCenter = (CENTER_TILE * centerScale) / 2;
  const step = BOX_PX + GAP_PX;
  const arm = halfCenter + CENTER_GUTTER_PX + BOX_PX / 2;
  if (index < N_LEFT) return {x: -(arm + index * step), y: 0};
  return {x: arm + (index - N_LEFT) * step, y: 0};
}

// Left side (0..N_LEFT-1) fills the left semicircle; right side fills the right semicircle.
// Spacing is divided evenly per side so the icons spread neatly regardless of count.
function orbitTheta(index: number, rotationRad: number): number {
  if (index < N_LEFT) {
    const spacing = Math.PI / N_LEFT;
    return Math.PI / 2 + (index + 0.5) * spacing + rotationRad;
  }
  const rel = index - N_LEFT;
  const spacing = Math.PI / N_RIGHT;
  return -Math.PI / 2 + (rel + 0.5) * spacing + rotationRad;
}

function orbitXY(index: number, rotationRad: number): {x: number; y: number; depth: number} {
  const theta = orbitTheta(index, rotationRad);
  const x0 = ORBIT_RADIUS_X_PX * Math.cos(theta);
  const y0 = ORBIT_RADIUS_Y_PX * Math.sin(theta);
  const depth = Math.sin(theta);
  const cosT = Math.cos(ORBIT_TILT_RAD);
  const sinT = Math.sin(ORBIT_TILT_RAD);
  return {x: x0 * cosT + y0 * sinT, y: -x0 * sinT + y0 * cosT, depth};
}

export const IconOrbitScene: React.FC<{
  consolidateStart?: number;
  exitStart?: number;
  rippleBurst?: boolean;
}> = ({
  consolidateStart = CONSOLIDATE_START,
  exitStart = EXIT_START,
  rippleBurst = false,
}) => {
  // `consolidateStart` (local frame) controls how long the icons spin before collapsing; the ripple
  // derives from it. `exitStart` (local frame) controls when the lone emblem rises/fades — align it
  // with the caller's hero-cards entry so the handoff overlaps cleanly.
  const f = useCurrentFrame();
  const {fps, width, height} = useVideoConfig();

  const zoomFrames = Math.max(8, Math.round(ICON_ZOOM_DURATION_S * fps));
  const centerScale = interpolate(f, [0, zoomFrames - 1], [ICON_START_SCALE, ICON_END_SCALE], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.exp),
  });

  const popStart = Math.max(0, zoomFrames - POP_LEAD_BEFORE_ZOOM_END);
  // Row finishes settling roughly when the last pair's spring is done.
  const orbitStart = popStart + 5 * PAIR_STAGGER + 18 + ROW_HOLD_AFTER_SETTLE;

  const orbitT = Math.max(0, f - orbitStart);
  const orbitProgress = interpolate(orbitT, [0, Math.max(1, ORBIT_TRANSITION_FRAMES - 1)], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.poly(5)),
  });
  const orbitMoveScaleMul = interpolate(orbitProgress, [0, 1], [1, ORBIT_MOVE_SCALE_END]);
  const orbitRotation = orbitT * ORBIT_SPIN_RAD_PER_FRAME;

  const sceneOp = interpolate(f, SCENE_FADE, [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

  // Emblem exits: rises up and fades once icons have fully collapsed and the ripple has cleared.
  const exitP  = interpolate(f, [exitStart, exitStart + EXIT_FRAMES], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.cubic),
  });
  const exitOp = 1 - exitP;
  const exitTy = -80 * exitP;

  // Outro: icons collapse to centre (accelerating), then the dot-grid ripple bursts out.
  const outroT = f - consolidateStart;
  const outroProgress = outroT <= 0 ? 0 : interpolate(outroT, [0, OUTRO_FRAMES - 1], [0, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.in(Easing.cubic),
  });
  const rippleStart = consolidateStart + RIPPLE_LEAD;
  const showRipple = f >= rippleStart;
  // Emblem pulses on the moment of impact.
  const pulse = interpolate(f, [rippleStart - 2, rippleStart + 3, rippleStart + 13], [1, 1.18, 1], {
    extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.out(Easing.cubic),
  });

  const cx = width / 2;
  const cy = height / 2;

  // Paint far icons first (depth sort) so the near side overlaps.
  const order = ALL.map((_, i) => i).sort(
    (a, b) => orbitXY(a, orbitRotation).depth - orbitXY(b, orbitRotation).depth,
  );

  return (
    <AbsoluteFill style={{opacity: sceneOp}}>
      <BlobBackground bgColor="#030305" blobColor="#071641" />

      {showRipple && <RippleDotGrid frame={f - rippleStart} burst={rippleBurst} />}

      <AbsoluteFill style={{zIndex: 2}}>
        {order.map((index) => {
          const spec = ALL[index];
          const pairIndex = index < N_LEFT ? index : index - N_LEFT;
          const pop = popScale(f, popStart, pairIndex, fps);

          const {x: xh, y: yh} = horizontalXY(index, centerScale);
          const {x: xo, y: yo, depth} = orbitXY(index, orbitRotation);
          const x = interpolate(orbitProgress, [0, 1], [xh, xo]) * (1 - outroProgress);
          const y = interpolate(orbitProgress, [0, 1], [yh, yo]) * (1 - outroProgress);

          const blur = orbitProgress * ORBIT_BLUR_MAX_PX * (depth < 0 ? Math.pow(-depth, 0.92) : 0);
          const depthScale = 1 + ORBIT_DEPTH_SCALE * depth;
          const scale = pop * depthScale * orbitMoveScaleMul * (1 - outroProgress);

          return (
            <div
              key={index}
              style={{
                position: 'absolute', left: cx, top: cy,
                width: BOX_PX, height: BOX_PX,
                marginLeft: -BOX_PX / 2, marginTop: -BOX_PX / 2,
                transform: `translate(${x}px, ${y}px) scale(${scale})`,
                transformOrigin: 'center center',
                filter: `blur(${blur}px)`,
                zIndex: 80 + Math.round(40 * depth),
              }}
            >
              <PlaceholderIcon spec={spec} />
            </div>
          );
        })}

        {/* Central Primerica emblem on a white tile */}
        <div
          style={{
            position: 'absolute', left: cx, top: cy,
            width: CENTER_TILE, height: CENTER_TILE,
            marginLeft: -CENTER_TILE / 2, marginTop: -CENTER_TILE / 2,
            transform: `translateY(${exitTy}px) scale(${centerScale * orbitMoveScaleMul * pulse})`,
            transformOrigin: 'center center',
            opacity: exitOp,
            background: '#fff', borderRadius: 32,
            boxShadow: '0 24px 60px -18px rgba(0,0,0,.55)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            zIndex: 200,
          }}
        >
          {/* Placeholder emblem — concentric-ring mark; swap for a real logo. */}
          <div
            style={{
              width: 92, height: 92, borderRadius: '50%', background: '#0b2f7a',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
            }}
          >
            <div style={{width: 34, height: 34, borderRadius: '50%', border: '6px solid #fff'}} />
          </div>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
};
