/**
 * Design DNA (adapted from reference):
 * - Single outward pulse: dot grid only visible in a band around one expanding ring (Gaussian in |r − front|).
 * - Soft circular envelope so the pattern fades into the dark frame like the reference.
 * - Base: ZoomDarkBackground beneath; soft blue radial glow expands with the pulse.
 *
 * `burst` mode turns this into a much more powerful shockwave: three stacked wave fronts (a leading
 * front + two trailing echoes), dots that swell as the wave passes, a white-hot leading edge, a
 * bright stroked energy ring, an impact flash, and a stronger expanding glow.
 */
import React, { useLayoutEffect, useRef } from "react";
import { AbsoluteFill, useVideoConfig } from "remotion";

const DOT_SPACING = 20;
const DOT_RADIUS = 1.25;
/** Ripple front radius grows ~this many px per frame (30fps). */
const RIPPLE_SPEED_PX_PER_FRAME = 22;
/** Thickness of the visible ring (Gaussian σ in px). */
const RIPPLE_SIGMA_PX = 48;
const DOT_PEAK_ALPHA = 0.82;
const DOT_COLOR = "130, 198, 255";
/** Ripple strength fades to 0 between these fractions of half-diagonal (never reaches frame edge). */
const RIPPLE_FADE_START_FRAC = 0.34;
const RIPPLE_FADE_END_FRAC = 0.56;

// ── burst-mode tuning ──────────────────────────────────────────────────────
const BURST_SPACING = 18;
const BURST_SPEED_PX_PER_FRAME = 30;
const BURST_PEAK_ALPHA = 0.96;
const BURST_BASE_COLOR = [120, 195, 255] as const; // trailing blue
const BURST_HOT_COLOR = [236, 246, 255] as const;  // white-hot leading edge
// Trailing echo fronts: [radius offset behind the leading front, gaussian σ, weight].
const BURST_FRONTS: ReadonlyArray<readonly [number, number, number]> = [
  [0, 38, 1.0],
  [130, 58, 0.52],
  [250, 78, 0.3],
];

function rippleFrontRadius(frame: number): number {
  return frame * RIPPLE_SPEED_PX_PER_FRAME;
}

/**
 * Frames after ripple start until the ring has cleared the frame corners (fullBleed),
 * plus one frame — first global frame where the downward exit may begin.
 * Matches `rippleFrontRadius` / `RIPPLE_SPEED_PX_PER_FRAME` / `RIPPLE_SIGMA_PX`.
 */
export function getRippleDotGridExitStartOffsetFrames(
  width: number,
  height: number,
): number {
  const maxDist = Math.hypot(width, height) * 0.5;
  const frontNeeded = maxDist + 4 * RIPPLE_SIGMA_PX;
  const fLast = Math.ceil(frontNeeded / RIPPLE_SPEED_PX_PER_FRAME);
  return fLast + 1;
}

function outwardRippleFade(rippleFront: number, maxDist: number): number {
  const start = maxDist * RIPPLE_FADE_START_FRAC;
  const end = maxDist * RIPPLE_FADE_END_FRAC;
  if (rippleFront <= start) {
    return 1;
  }
  if (rippleFront >= end) {
    return 0;
  }
  const t = (rippleFront - start) / (end - start);
  return 1 - t * t * (3 - 2 * t);
}

type RippleDotGridProps = {
  /** Frames since dark background / ripple start (0 = first frame). */
  frame: number;
  /** Let the ripple expand all the way to the frame edges (no early fade-out). */
  fullBleed?: boolean;
  /** Enhanced, much more powerful multi-front shockwave. */
  burst?: boolean;
};

export const RippleDotGrid: React.FC<RippleDotGridProps> = ({
  frame,
  fullBleed = false,
  burst = false,
}) => {
  const { width, height } = useVideoConfig();
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const speed = burst ? BURST_SPEED_PX_PER_FRAME : RIPPLE_SPEED_PX_PER_FRAME;
  const front = frame * speed;
  const maxDist = Math.hypot(width, height) * 0.5;
  const rippleDissolve = fullBleed ? 1 : outwardRippleFade(front, maxDist);
  const glowRadiusPx = Math.min(
    front * (burst ? 2.4 : 2) + (burst ? 200 : 140),
    Math.max(width, height) * (burst ? 1.15 : 0.95),
  );

  // Impact flash (burst only): a quick bright pop right at the moment the wave is born.
  const flashOp = burst
    ? frame < 2
      ? frame / 2
      : Math.max(0, 1 - (frame - 2) / 12)
    : 0;

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || width <= 0 || height <= 0) {
      return;
    }
    const ctx = canvas.getContext("2d");
    if (!ctx) {
      return;
    }

    const dpr =
      typeof window !== "undefined" ? Math.min(window.devicePixelRatio || 1, 2) : 1;
    canvas.width = Math.floor(width * dpr);
    canvas.height = Math.floor(height * dpr);
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    ctx.clearRect(0, 0, width, height);

    const cx = width / 2;
    const cy = height / 2;
    const rippleFront = frame * speed;
    const dissolve = fullBleed ? 1 : outwardRippleFade(rippleFront, maxDist);

    if (!burst) {
      // ── classic single-front pulse ──────────────────────────────────────
      // No per-dot ctx.shadowBlur here: at up to ~2,300 dots/frame, a shadow
      // (an offscreen blur pass per shape) is by far the most expensive thing
      // a canvas can do, and was the primary cause of this preset dropping
      // frames / feeling like it hung. A slightly larger, softer-alpha dot
      // reads as glowing without paying for a real blur — the ambient
      // radial-gradient glow layer underneath (see the JSX below) already
      // carries the actual light-bloom feel.
      const sigma2 = 2 * RIPPLE_SIGMA_PX * RIPPLE_SIGMA_PX;
      ctx.fillStyle = `rgb(${DOT_COLOR})`;
      for (let gx = 0; gx <= width + DOT_SPACING; gx += DOT_SPACING) {
        for (let gy = 0; gy <= height + DOT_SPACING; gy += DOT_SPACING) {
          const dx = gx - cx;
          const dy = gy - cy;
          const dist = Math.hypot(dx, dy);
          const ringMask = Math.exp(-((dist - rippleFront) ** 2) / sigma2);
          const outerFade = fullBleed
            ? 1
            : Math.pow(Math.max(0, 1 - dist / (maxDist * 1.02)), 1.25);
          const alpha = DOT_PEAK_ALPHA * ringMask * outerFade * dissolve;
          if (alpha < 0.012) {
            continue;
          }
          const a = Math.min(0.98, alpha);
          ctx.globalAlpha = a;
          ctx.beginPath();
          ctx.arc(gx, gy, DOT_RADIUS * 1.6, 0, Math.PI * 2);
          ctx.fill();
        }
      }
      ctx.globalAlpha = 1;
      return;
    }

    // ── burst: layered shockwave with swelling, colour-shifting dots ───────
    const [br, bg, bb] = BURST_BASE_COLOR;
    const [hr, hg, hb] = BURST_HOT_COLOR;
    const mainSigma2 = 2 * 38 * 38; // for the leading-edge colour blend
    ctx.globalCompositeOperation = "lighter"; // additive — overlapping glows build energy

    for (let gx = 0; gx <= width + BURST_SPACING; gx += BURST_SPACING) {
      for (let gy = 0; gy <= height + BURST_SPACING; gy += BURST_SPACING) {
        const dx = gx - cx;
        const dy = gy - cy;
        const dist = Math.hypot(dx, dy);

        // Sum the three wave fronts (leading + two trailing echoes).
        let ring = 0;
        for (const [offset, sigma, weight] of BURST_FRONTS) {
          const r = rippleFront - offset;
          if (r <= 0) continue;
          ring += weight * Math.exp(-((dist - r) ** 2) / (2 * sigma * sigma));
        }
        if (ring < 0.015) {
          continue;
        }
        ring = Math.min(1.35, ring);

        const outerFade = fullBleed
          ? 1
          : Math.pow(Math.max(0, 1 - dist / (maxDist * 1.06)), 1.1);
        const alpha = BURST_PEAK_ALPHA * Math.min(1, ring) * outerFade * dissolve;
        if (alpha < 0.012) {
          continue;
        }

        // Dots swell as the wave passes; leading edge goes white-hot.
        const nearMain = Math.exp(-((dist - rippleFront) ** 2) / mainSigma2);
        const dotR = DOT_RADIUS * (1 + 1.9 * Math.min(1, ring));
        const cr = Math.round(br + (hr - br) * nearMain);
        const cg = Math.round(bg + (hg - bg) * nearMain);
        const cb = Math.round(bb + (hb - bb) * nearMain);
        const a = Math.min(0.99, alpha);

        // No per-dot ctx.shadowBlur (see the classic-mode loop above for why) —
        // dotR already swells near the wave front, which reads as glow/energy
        // without paying for a blur pass on every one of these ~4,700 dots.
        ctx.beginPath();
        ctx.arc(gx, gy, dotR, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(${cr}, ${cg}, ${cb}, ${a})`;
        ctx.fill();
      }
    }

    // Bright stroked energy ring riding the leading front + one inner echo.
    const ringFronts: ReadonlyArray<readonly [number, number, number]> = [
      [rippleFront, 3.6, 0.6],
      [rippleFront - 130, 2.2, 0.28],
    ];
    for (const [r, lw, w] of ringFronts) {
      if (r <= 4) continue;
      const ra = w * dissolve * Math.pow(Math.max(0, 1 - r / (maxDist * 1.08)), 1.2);
      if (ra < 0.01) continue;
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.lineWidth = lw;
      ctx.strokeStyle = `rgba(190, 228, 255, ${ra})`;
      ctx.shadowBlur = 20;
      ctx.shadowColor = `rgba(120, 190, 255, ${ra * 0.9})`;
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    ctx.globalCompositeOperation = "source-over";
  }, [frame, width, height, maxDist, burst, fullBleed, speed]);

  return (
    <AbsoluteFill style={{ pointerEvents: "none", zIndex: 1 }}>
      <div
        style={{
          position: "absolute",
          inset: 0,
          opacity: rippleDissolve,
          mixBlendMode: burst ? "screen" : "normal",
          background: burst
            ? `radial-gradient(circle ${glowRadiusPx}px at 50% 50%, rgba(70, 140, 255, 0.42) 0%, rgba(24, 70, 170, 0.14) 46%, transparent 72%)`
            : `radial-gradient(circle ${glowRadiusPx}px at 50% 50%, rgba(35, 90, 200, 0.26) 0%, rgba(12, 40, 100, 0.06) 48%, transparent 72%)`,
        }}
      />
      <canvas
        ref={canvasRef}
        style={{
          position: "absolute",
          inset: 0,
          display: "block",
        }}
      />
      {burst && flashOp > 0 ? (
        <div
          style={{
            position: "absolute",
            inset: 0,
            opacity: flashOp,
            mixBlendMode: "screen",
            background:
              "radial-gradient(circle 38% at 50% 50%, rgba(220, 238, 255, 0.95) 0%, rgba(90, 165, 255, 0.4) 38%, transparent 68%)",
          }}
        />
      ) : null}
    </AbsoluteFill>
  );
};
