import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';

type BlobSpec = {
  cx: number;
  cy: number;
  size: number;
  blur: number;
  opacity: number;
  ampX: number;
  ampY: number;
  speedX: number;
  speedY: number;
  phase: number;
  brightnessPulse?: {
    boost: number;
    speed: number;
    phase: number;
    sharpness?: number;
  };
};

// 1920×1080 design-space centers
const BLOB_SPECS: BlobSpec[] = [
  {
    cx: 1480,
    cy: 220,
    size: 920,
    blur: 150,
    opacity: 0.72,
    ampX: 140,
    ampY: 100,
    speedX: 0.38,
    speedY: 0.31,
    phase: 0,
    brightnessPulse: {boost: 0.38, speed: 0.33, phase: 0.2, sharpness: 2.5},
  },
  {
    cx: 120,
    cy: 420,
    size: 780,
    blur: 130,
    opacity: 0.5,
    ampX: 110,
    ampY: 130,
    speedX: -0.33,
    speedY: 0.26,
    phase: 1.7,
  },
  {
    cx: 960,
    cy: 640,
    size: 640,
    blur: 120,
    opacity: 0.35,
    ampX: 90,
    ampY: 70,
    speedX: 0.24,
    speedY: -0.36,
    phase: 0.9,
  },
  {
    cx: 1720,
    cy: 780,
    size: 520,
    blur: 100,
    opacity: 0.42,
    ampX: 80,
    ampY: 95,
    speedX: -0.29,
    speedY: 0.22,
    phase: 2.4,
  },
];

const AnimatedBlobField: React.FC<{
  specs: BlobSpec[];
  blobColor: string;
  frame: number;
  fps: number;
}> = ({specs, blobColor, frame, fps}) => {
  const t = (frame / fps) * 2;

  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {specs.map((spec, i) => {
        const ox = Math.sin(t * spec.speedX + spec.phase) * spec.ampX;
        const oy = Math.cos(t * spec.speedY + spec.phase) * spec.ampY;

        // The brightness pulse used to ride inside the SAME filter as the blur
        // (`blur(Xpx) brightness(Y)`), so every frame it changed forced the
        // browser to re-rasterize the whole blurred blob instead of reusing a
        // cached layer — expensive at these blur radii (100-150px) x4 blobs.
        // Folding the boost into opacity alone keeps the blur filter CONSTANT
        // per blob, so only a cheap opacity/transform composite happens per frame.
        let opacity = spec.opacity;
        if (spec.brightnessPulse) {
          const {boost, speed, phase, sharpness = 1} = spec.brightnessPulse;
          const wave = (Math.sin(t * speed + phase) + 1) / 2;
          const shaped = Math.pow(wave, sharpness);
          opacity = spec.opacity + boost * shaped;
        }

        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: spec.cx - spec.size / 2,
              top: spec.cy - spec.size / 2,
              width: spec.size,
              height: spec.size,
              opacity,
              transform: `translate(${ox}px, ${oy}px)`,
            }}
          >
            <div
              style={{
                width: '100%',
                height: '100%',
                borderRadius: '50%',
                background: blobColor,
                filter: `blur(${spec.blur}px)`,
              }}
            />
          </div>
        );
      })}
    </AbsoluteFill>
  );
};

export type BlobBackgroundProps = {
  bgColor: string;
  blobColor: string;
};

export const BlobBackground: React.FC<BlobBackgroundProps> = ({bgColor, blobColor}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();

  return (
    <AbsoluteFill style={{background: bgColor}}>
      <AnimatedBlobField
        specs={BLOB_SPECS}
        blobColor={blobColor}
        frame={frame}
        fps={fps}
      />
    </AbsoluteFill>
  );
};
