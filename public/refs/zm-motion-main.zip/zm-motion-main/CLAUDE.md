See [AGENTS.md](./AGENTS.md) — conventions, mounting rules, the frame-space contract, and
how to add a component.

Single source of truth deliberately: two copies of the same guidance drift, and the stale
one is the one that gets read.
