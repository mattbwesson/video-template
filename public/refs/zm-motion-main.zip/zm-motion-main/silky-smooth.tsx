/**
 * silky-smooth.tsx — a headline that glides in word by word and, optionally,
 * glides back out in reverse.
 *
 * THE MECHANIC: every word fades up and slides right into place on a long
 * ease-out, cubic-bezier(0.06, 0.83, 0.05, 0.99). Two details are what make it
 * read as silk rather than as a stagger:
 *
 *   • The slide outlasts the fade. Opacity finishes at 700ms; the travel keeps
 *     easing for another 500ms, so a word is fully visible while still drifting
 *     the last pixels into place. Nothing ever visibly "arrives".
 *   • The block moves too. The whole line slides across the same span the last
 *     word needs to settle, so the words are gliding inside a frame that is
 *     itself gliding — the motion never resolves to a single velocity.
 *
 * The exit is the entrance played backwards through an ease-IN curve,
 * cubic-bezier(0.82, 0, 0.98, 0.26): the LAST word to arrive is the first to
 * leave, each fading and sliding right, with the block drifting right behind
 * them. Set `exitStartFrame` to enable it; omit it and the text simply stays.
 *
 * Timing is derived from seconds × fps, so the motion holds its real-world pace
 * at any composition rate. Reach for `silkySmoothDuration` rather than counting
 * the frames yourself — the total is a non-obvious sum of the stagger window,
 * the slide tail and the exit cascade.
 */
import type { CSSProperties } from "react";
import { Easing, interpolate, useCurrentFrame, useVideoConfig } from "remotion";

// The two curves the whole effect rests on. The entrance is a long ease-out that
// spends most of its time nearly settled; the exit is its mirror, an ease-in
// that starts imperceptibly and accelerates away.
const ENTER_EASE = Easing.bezier(0.06, 0.83, 0.05, 0.99);
const EXIT_EASE = Easing.bezier(0.82, 0.0, 0.98, 0.26);

const FADE_SECONDS = 0.7;
// The slide keeps easing for this long AFTER the fade completes. This overhang
// is the effect — remove it and the words snap into place on arrival.
const SLIDE_OVERHANG_SECONDS = 0.5;
const EXIT_SECONDS = 0.7;

/**
 * Sub-frame precision is deliberate here: these feed `interpolate` ranges, not
 * mount lengths, so rounding to whole frames would quantise the cascade and
 * cost the effect its smoothness. `framesFor` is used only where an integer
 * frame count is genuinely required — see `silkySmoothDuration`.
 */
function spans(fps: number) {
  const fade = FADE_SECONDS * fps;
  return {
    fade,
    slide: fade + SLIDE_OVERHANG_SECONDS * fps,
    exit: EXIT_SECONDS * fps,
  };
}

export interface SilkySmoothTiming {
  /** The headline. Use "\n" to break it into lines. */
  text: string;
  /**
   * Frame span across which the word entrances are triggered — the last word
   * starts here. Default 15. Widen it for a lazier cascade.
   */
  staggerWindowFrames?: number;
  /**
   * Frame the exit begins, on the component's own timeline. Omit to have the
   * text enter and stay.
   */
  exitStartFrame?: number;
}

export interface SilkySmoothProps extends SilkySmoothTiming {
  /** Type size in px. Default 64. */
  fontSize?: number;
  /** Text colour. Default "currentColor" — inherits from the caller. */
  color?: string;
  /** Font weight. Default 600. */
  fontWeight?: number;
  /**
   * Font stack. Default "inherit": the library ships no fonts, so inheriting
   * keeps the headline in whatever the surrounding composition already loaded.
   */
  fontFamily?: string;
  /** How far each word travels into place, in px. Default 20. */
  distance?: number;
  /** How far the whole block travels, in px. Default 100. */
  blockDistance?: number;
  /** Merged onto the centring container. */
  style?: CSSProperties;
}

/**
 * Total frames the effect occupies, entrance through exit. Pass the same timing
 * you give the component. Without `exitStartFrame` this is just the time the
 * last word needs to fully settle.
 */
export function silkySmoothDuration(timing: SilkySmoothTiming, fps: number): number {
  const { text, staggerWindowFrames = 15, exitStartFrame } = timing;
  const { slide, exit } = spans(fps);
  const enterEnd = staggerWindowFrames + slide;
  const exitEnd =
    exitStartFrame === undefined ? 0 : exitStartFrame + staggerWindowFrames + exit;
  return Math.ceil(Math.max(enterEnd, exitEnd));
}

/** Word count, for callers pacing something else against the cascade. */
export function silkySmoothWordCount(text: string): number {
  return text
    .split("\n")
    .reduce((sum, line) => sum + line.split(" ").filter(Boolean).length, 0);
}

/**
 * The gliding headline. See the file header for the mechanic; use
 * `silkySmoothDuration` for its length rather than counting frames by hand.
 */
export function SilkySmooth({
  text,
  fontSize = 64,
  color = "currentColor",
  fontWeight = 600,
  fontFamily = "inherit",
  staggerWindowFrames = 15,
  distance = 20,
  blockDistance = 100,
  exitStartFrame,
  style,
}: SilkySmoothProps) {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { fade, slide, exit } = spans(fps);

  const lines = text.split("\n").map((line) => line.split(" "));
  const wordCount = lines.reduce((sum, line) => sum + line.length, 0);
  const staggerPerWord = wordCount > 1 ? staggerWindowFrames / (wordCount - 1) : 0;

  // The block travels across the same span the last word needs to settle, so the
  // words glide inside a frame that is itself gliding.
  const blockProgress = interpolate(
    frame,
    [0, staggerWindowFrames + slide],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ENTER_EASE },
  );

  const blockExitProgress =
    exitStartFrame === undefined
      ? 0
      : interpolate(
          frame,
          [exitStartFrame, exitStartFrame + staggerWindowFrames + exit],
          [0, 1],
          { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: EXIT_EASE },
        );

  const blockX =
    interpolate(blockProgress, [0, 1], [-blockDistance, 0]) +
    interpolate(blockExitProgress, [0, 1], [0, blockDistance]);

  let wordIndex = 0;

  return (
    <div
      style={{
        position: "absolute",
        inset: 0,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        transform: `translateX(${blockX}px)`,
        ...style,
      }}
    >
      {lines.map((words, lineI) => (
        <span
          key={lineI}
          style={{
            fontFamily,
            fontSize,
            fontWeight,
            color,
            letterSpacing: "-0.02em",
            display: "inline-block",
            whiteSpace: "nowrap",
          }}
        >
          {words.map((word, i) => {
            const thisWordIndex = wordIndex;
            wordIndex += 1;

            const startFrame = thisWordIndex * staggerPerWord;
            const enterOpacity = interpolate(
              frame,
              [startFrame, startFrame + fade],
              [0, 1],
              { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ENTER_EASE },
            );
            const enterSlide = interpolate(
              frame,
              [startFrame, startFrame + slide],
              [0, 1],
              { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: ENTER_EASE },
            );

            // Reversed order: the last word in is the first out, so the line
            // unbuilds the way it was built rather than wiping.
            const reversedIndex = wordCount - 1 - thisWordIndex;
            const exitWordStart = (exitStartFrame ?? 0) + reversedIndex * staggerPerWord;
            const exitOpacity =
              exitStartFrame === undefined
                ? 1
                : interpolate(frame, [exitWordStart, exitWordStart + exit], [1, 0], {
                    extrapolateLeft: "clamp",
                    extrapolateRight: "clamp",
                    easing: EXIT_EASE,
                  });
            const exitSlide =
              exitStartFrame === undefined
                ? 0
                : interpolate(frame, [exitWordStart, exitWordStart + exit], [0, 1], {
                    extrapolateLeft: "clamp",
                    extrapolateRight: "clamp",
                    easing: EXIT_EASE,
                  });

            return (
              <span
                key={i}
                style={{
                  display: "inline-block",
                  marginRight: "0.28em",
                  opacity: enterOpacity * exitOpacity,
                  transform: `translateX(${
                    interpolate(enterSlide, [0, 1], [-distance, 0]) +
                    interpolate(exitSlide, [0, 1], [0, distance])
                  }px)`,
                }}
              >
                {word}
              </span>
            );
          })}
        </span>
      ))}
    </div>
  );
}
