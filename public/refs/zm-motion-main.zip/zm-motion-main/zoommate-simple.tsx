/**
 * zoommate-simple.tsx — the ZoomMate composer on its own: a prompt field that
 * opens an attachment menu, ticks its rows one by one, then types a prompt.
 *
 * "Simple" because it is the composer WITHOUT the surrounding product chrome —
 * no rails, no header, no thread. Drop it on any background and it reads as the
 * input, which is what most storytelling actually needs.
 *
 * THE BEAT ORDER (defaults in brackets, all configurable via the schedule):
 *   • 2→30      the sparkle and "ZoomMate is ready to help" converge above the card
 *               from opposite sides, while the card's conic glow fades out.
 *   • [50]      the cursor flies in to the plus button and clicks it.
 *   • [77]      the attachment menu springs open below the card.
 *   • [100]+15  the cursor drops row by row, ticking each checkbox as it lands.
 *   • then      the cursor returns to the field and the menu fades away.
 *   • [155]→60  the prompt types out; the pill grows into a card as it wraps.
 *
 * Every one of those is derived from six numbers — see `ZoomMateSimpleSchedule`.
 * The interlocks are the point: checkbox ticks fire where the cursor lands, the
 * menu dismisses as the cursor leaves, and the field expands mid-sentence. Move
 * one beat and the rest follow, so use `zoomMateSimpleBeats` rather than
 * hand-timing anything against it.
 *
 * Scope: this is the source composition's frames 0–215. The send-button click
 * that follows it is deliberately not here — the composer ends holding a typed,
 * unsent prompt, which is the frame you want to cut on or match-cut out of.
 */
import type { CSSProperties, ReactNode } from "react";
import {
  Easing,
  interpolate,
  spring,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { Cursor } from "./cursor";
import { SPARKLE_SPRITE_FRAME_COUNT, SparkleSprite } from "./sparkle-mask-outro";

// ── Layout constants ────────────────────────────────────────────────────────────────
// Tuned as a set against the 1200px card: the menu hangs off the card's own left
// inset, and the cursor's row targets are the menu's row rhythm. Change one and
// the cursor stops landing on the checkboxes.

/** Card height in its single-line pill state, and once it has grown into a card. */
const PILL_HEIGHT = 147;
const CARD_HEIGHT = 232;
/** Left inset shared by the plus button and the menu, so they align. */
const GUTTER = 46;
/** Y of the first attachment row's checkbox, and the pitch between rows. */
const FIRST_ROW_Y = 275;
const ROW_PITCH = 64;
/** Where the cursor rests while hovering the plus button. */
const PLUS_HOVER_X = 90;
const PLUS_HOVER_Y = 73;
/** X the cursor settles on while working down the checkbox column. */
const COLUMN_X = 96;

const FONT_STACK =
  '-apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Public Sans", "Liberation Sans", Arial, sans-serif';

const FLY_IN_EASE = Easing.bezier(0.19, 0.88, 0.24, 0.99);
const RETURN_EASE = Easing.bezier(0.53, 0.04, 0.16, 0.99);
const SETTLE_EASE = Easing.bezier(0.22, 1.0, 0.36, 1.0);

// ── Timing ──────────────────────────────────────────────────────────────────────────

export interface ZoomMateSimpleSchedule {
  /** Frame the cursor flies in toward the plus button. Default 50. */
  cursorInFrame?: number;
  /** Frame the plus is clicked and the menu opens. Default 77. */
  menuOpenFrame?: number;
  /** Frame the first attachment row is ticked. Default 100. */
  firstCheckFrame?: number;
  /** Frames between one row being ticked and the next. Default 15. */
  checkIntervalFrames?: number;
  /** Frame the prompt starts typing. Default 155. */
  typingStartFrame?: number;
  /** Frames the prompt takes to type out in full. Default 60. */
  typingDurationInFrames?: number;
}

/** Resolved frame of every beat, on the component's own timeline. */
export interface ZoomMateSimpleBeats {
  /** The intro glow around the pill has finished fading out. */
  glowGone: number;
  /** Cursor starts its fly-in, and reaches the plus button. */
  cursorIn: number;
  cursorAtPlus: number;
  /** The plus is clicked and the menu springs open / is fully open. */
  menuOpen: number;
  menuFullyOpen: number;
  /** Frame each attachment row is ticked, in order. */
  checkFrames: number[];
  /** Cursor leaves the last row, and arrives back at the field. */
  returnStart: number;
  returnEnd: number;
  /** The menu has fully faded away. */
  menuGone: number;
  /** The prompt starts and finishes typing. */
  typingStart: number;
  typingEnd: number;
}

function resolve(schedule: ZoomMateSimpleSchedule, rowCount: number) {
  const {
    cursorInFrame = 50,
    menuOpenFrame = 77,
    firstCheckFrame = 100,
    checkIntervalFrames = 15,
    typingStartFrame = 155,
    typingDurationInFrames = 60,
  } = schedule;

  const checkFrames = Array.from(
    { length: Math.max(0, rowCount) },
    (_, i) => firstCheckFrame + i * checkIntervalFrames,
  );
  const lastCheck = checkFrames.length
    ? checkFrames[checkFrames.length - 1]
    : firstCheckFrame;

  return {
    cursorInFrame,
    menuOpenFrame,
    checkFrames,
    lastCheck,
    typingStartFrame,
    typingDurationInFrames,
    // The cursor holds on the last row for a beat before heading back up, and
    // the menu only starts dismissing once it has left.
    returnStart: lastCheck + 9,
    returnEnd: typingStartFrame,
  };
}

/**
 * Every beat as a frame number. Use it to schedule anything alongside the
 * composer — a match cut on `typingEnd`, a caption on `menuFullyOpen` — rather
 * than re-deriving the arithmetic, which is interlocked and easy to get subtly wrong.
 */
export function zoomMateSimpleBeats(
  schedule: ZoomMateSimpleSchedule = {},
  rowCount = 3,
): ZoomMateSimpleBeats {
  const r = resolve(schedule, rowCount);
  return {
    glowGone: 30,
    cursorIn: r.cursorInFrame,
    cursorAtPlus: r.cursorInFrame + 21,
    menuOpen: r.menuOpenFrame,
    menuFullyOpen: r.menuOpenFrame + 10,
    checkFrames: r.checkFrames,
    returnStart: r.returnStart,
    returnEnd: r.returnEnd,
    menuGone: r.returnStart + 14,
    typingStart: r.typingStartFrame,
    typingEnd: r.typingStartFrame + r.typingDurationInFrames,
  };
}

/**
 * Total frames the sequence occupies, ending on the fully typed prompt. Add your
 * own hold if you want to sit on it before cutting.
 */
export function zoomMateSimpleDuration(
  schedule: ZoomMateSimpleSchedule = {},
  rowCount = 3,
): number {
  return zoomMateSimpleBeats(schedule, rowCount).typingEnd + 1;
}

// ── Props ───────────────────────────────────────────────────────────────────────────

export interface ZoomMateAttachmentItem {
  /** Row label, e.g. "[April 18] ACME — Pilot Kickoff". */
  label: string;
  /** Overrides the default calendar glyph for this row. */
  icon?: ReactNode;
}

export interface ZoomMateSimpleProps {
  /** The prompt that types into the field. */
  prompt: string;
  /**
   * Line above the card, alongside the sparkle. Default "ZoomMate is ready to
   * help"; pass null to drop the whole lockup (sparkle included).
   */
  intro?: string | null;
  /**
   * Mark shown beside the intro line. Defaults to the 3D sparkle playing its
   * entrance. NOTE: that default is what pulls the sparkle PNG sequence into a
   * consumer's bundle — pass your own node (or `intro={null}`) if you want this
   * component to ship without those frames.
   */
  introIcon?: ReactNode;
  /**
   * Font stack for the intro line. Defaults to the same system stack the card
   * uses — no font files to load, and it matches out of the box. Pass your own
   * (or "inherit") to put the line in a brand face.
   */
  fontFamily?: string;
  /** Rows in the attachment menu, ticked in order. Default: three meetings. */
  attachments?: ZoomMateAttachmentItem[];
  /** Menu header. Default "Attach meetings & files". */
  menuTitle?: string;
  /** Card width in px. Default 1200 — the layout is tuned around it. */
  width?: number;
  /** Timing overrides; see ZoomMateSimpleSchedule. */
  schedule?: ZoomMateSimpleSchedule;
  /** Merged onto the outer wrapper. */
  style?: CSSProperties;
}

const DEFAULT_ATTACHMENTS: ZoomMateAttachmentItem[] = [
  { label: "[April 18] ACME — Pilot Kickoff & Commitments" },
  { label: "[May 12] ACME — Security Review & SSO" },
  { label: "[May 28] ACME — Support Org & API Sync" },
];

// ── Component ───────────────────────────────────────────────────────────────────────

export function ZoomMateSimple({
  prompt,
  intro = "ZoomMate is ready to help",
  introIcon,
  fontFamily = FONT_STACK,
  attachments = DEFAULT_ATTACHMENTS,
  menuTitle = "Attach meetings & files",
  width = 1200,
  schedule = {},
  style,
}: ZoomMateSimpleProps) {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const r = resolve(schedule, attachments.length);

  // ── Intro lockup ──
  // The sparkle and the line arrive from opposite sides on the same spring, six
  // frames apart, so they converge on the gap between them rather than sliding in
  // as one block. Springs need fps, which is why this is not a plain interpolate.
  const springIn = { damping: 15, stiffness: 85, mass: 0.8 };
  const introIconOpacity = interpolate(frame, [2, 18], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const introIconX = spring({
    frame: Math.max(0, frame - 2),
    fps,
    config: springIn,
    from: 140,
    to: 0,
  });
  const introTextOpacity = interpolate(frame, [8, 24], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  const introTextX = spring({
    frame: Math.max(0, frame - 6),
    fps,
    config: springIn,
    from: -35,
    to: 0,
  });
  // The sprite plays its 28 poses forward over the first 30 frames, then rests.
  const introSpriteFrame = Math.min(
    SPARKLE_SPRITE_FRAME_COUNT - 1,
    Math.floor(Math.min(frame, 30) * 0.9),
  );

  // Two conic gradients counter-rotating behind the pill, on their own clocks so
  // the sheen never repeats. Seconds-based so the spin holds its pace at any fps.
  const spin = (frame * (360 / (3 * fps))) % 360;
  const spinSlow = -(frame * (360 / (5 * fps))) % 360;
  const glowOpacity = interpolate(frame, [20, 30], [1, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // ── Cursor path ──
  // Fly in to the plus, drift into the checkbox column, drop to each row in turn,
  // then return to the field. Each leg is expressed against the beat it serves,
  // so retiming the checks moves the cursor with them.
  const flyIn = FLY_IN_EASE(
    interpolate(frame, [r.cursorInFrame, r.cursorInFrame + 21], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }),
  );
  const returnProgress = RETURN_EASE(
    interpolate(frame, [r.returnStart, r.returnEnd], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }),
  );

  const rowY = (i: number) => FIRST_ROW_Y + i * ROW_PITCH;
  // The cursor lands 4 frames before a row ticks, so the tick reads as its click
  // rather than as something that happened on its own.
  const arriveAt = (i: number) => r.checkFrames[i] - 4;
  const departFor = (i: number) =>
    i === 0 ? r.menuOpenFrame + 7 : arriveAt(i) - 10;

  const cursorAtPlus = r.cursorInFrame + 21;
  let cursorX = PLUS_HOVER_X;
  let cursorY = PLUS_HOVER_Y;

  if (frame < cursorAtPlus) {
    cursorX = 750 + (PLUS_HOVER_X - 750) * flyIn;
    cursorY = 350 + (PLUS_HOVER_Y - 350) * flyIn;
  } else if (frame < r.returnStart) {
    cursorX = interpolate(
      frame,
      [cursorAtPlus, cursorAtPlus + 13],
      [PLUS_HOVER_X, COLUMN_X],
      { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
    );
    // Walk the rows: hold on the current one until it is time to leave for the next.
    cursorY = PLUS_HOVER_Y;
    for (let i = 0; i < r.checkFrames.length; i++) {
      const from = i === 0 ? PLUS_HOVER_Y : rowY(i - 1);
      if (frame >= departFor(i)) {
        cursorY = interpolate(frame, [departFor(i), arriveAt(i)], [from, rowY(i)], {
          easing: SETTLE_EASE,
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        });
      }
    }
  } else {
    const lastRowY = r.checkFrames.length
      ? rowY(r.checkFrames.length - 1)
      : PLUS_HOVER_Y;
    cursorX = COLUMN_X + (145 - COLUMN_X) * returnProgress;
    cursorY = lastRowY + (PLUS_HOVER_Y - lastRowY) * returnProgress;
  }

  // A light dip on each click — the plus, then every row.
  const clickPoints = [r.menuOpenFrame - 1, ...r.checkFrames];
  const clickScale = clickPoints.reduce((s, at) => {
    const dip = interpolate(frame, [at - 1, at + 0.25, at + 1.5], [1, 0.94, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    });
    return Math.min(s, dip);
  }, 1);

  // Visible from the fly-in until typing starts — the hand leaves before the words.
  const cursorOpacity =
    frame >= r.cursorInFrame && frame < r.typingStartFrame
      ? interpolate(frame, [r.cursorInFrame, r.cursorInFrame + 8], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        })
      : 0;

  // ── Menu ──
  const menuOpacity = Math.min(
    interpolate(frame, [r.menuOpenFrame, r.menuOpenFrame + 8], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }),
    interpolate(frame, [r.returnStart + 6, r.returnStart + 14], [1, 0], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }),
  );
  const menuScale = interpolate(
    frame,
    [r.menuOpenFrame, r.menuOpenFrame + 10],
    [0.9, 1],
    {
      easing: Easing.out(Easing.back(1.4)),
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    },
  );
  const menuY = interpolate(
    frame,
    [r.menuOpenFrame, r.menuOpenFrame + 10],
    [-15, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );
  const isPlusActive =
    frame >= r.menuOpenFrame - 1 && frame <= r.menuOpenFrame + 3;

  // Mount gates. In Remotion an invisible element still costs a full render,
  // layout and paint — there is no compositor to skip it — so the menu and the
  // cursor are unmounted outside their own windows rather than left at opacity 0.
  const menuMounted =
    frame >= r.menuOpenFrame && frame < r.returnStart + 14;
  const cursorMounted = cursorOpacity > 0;

  // ── Typing, and the pill growing into a card as the text wraps ──
  const typedCount = Math.floor(
    interpolate(
      frame,
      [r.typingStartFrame, r.typingStartFrame + r.typingDurationInFrames],
      [0, prompt.length],
      { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
    ),
  );
  const displayed = frame >= r.typingStartFrame ? prompt.slice(0, typedCount) : "";

  // The field grows partway through the sentence, where the text reaches line two.
  const expandStart =
    r.typingStartFrame + Math.round(r.typingDurationInFrames * (25 / 60));
  const expand = interpolate(frame, [expandStart, expandStart + 12], [0, 1], {
    easing: Easing.bezier(0.25, 0.1, 0.25, 1),
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  const cardHeight = PILL_HEIGHT + (CARD_HEIGHT - PILL_HEIGHT) * expand;
  // 73.5 is exactly half the pill's height, so the ends stay perfectly round
  // until it starts becoming a card.
  const borderRadius = 73.5 - (73.5 - 44) * expand;
  const buttonTop = 37.5 + (142 - 37.5) * expand;
  const textLeft = 136 - (136 - 48) * expand;
  const textRight = 120 - (120 - 48) * expand;
  const textTop = 49.5 - (49.5 - 28) * expand;

  const typingActive =
    frame >= r.typingStartFrame &&
    frame <= r.typingStartFrame + r.typingDurationInFrames + 5;
  const showCaret = typingActive && Math.floor(frame / 7) % 2 === 0;

  return (
    <div
      style={{
        position: "relative",
        display: "inline-flex",
        borderRadius,
        padding: "3.5px",
        ...style,
      }}
    >
      {/* Intro lockup, sitting above the card and outside its bounds */}
      {intro !== null && (
        <div
          style={{
            position: "absolute",
            bottom: "100%",
            marginBottom: 52,
            left: 0,
            right: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 14,
            pointerEvents: "none",
          }}
        >
          <div
            style={{
              opacity: introIconOpacity,
              transform: `translateX(${introIconX}px)`,
            }}
          >
            {introIcon ?? (
              <SparkleSprite size={120} frameIndex={introSpriteFrame} />
            )}
          </div>
          <div
            style={{
              opacity: introTextOpacity,
              transform: `translateX(${introTextX}px)`,
              fontSize: 54,
              lineHeight: "64px",
              fontWeight: 400,
              color: "#222325",
              letterSpacing: "-0.4px",
              whiteSpace: "nowrap",
              fontFamily,
            }}
          >
            {intro}
          </div>
        </div>
      )}

      {/* Attachment menu, hanging off the card's left gutter */}
      {menuMounted && (
      <div
        style={{
          position: "absolute",
          left: GUTTER,
          top: 165,
          width: 660,
          background: "#ffffff",
          border: "1px solid #E8E8E8",
          borderRadius: 20,
          boxShadow:
            "0 20px 52px -14px rgba(30,40,80,.20), 0 3px 10px -3px rgba(30,40,80,.10)",
          padding: "14px 0 12px",
          fontSize: 24,
          letterSpacing: "-0.1px",
          zIndex: 50,
          opacity: menuOpacity,
          transform: `translateY(${menuY}px) scale(${menuScale})`,
          transformOrigin: "top left",
          pointerEvents: "none",
          fontFamily: FONT_STACK,
        }}
      >
        <div
          style={{
            height: 58,
            display: "flex",
            alignItems: "center",
            padding: "0 36px",
            color: "#1A1A1A",
            fontWeight: 600,
            whiteSpace: "nowrap",
          }}
        >
          <AttachGlyph />
          {menuTitle}
        </div>

        <div style={{ height: 1, background: "#EDEDED", margin: "6px 36px 8px" }} />

        {attachments.map((item, i) => {
          const checked = frame >= r.checkFrames[i];
          return (
            <div
              key={i}
              style={{
                minHeight: ROW_PITCH,
                display: "flex",
                alignItems: "center",
                gap: 16,
                padding: "8px 36px",
                color: "#1A1A1A",
              }}
            >
              <Checkbox checked={checked} />
              {item.icon ?? <CalendarGlyph />}
              <span
                style={{
                  flex: 1,
                  minWidth: 0,
                  wordBreak: "break-word",
                  lineHeight: 1.3,
                }}
              >
                {item.label}
              </span>
            </div>
          );
        })}
      </div>
      )}

      {/* Cursor — the library primitive rather than a bundled SVG, so the
          component ships no assets and inherits the gallery's theme. */}
      {cursorMounted && (
        <div
          style={{
            position: "absolute",
            left: 0,
            top: 0,
            zIndex: 100,
            opacity: cursorOpacity,
            pointerEvents: "none",
          }}
        >
          <Cursor
            size={56}
            style={{
              x: cursorX,
              y: cursorY,
              scale: clickScale,
              rippleOpacity: 0,
              rippleScale: 0,
            }}
          />
        </div>
      )}

      {/* Conic entrance glow, and its counter-rotating sheen */}
      <span
        style={{
          position: "absolute",
          inset: 0,
          overflow: "hidden",
          borderRadius,
          opacity: glowOpacity,
        }}
      >
        <span
          style={{
            position: "absolute",
            inset: "-200%",
            background:
              "conic-gradient(from 0deg, #3b82f6 0deg, #6366f1 60deg, #8b5cf6 120deg, #a855f7 180deg, #d946ef 240deg, #0061d5 300deg, #3b82f6 360deg)",
            opacity: 0.95,
            transform: `rotate(${spin}deg)`,
            transformOrigin: "center center",
          }}
        />
      </span>
      <span
        style={{
          position: "absolute",
          inset: 0,
          overflow: "hidden",
          borderRadius,
          opacity: 0.45 * glowOpacity,
          mixBlendMode: "soft-light",
        }}
      >
        <span
          style={{
            position: "absolute",
            inset: "-200%",
            background:
              "conic-gradient(from 180deg, #60a5fa 0%, transparent 30%, #a855f7 50%, transparent 70%, #0061d5 100%)",
            transform: `rotate(${spinSlow}deg)`,
            transformOrigin: "center center",
          }}
        />
      </span>

      {/* The field itself */}
      <div
        style={{
          position: "relative",
          zIndex: 10,
          width,
          height: cardHeight,
          background: "#ffffff",
          borderRadius,
          overflow: "hidden",
          border: "1px solid #E8E8E8",
          fontFamily: FONT_STACK,
          boxSizing: "border-box",
          boxShadow:
            "inset 0 1px 0 rgba(255,255,255,0.72), inset 0 -1px 0 rgba(15,23,42,0.08), 0 1px 1px rgba(15,23,42,0.08), 0 12px 32px rgba(15,23,42,0.14)",
        }}
      >
        <span
          style={{
            position: "absolute",
            left: GUTTER,
            top: buttonTop,
            width: 72,
            height: 72,
            borderRadius: 9999,
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#5F5F5F",
            background: isPlusActive ? "#EDEEF1" : "transparent",
            zIndex: 15,
          }}
        >
          <svg style={{ width: 36, height: 36, display: "block" }} viewBox="0 0 16 16">
            <path
              d="M7.99805 1.90039C8.32942 1.90039 8.59766 2.16863 8.59766 2.5V7.40039H13.498C13.8294 7.40039 14.0977 7.66863 14.0977 8C14.0977 8.33137 13.8294 8.59961 13.498 8.59961H8.59766V13.5C8.59766 13.8314 8.32942 14.0996 7.99805 14.0996C7.66668 14.0996 7.39844 13.8314 7.39844 13.5V8.59961H2.49805C2.16668 8.59961 1.89844 8.33137 1.89844 8C1.89844 7.66863 2.16668 7.40039 2.49805 7.40039H7.39844V2.5C7.39844 2.16863 7.66668 1.90039 7.99805 1.90039Z"
              fill="currentColor"
            />
          </svg>
        </span>

        <span
          style={{
            position: "absolute",
            right: 30,
            top: buttonTop,
            width: 72,
            height: 72,
            borderRadius: 9999,
            background:
              "radial-gradient(circle at 20% 80%,#528fff 20%,#76b5ffe0,#99daffc2 90%)",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#ffffff",
            zIndex: 15,
          }}
        >
          <svg
            style={{
              width: 36,
              height: 36,
              fill: "none",
              stroke: "currentColor",
              strokeWidth: 3,
              strokeLinecap: "round",
              strokeLinejoin: "round",
              display: "block",
            }}
            viewBox="0 0 24 24"
          >
            <path d="m5 12 7-7 7 7" />
            <path d="M12 19V5" />
          </svg>
        </span>

        <div
          style={{
            position: "absolute",
            left: textLeft,
            right: textRight,
            top: textTop,
            fontSize: 38,
            lineHeight: "48px",
            fontWeight: 500,
            color: "#171717",
            letterSpacing: "-0.1px",
            whiteSpace: expand > 0 ? "pre-wrap" : "nowrap",
            wordBreak: "break-word",
            overflow: "hidden",
            zIndex: 10,
          }}
        >
          <span>{displayed}</span>
          {showCaret && (
            <span
              style={{
                display: "inline-block",
                width: 3,
                height: 38,
                backgroundColor: "#0B5CFF",
                marginLeft: 3,
                borderRadius: 1,
                verticalAlign: "middle",
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
}

function Checkbox({ checked }: { checked: boolean }) {
  return (
    <span
      style={{
        width: 28,
        height: 28,
        flex: "none",
        borderRadius: 7,
        border: `2px solid ${checked ? "#0B5CFF" : "#C4C4C4"}`,
        background: checked ? "#0B5CFF" : "#ffffff",
        position: "relative",
      }}
    >
      {checked && (
        <span
          style={{
            position: "absolute",
            left: 8,
            top: 3,
            width: 8,
            height: 14,
            border: "solid #ffffff",
            borderWidth: "0 3px 3px 0",
            transform: "rotate(42deg)",
          }}
        />
      )}
    </span>
  );
}

function AttachGlyph() {
  return (
    <svg
      style={{ width: 29, height: 29, marginRight: 14, flex: "none", fill: "currentColor" }}
      viewBox="0 0 16 16"
    >
      <g transform="translate(1, 0.9)">
        <path d="M8.01953 9.88867C8.25385 9.65436 8.63385 9.65436 8.86816 9.88867C9.10213 10.123 9.1023 10.5021 8.86816 10.7363L8.33789 11.2666C7.79116 11.8133 7.79116 12.7003 8.33789 13.2471C8.88464 13.7936 9.77168 13.7937 10.3184 13.2471L10.8486 12.7168C11.083 12.4825 11.462 12.4825 11.6963 12.7168C11.9306 12.9511 11.9305 13.3301 11.6963 13.5645L11.166 14.0947C10.1507 15.1101 8.50462 15.1101 7.48926 14.0947C6.47433 13.0795 6.47436 11.4342 7.48926 10.4189L8.01953 9.88867Z" />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M9.99805 0C10.3294 0 10.5977 0.268238 10.5977 0.599609V1.09961H10.7998C11.9199 1.09961 12.4804 1.0994 12.9082 1.31738C13.2845 1.50912 13.5905 1.81515 13.7822 2.19141C14.0002 2.61923 14 3.1797 14 4.2998V5.75C13.9997 6.08104 13.7314 6.34935 13.4004 6.34961C13.0691 6.34961 12.8001 6.0812 12.7998 5.75V5.69922H1.2002V10.8994C1.2002 11.4791 1.20132 11.842 1.22363 12.1152C1.24482 12.3745 1.27868 12.4463 1.28711 12.4629C1.3638 12.6134 1.48622 12.7358 1.63672 12.8125C1.65327 12.8209 1.72508 12.8548 1.98437 12.876C2.25765 12.8983 2.6205 12.8994 3.2002 12.8994H4.40039C4.73159 12.8997 5 13.1687 5 13.5C4.99974 13.831 4.73143 14.0993 4.40039 14.0996H3.2002L2.45801 14.0967C1.91644 14.0882 1.55193 14.0574 1.25977 13.9531L1.0918 13.8818C0.762562 13.7141 0.487067 13.4588 0.294922 13.1455L0.217773 13.0078C-0.000213534 12.58 8.164e-10 12.0195 8.164e-10 10.8994V4.2998C8.164e-10 3.1797 -0.000213534 2.61923 0.217773 2.19141C0.409508 1.81515 0.715544 1.50912 1.0918 1.31738C1.41263 1.15391 1.80803 1.01315 2.45801 1.10254L3.2002 1.09961H3.39844V0.599609C3.39844 0.268238 3.66668 0 3.99805 0C4.32942 0 4.59766 0.268238 4.59766 0.599609V1.09961H9.39844V0.599609C9.39844 0.268238 9.66668 0 9.99805 0ZM3.2002 2.2998C2.6205 2.2998 2.25765 2.30093 1.98437 2.32324C1.72508 2.34443 1.65327 2.37829 1.63672 2.38672C1.48622 2.46341 1.3638 2.58583 1.28711 2.73633C1.27868 2.75288 1.24482 2.82469 1.22363 3.08398C1.20132 3.35726 1.2002 3.72011 1.2002 4.2998V4.5H12.7998V4.2998C12.7998 3.72011 12.7987 3.35726 12.7764 3.08398C12.7552 2.82469 12.7213 2.65327 12.7129 2.63672C12.6362 2.48622 12.5138 2.3638 12.3633 2.28711C12.3467 2.27868 12.2749 2.24482 12.0156 2.32324C11.7423 2.30093 11.3795 2.2998 10.7998 2.2998H10.5977V2.84961C10.5977 3.18098 10.3294 3.44922 9.99805 3.44922C9.66668 3.44922 9.39844 3.18098 9.39844 2.84961V2.2998H4.59766V2.84961C4.59766 3.18098 4.32942 3.44922 3.99805 3.44922C3.66668 3.44922 3.39844 3.18098 3.39844 2.84961V2.2998H3.2002Z"
        />
        <path d="M11.0254 9.71191C11.2597 9.4776 11.6387 9.4776 11.873 9.71191C12.1072 9.94624 12.1073 10.3253 11.873 10.5596L10.459 11.9736C10.2247 12.2079 9.84566 12.2078 9.61133 11.9736C9.37701 11.7393 9.37701 11.3603 9.61133 11.126L11.0254 9.71191Z" />
        <path d="M10.3184 7.58984C11.3336 6.57489 12.9789 6.57489 13.9941 7.58984C15.0095 8.60521 15.0095 10.2512 13.9941 11.2666L13.4639 11.7969C13.2296 12.0311 12.8505 12.0311 12.6162 11.7969C12.3819 11.5626 12.382 11.1835 12.6162 10.9492L13.1465 10.4189C13.6932 9.87227 13.693 8.98522 13.1465 8.43848C12.5997 7.89174 11.7127 7.89174 11.166 8.43848L10.6357 8.96875C10.4015 9.20283 10.0224 9.2027 9.78809 8.96875C9.55377 8.73443 9.55377 8.35443 9.78809 8.12012L10.3184 7.58984Z" />
      </g>
    </svg>
  );
}

function CalendarGlyph() {
  return (
    <svg style={{ width: 29, height: 29, flex: "none", display: "block" }} viewBox="0 0 16 16">
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M9.40039 3.39648C9.4004 4.2823 10.1163 5 11 5C11.8837 5 12.5996 4.2823 12.5996 3.39648V2.00391C13.2156 2.01562 13.597 2.0592 13.9082 2.21777C14.2845 2.40951 14.5905 2.71554 14.7822 3.0918C15.0002 3.51962 15 4.08009 15 5.2002V11.7998C15 12.9199 15.0002 12.4804 14.7822 12.9082L14.7051 13.0459C14.5129 13.3592 14.2374 13.6145 13.9082 13.7822L13.7402 13.8535C13.3311 13.9995 12.7798 14 11.7998 14H4.2002L3.45801 13.9971C2.91644 13.9886 2.55193 13.9578 2.25977 13.8535L2.0918 13.7822C1.76256 13.6145 1.48707 13.3592 1.29492 13.0459L1.21777 12.9082C0.999786 12.4804 1 11.9199 1 10.7998V5.2002C1 4.08009 0.999786 3.51962 1.21777 3.0918C1.40951 2.71554 1.71554 2.40951 2.0918 2.21777C2.40302 2.0592 2.78442 2.01562 3.40039 2.00391V3.39648C3.4004 4.2823 4.11635 5 5 5C5.88365 5 6.5996 4.2823 6.59961 3.39648V2H9.40039V3.39648ZM4.59961 6.50391C3.75981 6.50391 3.33938 6.50366 3.01855 6.66699C2.73637 6.81077 2.50612 7.0401 2.3623 7.32227C2.19884 7.64309 2.19922 8.06347 2.19922 8.90332V11.4004C2.19922 12.2402 2.19884 12.6606 2.3623 12.9814C2.50612 13.2636 2.73638 13.4929 3.01855 13.6367C3.33938 13.8 3.75983 13.7998 4.59961 13.7998H11.3994C12.2394 13.7998 12.6596 13.8002 12.9805 13.6367C13.2625 13.493 13.4919 13.2635 13.6357 12.9814C13.7992 12.6606 13.7988 12.2402 13.7988 11.4004V8.90332C13.7988 8.06347 13.7992 7.64309 13.6357 7.32227C13.4919 7.04022 13.2625 6.81075 12.9805 6.66699C12.6596 6.50351 12.2394 6.50391 11.3994 6.50391H4.59961Z"
        fill="#0D6BDE"
      />
      <path
        d="M5 0.879883C5.33137 0.879883 5.59961 1.14812 5.59961 1.47949V3.40137C5.5994 3.73256 5.33124 4.00098 5 4.00098C4.66876 4.00098 4.4006 3.73256 4.40039 3.40137V1.47949C4.40039 1.14812 4.66863 0.879883 5 0.879883Z"
        fill="#0D6BDE"
      />
      <path
        d="M11 0.879883C11.3314 0.879883 11.5996 1.14812 11.5996 1.47949V3.40137C11.5994 3.73256 11.3312 4.00098 11 4.00098C10.6688 4.00098 10.4006 3.73256 10.4004 3.40137V1.47949C10.4004 1.14812 10.6686 0.879883 11 0.879883Z"
        fill="#0D6BDE"
      />
    </svg>
  );
}
