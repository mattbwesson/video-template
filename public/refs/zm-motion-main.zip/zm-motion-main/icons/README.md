# Zoom icon library

190 Zoom UI glyphs, product marks and illustrations, captured from live Zoom
surfaces and normalized to a common convention — plus the design tokens that
surround them and the tooling that keeps both current.

Every path is byte-for-byte from the source. Nothing here is drawn by hand, and
nothing should be: a plausible-looking Zoom glyph that nobody drew is wrong in a
way no reviewer catches.

## Layout

```
icons/
├── icons.json               190 records: id, name, aliases, kind, size, svg
├── icons-index.md           browsable table — ids, names, sizes, aliases (14 KB)
├── tokens.json              presence colours, type scale, control sizing, radii
├── zoom-asset-library.html  the visual gallery (open in a browser)
├── zoom-icons-additions.md  per-icon markup with prose
├── tools/                   extract → insert → dedupe → index (stdlib only)
└── pastes/                  raw captured DOM — the provenance record
```

## Finding an icon

```bash
python3 tools/icon_lookup.py "kebab menu"        # ranked matches + markup
python3 tools/icon_lookup.py ui.send-16 --svg    # exact markup, by id
python3 tools/icon_lookup.py "chat" --kind ui-glyph --size 16
```

`icons.json` is 338 KB — query it, don't read it. `icons-index.md` is the small
browsable view when you want to see what exists.

### Ids are `<kind>.<name>`, and the kind matters

27 names in this library belong to two different assets. The usual split is a
colored product tile (`app-tile`) versus a 16px monochrome line glyph
(`ui-glyph`) — so `app.chat` and `ui.chat` are different icons, and "the chat
icon" is only answerable once you say which register you mean.

Where two icons share a name *and* kind, the id carries the artboard size
(`ui.star-24` / `ui.star-16`) — but only when the sizes genuinely differ.
Otherwise the suffix is an ordinal and `section` is what tells them apart.

### When nothing matches

`icon_lookup.py` exits **1** and prints no markup. That exit code is the point:
widen the query, drop filters, or pick a documented fallback. Don't author
substitute path data.

## Tokens

`tokens.json` carries the presence palette (`#09A639` online, `#FF5500`
in-meeting, `#8E9194` offline/away), the editor type scale, the 32px-control /
16px-glyph pairing that recurs across every capture, radii and panel widths.
Each value records the paste it came from.

It also carries a `gaps` list — no grey ramp, no hover/focus states, no dark
theme, no elevation. Treat a gap like a lookup miss: capture more DOM.

## Why `pastes/` is checked in

It is the provenance record, and it has already earned its keep. The Zoom Docs
file-menu section had 21 of 29 icons mislabeled — a stray submenu chevron had
been ingested as a menu icon, sliding every subsequent label by one. That was
only recoverable because the original capture still held the menu text.
`build_tokens.py` also reads `pastes/` directly, so removing it makes the
tooling partly inert.

## Relevance to zm-motion

`orbit-animation/IconOrbitScene.tsx` currently orbits placeholder circles,
squares and diamonds, with a note to swap them for real brand icons. The nine
Zoom product marks it wants are in here — see `icons-index.md`, sections
_Tool-set glyphs_ and _Zoom product app icons (squircle logos)_.

No Remotion bindings are included on this branch; the library is checked in
as-is.

## Maintaining it

`tools/README.md` has the full workflow. The short version — after adding icons,
regenerate the derived artifacts:

```bash
python3 tools/build_index.py && python3 tools/build_tokens.py
```
