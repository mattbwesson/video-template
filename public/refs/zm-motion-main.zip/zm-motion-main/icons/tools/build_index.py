#!/usr/bin/env python3
"""
build_index.py — turn the human-facing gallery (zoom-asset-library.html) into a
machine-queryable index for the zoom-ui skill.

Emits two artifacts:
    icons.json       full records incl. SVG markup   (for icon_lookup.py to grep)
    icons-index.md   compact id/name/alias table      (small enough for a skill to read)

Nothing here rewrites path data. The gallery stays the source of truth; this is a
derived view, so re-run it after every add_icons.py insert.

    python3 tools/build_index.py
"""
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
HTML = os.path.join(ROOT, "zoom-asset-library.html")
OUT_JSON = os.path.join(ROOT, "icons.json")
OUT_MD = os.path.join(ROOT, "icons-index.md")

# ---------------------------------------------------------------- taxonomy
# kind drives which visual register a query resolves to. The single biggest
# retrieval bug this fixes: "chat" is both a colored product squircle and a
# 16px monochrome line glyph, and an agent must not confuse them.
SECTION_KIND = {
    "Brand & wordmarks": "brand",
    "ZoomMate": "brand",
    "Zoom product app icons (squircle logos)": "app-squircle",
    "Tool-set glyphs": "app-tile",
    "Skill & onboarding illustrations": "illustration",
}
DEFAULT_KIND = "ui-glyph"

SECTION_SLOTS = {
    "Chat & navigation glyphs": ["nav-rail", "sidebar"],
    "Workflow node glyphs": ["canvas", "workflow-node"],
    "Tool-set glyphs": ["app-launcher", "tool-picker"],
    "UI glyphs (16×16, currentColor)": ["toolbar", "nav-rail", "inline"],
    "Chat widget glyphs": ["composer", "message-hover"],
    "Incoming-call screen glyphs": ["call-screen", "status-bar"],
    "Zoom Docs toolbar glyphs": ["toolbar", "formatting-bar"],
    "Zoom Docs header controls": ["header", "toolbar"],
    "Zoom Docs header toolbar (file info)": ["header"],
    "Zoom Docs file menu options": ["menu-item", "dropdown"],
    "ZoomMate UI Components": ["sidebar", "toolbar", "header"],
    "ZoomMate Compose Input States": ["composer"],
    "ZoomMate home quick actions": ["home", "quick-action"],
    "Zoom Team Chat controls": ["header", "toolbar", "nav-rail", "composer"],
}

# ---------------------------------------------------------------- synonyms
# Maps a concept -> the extra words someone might search for. Applied when the
# icon's name contains any of the trigger words. Fixes the fragmentation where
# the overflow menu lives under six different names.
ALIAS_RULES = [
    (("ellipsis", "overflow", "kebab", "more"),
     ["kebab", "three dots", "overflow menu", "more actions", "meatball"]),
    (("chevron", "dropdown arrow", "caret"),
     ["caret", "disclosure arrow", "expand arrow", "dropdown"]),
    (("trash", "delete"), ["bin", "remove", "discard"]),
    (("pencil", "edit"), ["modify", "rename", "compose"]),
    (("send",), ["submit", "paper plane"]),
    (("search",), ["find", "magnifier", "magnifying glass", "lookup"]),
    (("settings", "setting", "gear"), ["preferences", "gear", "cog", "options"]),
    (("star", "starred", "favorite"), ["favorite", "bookmark", "pin"]),
    (("plus", "add"), ["new", "create", "add"]),
    (("attach", "paperclip"), ["file upload", "clip", "attachment"]),
    (("emoji", "smiley"), ["reaction", "smiley face"]),
    (("bell", "notification"), ["alerts", "notifications"]),
    (("person", "avatar", "contact"), ["user", "profile", "member"]),
    (("phone",), ["call", "dial", "telephone"]),
    (("video",), ["camera", "webcam", "meet"]),
    (("mention",), ["at sign", "@"]),
    (("folder",), ["directory"]),
    (("calendar",), ["schedule", "date", "event"]),
    (("mail",), ["email", "inbox", "envelope"]),
    (("sparkle", "ai companion", "agentai"), ["ai", "magic", "assistant", "genai"]),
    (("collapse sidebar",), ["panel toggle", "hide sidebar"]),
    (("drag handle",), ["grabber", "reorder", "grip"]),
    (("arrow down",), ["download", "descend"]),
    (("upload",), ["cloud upload", "import"]),
    (("export",), ["share out", "download as"]),
    (("print",), ["printer"]),
    (("waffle", "apps"), ["app grid", "launcher", "nine dots"]),
    (("filter",), ["sort", "refine"]),
    (("link",), ["url", "hyperlink", "anchor"]),
]

FIG_RE = re.compile(r'<figure class="tile([^"]*)"(.*?)</figure>', re.S)
NM_RE = re.compile(r'<span class="nm"[^>]*>([^<]*)</span>')
ART_RE = re.compile(r'<div class="art">(.*?)</div>', re.S)
VB_RE = re.compile(r'viewBox="([^"]*)"')
NOTE_RE = re.compile(r'<span class="chip note" title="([^"]*)"')
HARD_PAINT_RE = re.compile(r'(?:fill|stroke)="(?:#|url\()')


def unescape(s):
    return (s.replace("&quot;", '"').replace("&amp;", "&")
             .replace("&lt;", "<").replace("&gt;", ">").replace("&#39;", "'"))


def slug(s):
    s = s.lower()
    s = re.sub(r"[—–]", " ", s)
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return re.sub(r"-+", "-", s)


def render_size(viewbox):
    try:
        p = [float(x) for x in re.split(r"[ ,]+", viewbox.strip())]
        return int(round(max(p[2], p[3]))) if len(p) == 4 else None
    except Exception:
        return None


def detect_style(svg):
    has_stroke = 'stroke="' in svg and 'stroke="none"' not in svg
    has_fill = re.search(r'fill="(?!none)', svg) is not None
    if has_stroke and has_fill:
        return "mixed"
    return "outline" if has_stroke else "filled"


def aliases_for(name):
    low = name.lower()
    out = []
    for triggers, extra in ALIAS_RULES:
        if any(t in low for t in triggers):
            out += extra
    # the bare words of the name are searchable too
    return sorted(set(a for a in out if a not in low))


def build():
    html = open(HTML, encoding="utf-8").read()
    parts = re.split(r'<h3 class="sec">([^<]*)</h3>', html)
    icons, used = [], {}

    for i in range(1, len(parts), 2):
        section = unescape(parts[i]).strip()
        kind = SECTION_KIND.get(section, DEFAULT_KIND)
        slots = SECTION_SLOTS.get(section, [])
        for cls, inner in FIG_RE.findall(parts[i + 1]):
            nm, art = NM_RE.search(inner), ART_RE.search(inner)
            if not (nm and art):
                continue  # raster/img tile — no vector to index
            name = unescape(nm.group(1)).strip()
            svg = art.group(1).strip()
            if not svg.startswith("<svg"):
                continue
            vb = VB_RE.search(svg)
            vb = vb.group(1) if vb else ""
            recolorable = "currentColor" in svg and not HARD_PAINT_RE.search(svg)

            note = NOTE_RE.search(inner)
            rec = {
                "_base": f"{kind.split('-')[0]}.{slug(name)}",
                "name": name,
                "aliases": aliases_for(name),
                "kind": kind,
                "section": section,
                "slots": slots,
                "viewBox": vb,
                "renderSize": render_size(vb),
                "currentColor": recolorable,
                "style": detect_style(svg),
                "svg": svg,
            }
            if note:
                rec["note"] = unescape(note.group(1))
            icons.append(rec)

    # ---- assign ids in a second pass, now that whole collision groups are visible
    groups = {}
    for ic in icons:
        groups.setdefault(ic["_base"], []).append(ic)
    for base, group in groups.items():
        if len(group) == 1:
            group[0]["id"] = base
            continue
        # size tells them apart only if the sizes actually differ
        sizes = [g["renderSize"] for g in group]
        by_size = len(set(sizes)) == len(sizes) and all(sizes)
        for n, g in enumerate(group, 1):
            g["id"] = f"{base}-{g['renderSize']}" if by_size else f"{base}-{n}"
    for ic in icons:
        ic.pop("_base", None)
    # id first, for readability
    icons = [dict([("id", i.pop("id"))] + list(i.items())) for i in icons]

    json.dump({"icons": icons}, open(OUT_JSON, "w", encoding="utf-8"),
              indent=1, ensure_ascii=False)

    # compact browsable table — no SVG, safe for a skill to read whole
    by_sec = {}
    for ic in icons:
        by_sec.setdefault(ic["section"], []).append(ic)
    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write("# Zoom icon index\n\n")
        f.write("Derived from `zoom-asset-library.html` by `tools/build_index.py`. "
                "Do not edit by hand.\n\n")
        f.write(f"{len(icons)} icons. Resolve one to markup with:\n\n")
        f.write("```bash\npython3 tools/icon_lookup.py \"<query>\"\n```\n\n")
        f.write("`cc` = recolorable via `currentColor`. `px` = artboard size.\n")
        for sec, group in by_sec.items():
            kind = group[0]["kind"]
            f.write(f"\n## {sec}\n\n_kind: `{kind}`")
            if group[0]["slots"]:
                f.write(f" · slots: {', '.join(group[0]['slots'])}")
            f.write("_\n\n| id | name | px | cc | aliases |\n|---|---|---|---|---|\n")
            for ic in group:
                f.write("| `%s` | %s | %s | %s | %s |\n" % (
                    ic["id"], ic["name"], ic["renderSize"] or "—",
                    "yes" if ic["currentColor"] else "no",
                    ", ".join(ic["aliases"][:5]) or "—"))

    return icons


if __name__ == "__main__":
    ic = build()
    kinds = {}
    for i in ic:
        kinds[i["kind"]] = kinds.get(i["kind"], 0) + 1
    print(f"indexed {len(ic)} icons -> icons.json, icons-index.md")
    for k, v in sorted(kinds.items(), key=lambda x: -x[1]):
        print(f"   {v:>4}  {k}")
    print(f"   {sum(1 for i in ic if i['currentColor']):>4}  recolorable (currentColor)")
    sys.exit(0)
