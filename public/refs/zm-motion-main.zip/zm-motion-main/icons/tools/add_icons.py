#!/usr/bin/env python3
"""
add_icons.py — take extract_icons.py output and write it into
zoom-asset-library.html (tiles) and zoom-icons-additions.md (inline entries).

Usage:
    python3 tools/add_icons.py candidates.json --section "Docs header controls"
    ... --note-key NOTE            # optional per-icon "note" field is honoured
    ... --dry-run                  # print what would change, touch nothing

Skips anything flagged duplicate_of_library, and re-checks geometry against the
current library so repeated runs are idempotent. Both files are backed up to
*.bak before writing.
"""
import argparse
import json
import os
import re
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_icons import SVG_RE, geometry_key, dims, uses_currentcolor  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, "zoom-asset-library.html")
MD = os.path.join(ROOT, "zoom-icons-additions.md")
SRC_LABEL = "Added this thread"


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def title_case(name):
    return name[:1].upper() + name[1:] if name else name


def tile(icon):
    name = icon["name"]
    disp = title_case(name)
    chips = ""
    if icon.get("currentColor", True):
        chips += '<span class="chip cc">currentColor</span>'
    if icon.get("note"):
        chips += '<span class="chip note" title="%s">note</span>' % esc(icon["note"])
    cls = "tile cc" if icon.get("currentColor", True) else "tile"
    return (
        '      <figure class="%s" data-name="%s"\n'
        '        data-src="%s" tabindex="0" role="button" aria-label="Copy %s">\n'
        '        <div class="art">%s</div>\n'
        "        <figcaption>\n"
        '          <span class="nm" title="%s">%s</span>\n'
        '          <span class="meta">%s%s</span>\n'
        "        </figcaption>\n"
        "      </figure>\n"
    ) % (cls, esc(name.lower()), SRC_LABEL, esc(disp), icon["svg"],
         esc(disp), esc(disp), icon["dims"], chips)


def insert_html(html, icons, section):
    tiles = "".join(tile(i) for i in icons)
    sec_re = re.compile(
        r'(<h3 class="sec">%s</h3>\s*\n\s*<div class="grid">)(.*?)(\n    </div>)'
        % re.escape(section), re.S)
    m = sec_re.search(html)
    if m:
        html = html[:m.end(2)] + tiles.rstrip("\n") + html[m.end(2):]
    else:
        block = '    <h3 class="sec">%s</h3>\n    <div class="grid">\n%s    </div>\n' % (
            esc(section), tiles)
        anchor = '  <p class="empty" id="empty"'
        idx = html.index(anchor)
        html = html[:idx] + block + html[idx:]
    # keep the "Added this thread" counter honest
    def bump(mm):
        total = html.count('data-src="%s"' % SRC_LABEL)
        return mm.group(1) + str(total) + mm.group(3)
    html = re.sub(r'(<h2 class="src new">%s<span class="n">)(\d+)(</span>)' % re.escape(SRC_LABEL),
                  bump, html)
    return html


def insert_md(md, icons, components, section):
    entries = []
    for i in icons:
        e = "### %s\n" % title_case(i["name"])
        if i.get("desc"):
            e += "*%s*\n" % i["desc"]
        if i.get("note"):
            # backtick any raw tag in prose so it can't be re-parsed as real markup
            note = re.sub(r"(?<!`)(<[a-zA-Z/][^>`]*>)(?!`)", r"`\1`", i["note"])
            e += "\n> **Note.** %s\n" % note
        e += "\n```html\n%s\n```\n" % i["svg"]
        entries.append(e)
    body = "\n".join(entries)
    if components:
        body += "\n\n### Composite controls\n\n" + "".join(
            "- **%s** — %s: `%s`\n\n```html\n%s\n```\n"
            % (comp["name"], ", ".join(comp.get("icon_names", []))[:50],
               ", ".join("`%s`" % i for i in comp.get("icon_names", [])),
               comp["markup"])
            for comp in components)
    head = "## %s\n\n" % section
    footer = "## Not included, and why"
    if head.rstrip() in md:
        # append to the existing section, just before the next "## " or the tail
        start = md.index(head.rstrip()) + len(head.rstrip())
        nxt = md.find("\n## ", start)
        end = nxt if nxt != -1 else md.index(footer)
        return md[:end] + "\n" + body + md[end:]
    # insert a new section right before the footer heading, adding our own
    # divider since the one before the footer may already have other
    # sections' content between it and the heading
    idx = md.index(footer)
    return md[:idx] + head + body + "\n\n---\n\n" + md[idx:]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("candidates")
    ap.add_argument("--section", required=True)
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args()

    all_items = json.load(open(a.candidates, encoding="utf-8"))
    icons = [i for i in all_items if i.get("kind") != "component"]
    components = [i for i in all_items if i.get("kind") == "component"]
    html = open(HTML, encoding="utf-8").read()
    md = open(MD, encoding="utf-8").read()

    live = {geometry_key(s) for s in SVG_RE.findall(html)}
    fresh, skipped = [], []
    for i in icons:
        i.setdefault("dims", dims(i["svg"]))
        i.setdefault("currentColor", uses_currentcolor(i["svg"]))
        k = i.get("key") or geometry_key(i["svg"])
        (skipped if (k in live or i.get("duplicate_of_library")) else fresh).append(i)
        live.add(k)

    print("adding %d icon(s) and %d composite(s) to section %r; skipping %d duplicate(s)"
          % (len(fresh), len(components), a.section, len(skipped)))
    for i in skipped:
        print("  dup: %s" % i["name"])
    for i in fresh:
        print("  new: %s (%s)" % (i["name"], i["dims"]))
    for c in components:
        print("  component: %s (%d icon(s))" % (c["name"], c["icon_count"]))
    if a.dry_run or (not fresh and not components):
        return

    # compute both outputs before touching either file, so a failure in one
    # can't leave the file truncated (open(..., "w") clears it immediately)
    new_html = insert_html(html, fresh, a.section)
    new_md = insert_md(md, fresh, components, a.section)

    shutil.copy(HTML, HTML + ".bak")
    shutil.copy(MD, MD + ".bak")
    open(HTML, "w", encoding="utf-8").write(new_html)
    open(MD, "w", encoding="utf-8").write(new_md)
    print("wrote both files (backups at *.bak)")


if __name__ == "__main__":
    main()
