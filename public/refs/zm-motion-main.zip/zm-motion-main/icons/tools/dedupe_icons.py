#!/usr/bin/env python3
"""
dedupe_icons.py — audit the library for icons stored more than once.

Two glyphs are "the same" when their geometry hash matches: every geometry-bearing
attribute (d, points, cx/cy/r, x/y/width/height...) plus the viewBox. Naming,
wrapper attributes and casing are ignored, so the same path pasted from two
different screens is caught even when the two sites labelled it differently.

Usage:
    python3 tools/dedupe_icons.py                 # audit both files, report only
    python3 tools/dedupe_icons.py --fix           # drop the redundant HTML tiles
    python3 tools/dedupe_icons.py --near          # also flag same-shape/different-viewBox
    python3 tools/dedupe_icons.py --json          # machine-readable report

--fix only ever touches zoom-asset-library.html, and only removes *later*
duplicates — the first tile for a geometry always survives, so section order and
the earliest (usually best-named) entry are preserved. Backup written to *.bak.
The .md is never edited automatically: its entries carry prose you may want to
merge by hand. Exit status is 1 when duplicates remain, so it works in a check.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_icons import SVG_RE, GEOM_RE, VIEWBOX_RE, geometry_key  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, "zoom-asset-library.html")
MD = os.path.join(ROOT, "zoom-icons-additions.md")

FIGURE_RE = re.compile(r"[ \t]*<figure class=\"tile[^\"]*\".*?</figure>\n", re.S)
NAME_RE = re.compile(r'data-name="([^"]*)"')
SEC_RE = re.compile(r'<h3 class="sec">(.*?)</h3>')
MD_ENTRY_RE = re.compile(r"^### (.+?)$", re.M)


def shape_key(svg):
    """Geometry only, viewBox ignored — catches the same art on a resized artboard."""
    body = svg[svg.index(">") + 1:]
    return hashlib.sha1("|".join(GEOM_RE.findall(body)).encode()).hexdigest()


def html_icons(html):
    """Every tile, with the section heading it sits under."""
    sections = [(m.start(), m.group(1)) for m in SEC_RE.finditer(html)]
    out = []
    for m in FIGURE_RE.finditer(html):
        svgs = SVG_RE.findall(m.group(0))
        if not svgs:  # raster tile (PNG/data URI) — nothing to hash
            continue
        sec = ""
        for pos, title in sections:
            if pos < m.start():
                sec = title
        nm = NAME_RE.search(m.group(0))
        out.append({
            "name": nm.group(1) if nm else "?",
            "section": sec,
            "start": m.start(),
            "end": m.end(),
            "key": geometry_key(svgs[0]),
            "shape": shape_key(svgs[0]),
            "viewBox": (VIEWBOX_RE.search(svgs[0]) or [None, ""])[1]
            if VIEWBOX_RE.search(svgs[0]) else "",
        })
    return out


def md_icons(md):
    out = []
    for m in MD_ENTRY_RE.finditer(md):
        nxt = md.find("\n### ", m.end())
        chunk = md[m.start(): nxt if nxt != -1 else len(md)]
        # only look inside ```html fences — prose may mention <svg> in passing
        svgs = [s for fence in re.findall(r"```html\n(.*?)\n```", chunk, re.S)
                for s in SVG_RE.findall(fence)]
        if svgs:
            out.append({"name": m.group(1), "key": geometry_key(svgs[0]),
                        "shape": shape_key(svgs[0])})
    return out


def group(items, field):
    g = {}
    for it in items:
        g.setdefault(it[field], []).append(it)
    return {k: v for k, v in g.items() if len(v) > 1}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--fix", action="store_true", help="remove redundant HTML tiles")
    ap.add_argument("--near", action="store_true",
                    help="also report same-shape/different-viewBox pairs")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()

    html = open(HTML, encoding="utf-8").read()
    md = open(MD, encoding="utf-8").read()
    hi, mi = html_icons(html), md_icons(md)

    exact = group(hi, "key")
    near = {k: v for k, v in group(hi, "shape").items()
            if len({i["viewBox"] for i in v}) > 1} if a.near else {}
    md_dupes = group(mi, "key")
    # entries present in one file but not the other
    hkeys, mkeys = {i["key"] for i in hi}, {i["key"] for i in mi}
    only_html = [i["name"] for i in hi if i["key"] not in mkeys]
    only_md = [i["name"] for i in mi if i["key"] not in hkeys]

    report = {
        "html_icons": len(hi), "md_icons": len(mi),
        "exact_duplicates": [[i["name"] for i in v] for v in exact.values()],
        "near_duplicates": [[f"{i['name']} ({i['viewBox']})" for i in v] for v in near.values()],
        "md_duplicates": [[i["name"] for i in v] for v in md_dupes.values()],
        "only_in_html": only_html, "only_in_md": only_md,
    }
    if a.json:
        json.dump(report, sys.stdout, indent=2, ensure_ascii=False)
        print()
    else:
        print("%d vector tiles in HTML, %d entries in MD" % (len(hi), len(mi)))
        for label, groups in (("EXACT duplicate", exact), ("NEAR duplicate (same shape, different viewBox)", near)):
            for v in groups.values():
                print("  %s: %s" % (label, " | ".join(
                    "%s [%s]" % (i["name"], i["section"]) for i in v)))
        for v in md_dupes.values():
            print("  MD duplicate: %s" % " | ".join(i["name"] for i in v))
        if only_html:
            print("  in HTML but not MD (%d): %s" % (len(only_html), ", ".join(only_html)))
        if only_md:
            print("  in MD but not HTML (%d): %s" % (len(only_md), ", ".join(only_md)))
        if not exact and not near and not md_dupes:
            print("  no duplicates found")

    if a.fix and exact:
        drop = []
        for v in exact.values():
            for i in v[1:]:
                drop.append(i)
                print("removing tile: %s [%s]" % (i["name"], i["section"]))
        shutil.copy(HTML, HTML + ".bak")
        for i in sorted(drop, key=lambda x: -x["start"]):
            html = html[:i["start"]] + html[i["end"]:]
        n = html.count('data-src="Added this thread"')
        html = re.sub(r'(<h2 class="src new">Added this thread<span class="n">)\d+(</span>)',
                      lambda m: m.group(1) + str(n) + m.group(2), html)
        open(HTML, "w", encoding="utf-8").write(html)
        print("removed %d tile(s); backup at zoom-asset-library.html.bak" % len(drop))
        print("NOTE: matching .md entries were left alone — merge their prose by hand.")
        return 0

    return 1 if (exact or md_dupes) else 0


if __name__ == "__main__":
    sys.exit(main())
