#!/usr/bin/env python3
"""
icon_lookup.py — resolve a plain-language query to real Zoom icon markup.

This is the query surface the zoom-ui skill uses. It exists so an agent never has
to read the 490KB gallery, and never has to invent path data: if nothing matches,
this exits 1 and prints nothing usable, which is the signal to pick a documented
fallback rather than draw something Zoom-ish from memory.

    python3 tools/icon_lookup.py "kebab menu"          # ranked matches + markup
    python3 tools/icon_lookup.py ui.send-16 --svg      # just the <svg>, by id
    python3 tools/icon_lookup.py "chat" --kind ui-glyph
    python3 tools/icon_lookup.py "star" --json

Exit status: 0 when at least one icon matched, 1 when nothing did.
"""
import argparse
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
INDEX = os.path.join(ROOT, "icons.json")


def load():
    if not os.path.exists(INDEX):
        sys.exit("icons.json missing — run: python3 tools/build_index.py")
    return json.load(open(INDEX, encoding="utf-8"))["icons"]


def tokens(s):
    return [t for t in re.split(r"[^a-z0-9]+", s.lower()) if t]


def score(icon, q):
    """Higher is better. 0 means no match at all."""
    ql = q.lower().strip()
    qt = set(tokens(ql))
    name = icon["name"].lower()
    aliases = [a.lower() for a in icon.get("aliases", [])]

    if ql == icon["id"].lower():
        return 1000
    if ql == name:
        return 900
    if ql in aliases:
        return 850
    if ql and ql in icon["id"].lower():
        return 700
    if ql and ql in name:
        return 600
    if any(ql and ql in a for a in aliases):
        return 550

    # token overlap, normalized so a short precise name beats a long vague one
    pool = set(tokens(name)) | set(t for a in aliases for t in tokens(a))
    hit = qt & pool
    if not hit:
        return 0
    return int(400 * len(hit) / max(len(qt), 1)) + int(40 * len(hit) / max(len(pool), 1))


def fmt(icon, show_svg=True):
    bits = [
        f"  id        {icon['id']}",
        f"  name      {icon['name']}",
        f"  kind      {icon['kind']}   size {icon['renderSize']}px   "
        f"style {icon['style']}   currentColor {'yes' if icon['currentColor'] else 'NO'}",
        f"  section   {icon['section']}",
    ]
    if icon.get("slots"):
        bits.append(f"  slots     {', '.join(icon['slots'])}")
    if icon.get("aliases"):
        bits.append(f"  aliases   {', '.join(icon['aliases'])}")
    if icon.get("note"):
        bits.append(f"  note      {icon['note']}")
    if not icon["currentColor"]:
        bits.append("  ! fixed palette — do not recolor; use as-is")
    if show_svg:
        bits.append(f"  svg       {icon['svg']}")
    return "\n".join(bits)


def main():
    p = argparse.ArgumentParser(description="Resolve a query to Zoom icon markup.")
    p.add_argument("query", help="id, name, or plain-language description")
    p.add_argument("--svg", action="store_true", help="print only the top match's <svg>")
    p.add_argument("--kind", help="filter: ui-glyph | app-tile | app-squircle | brand | illustration")
    p.add_argument("--slot", help="filter by UI slot, e.g. composer, nav-rail, toolbar")
    p.add_argument("--size", type=int, help="filter by artboard size, e.g. 16")
    p.add_argument("-n", "--limit", type=int, default=5, help="max matches (default 5)")
    p.add_argument("--json", action="store_true", help="machine-readable output")
    a = p.parse_args()

    pool = load()
    if a.kind:
        pool = [i for i in pool if i["kind"] == a.kind]
    if a.slot:
        pool = [i for i in pool if a.slot in i.get("slots", [])]
    if a.size:
        pool = [i for i in pool if i["renderSize"] == a.size]

    ranked = sorted(((score(i, a.query), i) for i in pool), key=lambda x: -x[0])
    hits = [i for s, i in ranked if s > 0][: a.limit]

    if not hits:
        filt = "".join(f" --{k} {v}" for k, v in
                       (("kind", a.kind), ("slot", a.slot), ("size", a.size)) if v)
        sys.stderr.write(
            f'no icon matches "{a.query}"{filt}.\n'
            "Do NOT author substitute path data. Options: broaden the query, drop\n"
            "filters, browse icons-index.md, or use a documented fallback.\n")
        return 1

    if a.json:
        json.dump(hits, sys.stdout, indent=1, ensure_ascii=False)
        print()
    elif a.svg:
        print(hits[0]["svg"])
    else:
        print(f'{len(hits)} match(es) for "{a.query}":\n')
        for i, ic in enumerate(hits):
            print(fmt(ic))
            if i < len(hits) - 1:
                print()
        if len(hits) > 1:
            print("\n(top match first; compare `section` and `size` to pick)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
