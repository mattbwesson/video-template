#!/usr/bin/env python3
"""
verify_library.py — sanity-check the library after an insert.

    python3 tools/verify_library.py                     # structural checks only
    python3 tools/verify_library.py pastes/paste-002.html   # also prove provenance

Checks:
  1. every <svg> in both files parses as well-formed XML
  2. every tile has a name, a viewBox, and a dimensions label that matches its viewBox
  3. the "Added this thread" counter equals the real tile count
  4. with paste files given: every path/geometry value in the library that came from
     those pastes is byte-identical to the source (the provenance rule)

Exit status 0 when clean, 1 otherwise.
"""
import os
import re
import sys
import xml.dom.minidom

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_icons import SVG_RE, VIEWBOX_RE, dims, geometry_key  # noqa: E402
from dedupe_icons import html_icons, FIGURE_RE  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HTML = os.path.join(ROOT, "zoom-asset-library.html")
MD = os.path.join(ROOT, "zoom-icons-additions.md")
SRC_LABEL = "Added this thread"


def main(pastes):
    html = open(HTML, encoding="utf-8").read()
    md = open(MD, encoding="utf-8").read()
    problems = []

    md_svgs = [s for fence in re.findall(r"```html\n(.*?)\n```", md, re.S)
               for s in SVG_RE.findall(fence)]
    for label, svgs in (("html", SVG_RE.findall(html)), ("md", md_svgs)):
        for svg in svgs:
            try:
                xml.dom.minidom.parseString(svg)
            except Exception as e:
                problems.append("%s: malformed svg (%s): %s..." % (label, e, svg[:80]))

    for fig in FIGURE_RE.findall(html):
        svgs = SVG_RE.findall(fig)
        name = (re.search(r'data-name="([^"]*)"', fig) or [None, "?"])[1] \
            if re.search(r'data-name="([^"]*)"', fig) else "?"
        if not svgs:
            continue
        if not name or name == "?":
            problems.append("tile with no data-name: %s..." % fig[:80])
        if not VIEWBOX_RE.search(svgs[0]):
            problems.append("%s: no viewBox" % name)
            continue
        want = dims(svgs[0])
        meta = re.search(r'<span class="meta">([^<]*)', fig)

        def round_dims(s):  # labels round fractional artboards; that's fine
            return "×".join(str(round(float(x))) for x in s.split("×")) if s else s
        if meta and want and round_dims(meta.group(1).strip()) != round_dims(want):
            problems.append("%s: label says %r, viewBox says %r"
                            % (name, meta.group(1).strip(), want))

    real = html.count('data-src="%s"' % SRC_LABEL)
    m = re.search(r'<h2 class="src new">%s<span class="n">(\d+)</span>' % SRC_LABEL, html)
    if m and int(m.group(1)) != real:
        problems.append("counter says %s, actual tiles %d" % (m.group(1), real))

    checked = missing = 0
    if pastes:
        # A geometry hash covers every coordinate plus the viewBox, so any edit to
        # path data changes the key. Source key present in the library == byte-identical.
        src = "".join(open(p, encoding="utf-8").read() for p in pastes)
        lib_keys = {geometry_key(s) for s in SVG_RE.findall(html)}
        for svg in SVG_RE.findall(src):
            checked += 1
            if geometry_key(svg) not in lib_keys:
                missing += 1
                name = re.search(r'aria-label="([^"]*)"', svg)
                problems.append("source glyph not in library byte-identical: %s"
                                % (name.group(1) if name else svg[:60]))

    icons = html_icons(html)
    print("%d vector tiles, %d svg blocks in md" % (len(icons), len(SVG_RE.findall(md))))
    if pastes:
        print("provenance: %d source glyph(s) checked, %d not byte-identical in library"
              % (checked, missing))
    for p in problems:
        print("  FAIL %s" % p)
    print("  all checks passed" if not problems else "  %d problem(s)" % len(problems))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
