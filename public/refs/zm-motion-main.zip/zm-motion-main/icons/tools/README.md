# Icon library tooling

Small Python scripts (stdlib only, no install step) that turn pasted website markup
into library entries in `zoom-asset-library.html` and `zoom-icons-additions.md`, and
then into a machine-queryable index for the `zoom-ui` skill.

**Authoring** — paste in, library out:

| Script | Job |
| --- | --- |
| `extract_icons.py` | Pull every `<svg>` out of a paste, normalize, name, dedupe → JSON |
| `add_icons.py` | Write that JSON into the `.html` tiles and the `.md` entries |
| `dedupe_icons.py` | Audit (and optionally repair) duplicates across both files |

**Consumption** — library out, skill in:

| Script | Job |
| --- | --- |
| `build_index.py` | Derive `icons.json` + `icons-index.md` from the gallery |
| `icon_lookup.py` | Resolve a plain-language query to real markup (the skill's query surface) |
| `build_tokens.py` | Mine `pastes/` for colours, type, sizing → `tokens.json` |

Rebuild the derived artifacts after every insert:

```bash
python3 tools/build_index.py && python3 tools/build_tokens.py
```

---

## What gets detected

The extractor finds two things:

1. **Bare icons** — raw `<svg>` elements anywhere in the DOM (no surrounding button)
2. **Labelled controls** — an `<svg>` inside a `<button>` or `<a>` (or `[role="button"]`),
   paired with a visible text label. The label must be real — not an `aria-label` alone,
   not just a screen-reader-only span. The detector drops any `<span>` whose text echoes
   an `aria-label` that's already on the button, since that's just a11y redundancy, not
   a visible label

Controls come out as **components** (in the JSON marked `"kind": "component"`), which
get written to the markdown (not the interactive HTML gallery) so their HTML can sit
alongside prose. Each component lists the names of its glyphs and includes the
normalized `<button>` markup.

## The normal run

**1. Save the paste.** Anything goes in — a whole page's DOM, one `<div>`, a React
dump. The scripts only care about `<svg>` elements.

```bash
cd /Users/MattWesson/Desktop/icon_files && pbpaste > pastes/paste-002.html
```

**2. Extract.**

```bash
python3 tools/extract_icons.py pastes/paste-002.html > /tmp/cand.json
```

It prints a summary to stderr (`scanned 12 svg(s); 9 unique; 2 already in library; 7 new`)
and the candidates to stdout. Multiple files at once are fine, and `-` reads stdin.

**3. Review the JSON.** This is the human step, and the only one. Icons look like:

```json
{
  "name": "Copy doc link",
  "svg": "<svg xmlns=... >…</svg>",
  "dims": "16×16",
  "currentColor": true,
  "key": "9f2c…",
  "duplicate_of_library": false
}
```

Fix the `name` if the auto-guess is poor, and optionally add any of these fields:

**For bare icons:**

- `"desc"` — the one-line italic caption under the MD heading (where it's used in the product)
- `"note"` — a caveat; renders as a `> **Note.**` block in the MD and a hoverable
  `note` chip on the HTML tile

**For components** (labelled controls — JSON marked `"kind": "component"`): typically
nothing to edit. They're auto-extracted with normalized markup and a list of their
glyphs. Delete if you don't want the control variant documented.

Delete any entry you don't want. Entries with `duplicate_of_library: true` are skipped
automatically, so you can leave them in.

**4. Insert.**

```bash
python3 tools/add_icons.py /tmp/cand.json --section "Zoom Docs header controls"
```

Add `--dry-run` first if you want to see the plan without touching anything. If the
section heading already exists the tiles are appended to it; otherwise a new
`<h3 class="sec">` block is created at the end. The "Added this thread" counter is
recomputed from the actual tile count, and `*.bak` backups are written.

**5. Audit.**

```bash
python3 tools/dedupe_icons.py --near
```

---

## What "normalize" does and does not touch

**Never rewritten:** path data. Every `d`, `points`, and coordinate is passed through
byte-for-byte, and so is the `viewBox`. This preserves the provenance rule stated at the
top of `zoom-icons-additions.md`.

**Rewritten, on the opening `<svg>` tag only:**

- `width`/`height` → `1em` (size from the wrapper, per library convention)
- dropped: `class`, `id`, `aria-*`, `role`, `tabindex`, `focusable`, `style`, `data-*`,
  and any `on*` handler — none affect rendering
- dropped: `color="currentColor"`, which is the default anyway. A `color` holding a real
  value (`var(--token)`, a hex) is **kept**, because it changes rendering — decide
  per icon whether to strip it, and say so in a `note` if you do
- kept and reordered: `xmlns`, `fill`, `viewBox`, then anything else unrecognized

**Rewritten in the body:** `id` attributes that nothing references via `url(#…)` or
`href="#…"` are removed. Zoom's sprite build emits ids like `video_svg__Vector` on many
different icons; left in place they collide once two icons are on the same page. Ids that
*are* referenced (clip paths, gradients) are left alone.

## How naming works

First hit wins: `aria-label` → `data-name` → `data-icon` → `title` attribute → an inner
`*_svg__name` sprite id → a `<title>` element → the visible text sitting right after the
`</svg>` inside its button. Failing all that, `untitled icon N` — which is your cue to
name it by hand in the JSON.

## How deduping works

Identity is a SHA-1 over every geometry-bearing attribute (`d`, `points`, `cx`, `cy`,
`r`, `rx`, `ry`, `x`, `y`, `x1…y2`, `width`, `height`) concatenated with the `viewBox`.
Names, classes, wrapper attributes and casing are all ignored, so the same glyph pasted
from two different screens under two different labels still collides.

This runs at three points:

1. **Within a paste** — `extract_icons.py` emits each shape once, even if the page used
   it in six places.
2. **Against the library** — `duplicate_of_library` is set at extract time, and
   `add_icons.py` re-checks against the file on disk at write time. Re-running the same
   command twice adds nothing the second time.
3. **Across the whole library** — `dedupe_icons.py`, below.

## `dedupe_icons.py`

```bash
python3 tools/dedupe_icons.py            # audit, report only
python3 tools/dedupe_icons.py --near     # also flag same shape on a different viewBox
python3 tools/dedupe_icons.py --fix      # remove the redundant HTML tiles
python3 tools/dedupe_icons.py --json     # machine-readable
```

It reports four things:

- **Exact duplicates** — same geometry hash, two or more tiles
- **Near duplicates** (`--near`) — identical path data on a different artboard, e.g. the
  same mark saved at `0 0 16 16` and `0 0 14 14`. Usually legitimate, occasionally a
  re-export you'd rather collapse. Judgement call, never auto-fixed
- **MD duplicates** — the same glyph written into `zoom-icons-additions.md` twice
- **Drift between the two files** — what's in the HTML but has no MD entry, and vice
  versa. A long "in HTML but not MD" list is expected and fine: the Project-library
  icons predate the additions file and are documented in `zoom-icons.md` instead

`--fix` only edits the HTML, and only deletes *later* duplicates — the first tile for a
given geometry always survives, so section ordering and the earliest (usually
best-named) entry are preserved. It rewrites the counter and leaves a `.bak`. It
deliberately does **not** edit the `.md`, because those entries carry prose worth merging
by hand.

Exit status is `1` when duplicates remain and `0` when clean, so it can gate a commit:

```bash
python3 tools/dedupe_icons.py && echo "library is clean"
```

## Recovering from a bad run

Both writers back up before touching anything:

```bash
cp zoom-asset-library.html.bak zoom-asset-library.html && cp zoom-icons-additions.md.bak zoom-icons-additions.md
```

Only one generation of backup is kept — each run overwrites `.bak`. If you want to redo
an insert with different names, restore from `.bak` first, then re-run `add_icons.py`;
otherwise the dedupe check will correctly refuse to add the same shapes again.

## Verifying an insert

Worth running after a large batch — checks the new markup parses and that path data
survived untouched:

```bash
python3 - <<'EOF'
import re, sys, xml.dom.minidom
sys.path.insert(0, 'tools')
from extract_icons import SVG_RE
lib = open('zoom-asset-library.html').read()
src = open('pastes/paste-002.html').read()
srcd = set(re.findall(r'\sd="([^"]*)"', src))
bad = 0
for s in SVG_RE.findall(lib):
    xml.dom.minidom.parseString(s)          # raises if malformed
    for d in re.findall(r'\sd="([^"]*)"', s):
        if d in srcd: continue
bad = sum(1 for s in SVG_RE.findall(lib) for d in re.findall(r'\sd="([^"]*)"', s)
          if d not in srcd and s in lib[lib.index('Added this thread'):])
print('all svgs parse OK')
EOF
```

## Component detection details

When the extractor finds an `<svg>` inside a button, it:

1. Walks backwards from the svg to find the enclosing `<button>`, `<a>`, or
   `[role="button"]`
2. Traces forward to the matching close tag (skipping nesting depth)
3. Extracts the visible text in that control — everything except sr-only spans and
   `<svg>` elements
4. Filters out `<span>` text that merely echoes an `aria-label`, since that's just a11y
   bookkeeping, not a real label
5. If real text remains, stores the control as a component with its normalized `<button>`
   (or `<a>`), its icon(s), and the visible text

Multiple icons in one button count as one component (e.g., an icon stack or an icon
with a badge).

The control's `type`, `href`, and `aria-label` are preserved; everything else (class,
id, data-*, on*) is dropped. The icon(s) inside are normalized per the usual rules.

## Known limits

- SVGs are matched with a regex, so a *nested* `<svg>` inside another `<svg>` would be
  cut short at the first `</svg>`. Rare in component markup; hasn't come up yet.
- `<img src="data:image/svg+xml,…">` and raster PNG tiles are ignored by the extractor.
  Add those by hand — the library already has a couple.
- Icons that reference an external `<symbol>`/`<use>` sprite extract as an empty shell.
  They'll come through with an `untitled icon` name and near-empty geometry; delete them
  from the JSON and grab the real symbol definition instead.

## Consuming the library from a skill

The gallery is ~490 KB and the full record set ~340 KB — neither is readable in an
agent's context. The access pattern is therefore: **read the small index, query the
big one.**

```bash
python3 tools/icon_lookup.py "kebab menu"        # ranked matches + markup
python3 tools/icon_lookup.py ui.send-16 --svg    # exact markup, by id
python3 tools/icon_lookup.py "chat" --kind ui-glyph --size 16
```

`icons-index.md` (~14 KB) is the browsable table — ids, names, sizes, aliases, no
markup. Safe to read whole when the agent needs to see what exists.

### Why ids look the way they do

`<kind>.<name>`, e.g. `ui.chat`, `app.chat`. The `kind` prefix is load-bearing: 27
names in this library are used by two different assets, and the most common split is
a colored product tile (`app-tile`) versus a 16px monochrome line glyph (`ui-glyph`).
Asking for "the chat icon" without a kind is genuinely ambiguous.

When two icons share a name *and* kind, the id is suffixed by artboard size
(`ui.star-24` / `ui.star-16`) — but only when the sizes actually differ. Where they
don't, the suffix is a bare ordinal and the `section` field is what tells them apart.

### The no-match contract

`icon_lookup.py` exits **1** and prints no markup when nothing matches. That exit code
is the whole point: it is the signal to widen the query or pick a documented fallback,
never to author substitute path data. A hand-written path that looks Zoom-ish is the
worst possible output — it is wrong in a way nobody reviews.

### Tokens

`tokens.json` carries presence colours, the editor type scale, the 32px-control /
16px-glyph pairing, radii, and panel widths — each with the paste it came from. It also
carries a `gaps` list (no grey ramp, no hover/focus states, no dark theme, no
elevation). Treat a gap the same way as a lookup miss: capture more DOM, don't guess.

## Adding to the token set

`build_tokens.py` only sees what's in `pastes/`. When you capture new markup for icons,
the surrounding style context is usually discarded — `paste-team-chat.html` was trimmed
to glyphs, which is why `paste-team-chat-tokens.html` exists alongside it. If a capture
carries CSS custom properties, `status="…"` swatches, or inline sizing worth keeping,
save those fragments as a separate `*-tokens.html` paste before trimming.
