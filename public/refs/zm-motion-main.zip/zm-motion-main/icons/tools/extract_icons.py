#!/usr/bin/env python3
"""
extract_icons.py — pull every <svg> out of pasted website markup, normalize it to
the library's conventions, name it, and dedupe it against what's already in
zoom-asset-library.html.

Usage:
    python3 tools/extract_icons.py paste1.html paste2.html   > candidates.json
    pbpaste | python3 tools/extract_icons.py -               > candidates.json

Path data is NEVER rewritten. Only wrapper attributes on the <svg> tag are
normalized (width/height -> 1em, presentational cruft dropped). Anything that
changes rendering (color="var(--...)", fill, stroke, viewBox) is preserved.
"""
import hashlib
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LIBRARY_HTML = os.path.join(ROOT, "zoom-asset-library.html")

SVG_RE = re.compile(r"<svg\b[^>]*>.*?</svg>", re.S | re.I)
ATTR_RE = re.compile(r'([:\w-]+)\s*=\s*"([^"]*)"')
VIEWBOX_RE = re.compile(r'viewBox\s*=\s*"([^"]*)"', re.I)
# geometry-bearing attributes: everything the shape actually is
GEOM_RE = re.compile(r'\b(?:d|points|cx|cy|rx|ry|r|x|y|x1|y1|x2|y2|width|height)\s*=\s*"([^"]*)"')

# attributes dropped from the <svg> tag: framework/a11y/layout noise, no render effect
DROP_ATTRS = {
    "class", "id", "aria-label", "aria-hidden", "aria-labelledby", "aria-describedby",
    "focusable", "role", "tabindex", "style", "data-testid", "data-name",
}
# color="currentColor" is the default and redundant; a var()/hex color is not.
NAME_ATTRS = ("aria-label", "data-name", "data-icon", "title", "id")


def parse_attrs(tag):
    return dict(ATTR_RE.findall(tag))


def slug_to_name(s):
    s = re.sub(r"_svg__|[-_]+", " ", s).strip()
    s = re.sub(r"\s+", " ", s)
    return s


def guess_name(svg, i, trailing=""):
    open_tag = svg[: svg.index(">") + 1]
    attrs = parse_attrs(open_tag)
    for a in NAME_ATTRS:
        v = attrs.get(a, "").strip()
        if v and not v.startswith("sun-ui"):
            return slug_to_name(v)
    # fall back to inner <g id="...">/<path id="..."> hints (Zoom sprite naming)
    m = re.search(r'<(?:g|path)[^>]*\bid="([^"]*_svg__[^"]*)"', svg)
    if m:
        return slug_to_name(m.group(1))
    m = re.search(r"<title[^>]*>(.*?)</title>", svg, re.S)
    if m:
        return slug_to_name(re.sub(r"<[^>]+>", "", m.group(1)))
    # last resort: the visible label sitting next to the glyph inside its control
    m = re.match(r"\s*([^<>]{1,40}?)\s*<", trailing)
    if m and m.group(1).strip():
        return slug_to_name(m.group(1))
    return "untitled icon %d" % i


def strip_unused_ids(body):
    """Drop sprite-generated ids nobody points at — they collide across icons."""
    refs = set(re.findall(r'url\(#([^)"\']+)\)', body)) | set(re.findall(r'href="#([^"]+)"', body))
    return re.sub(r'\s+id="([^"]*)"',
                  lambda m: "" if m.group(1) not in refs else m.group(0), body)


def normalize(svg):
    """Rewrite only the opening <svg> tag. Body bytes are passed through."""
    end = svg.index(">") + 1
    open_tag, body = svg[:end], strip_unused_ids(svg[end:])
    attrs = parse_attrs(open_tag)
    out = {}
    out["xmlns"] = "http://www.w3.org/2000/svg"
    out["width"] = "1em"
    out["height"] = "1em"
    if "fill" in attrs:
        out["fill"] = attrs["fill"]
    if "viewBox" in attrs:
        out["viewBox"] = attrs["viewBox"]
    color = attrs.get("color", "")
    if color and color != "currentColor":
        out["color"] = color
    for k, v in attrs.items():
        if k in out or k in DROP_ATTRS or k in ("color", "xmlns", "width", "height"):
            continue
        if k.startswith(("data-", "aria-", "on")):
            continue
        out[k] = v
    order = ["xmlns", "width", "height", "fill", "viewBox", "color"]
    keys = [k for k in order if k in out] + [k for k in out if k not in order]
    tag = "<svg " + " ".join('%s="%s"' % (k, out[k]) for k in keys) + ">"
    return tag + body


def geometry_key(svg):
    """Identity = the shape itself, independent of wrapper attrs/naming."""
    body = svg[svg.index(">") + 1:]
    geom = "|".join(GEOM_RE.findall(body))
    vb = VIEWBOX_RE.search(svg)
    return hashlib.sha1((geom + "#" + (vb.group(1) if vb else "")).encode()).hexdigest()


def dims(svg):
    vb = VIEWBOX_RE.search(svg)
    if not vb:
        return ""
    p = vb.group(1).replace(",", " ").split()
    if len(p) != 4:
        return ""
    def fmt(x):
        f = float(x)
        return str(int(f)) if f == int(f) else str(f)
    return "%s×%s" % (fmt(p[2]), fmt(p[3]))


def uses_currentcolor(svg):
    return "currentColor" in svg


BTN_OPEN_RE = re.compile(r'<(button|a)\b[^>]*>|<[^>]*\brole="button"[^>]*>', re.I)
# a span that exists only for screen readers, not a visible label
SR_ONLY_RE = re.compile(
    r'<span[^>]*style="[^"]*(?:clip:\s*rect\(0|width:\s*1px)[^"]*"[^>]*>.*?</span>', re.S | re.I)
TAG_RE = re.compile(r"<[^>]+>", re.S)


def enclosing_control(blob, start, end):
    """
    Walk backwards for the nearest <button>/<a>/[role=button] that encloses this svg,
    then forward to its matching close tag. Returns (outer_html, tag) or (None, None).
    """
    for m in reversed(list(BTN_OPEN_RE.finditer(blob, 0, start))):
        tag = (re.match(r"<(\w+)", m.group(0)) or [None, "div"])[1]
        if m.group(0).endswith("/>"):
            continue
        depth, pos = 1, m.end()
        open_re = re.compile(r"<%s\b" % tag, re.I)
        close_re = re.compile(r"</%s\s*>" % tag, re.I)
        while depth and pos < len(blob):
            o, c = open_re.search(blob, pos), close_re.search(blob, pos)
            if not c:
                break
            if o and o.start() < c.start():
                depth += 1
                pos = o.end()
            else:
                depth -= 1
                pos = c.end()
        if depth == 0 and pos >= end:
            return blob[m.start():pos], tag
    return None, None


def visible_text(html):
    """
    Text a sighted user actually reads on the control.

    Two things get removed. First, spans styled as screen-reader-only (the
    clip-rect / 1px trick). Second — because inline styles are easy to lose in a
    paste — any span whose text merely repeats an aria-label already present on
    the control or its glyph, which is the same a11y duplicate by another route.
    """
    labels = {v.strip().lower() for v in re.findall(r'aria-label="([^"]*)"', html)}
    stripped = SR_ONLY_RE.sub("", SVG_RE.sub("", html))

    def drop_echo(m):
        txt = re.sub(r"\s+", " ", TAG_RE.sub("", m.group(0))).strip().lower()
        return "" if txt in labels else m.group(0)
    stripped = re.sub(r"<span\b[^>]*>.*?</span>", drop_echo, stripped, flags=re.S | re.I)
    return re.sub(r"\s+", " ", TAG_RE.sub(" ", stripped)).strip()


def clean_control(outer, tag, svgs_normalized):
    """Rebuild the control with framework noise dropped and its glyph(s) normalized."""
    end = outer.index(">") + 1
    attrs = parse_attrs(outer[:end])
    keep = {}
    for k in ("type", "href", "aria-label"):
        if k in attrs:
            keep[k] = attrs[k]
    keep.setdefault("type", "button") if tag == "button" else None
    label = visible_text(outer)
    inner = "".join(svgs_normalized) + (label if label else "")
    a = "".join(' %s="%s"' % (k, v) for k, v in keep.items())
    return "<%s%s>%s</%s>" % (tag, a, inner, tag)


def existing_keys():
    if not os.path.exists(LIBRARY_HTML):
        return {}
    html = open(LIBRARY_HTML, encoding="utf-8").read()
    return {geometry_key(svg): True for svg in SVG_RE.findall(html)}


def main(argv):
    paths = argv[1:]
    if not paths:
        print(__doc__)
        return 1
    blobs = []
    for p in paths:
        blobs.append(sys.stdin.read() if p == "-" else open(p, encoding="utf-8").read())
    known = existing_keys()
    seen = set()
    out = []
    components = []
    seen_components = set()
    n = 0
    for blob in blobs:
        for m in SVG_RE.finditer(blob):
            raw = m.group(0)
            n += 1
            outer, tag = enclosing_control(blob, m.start(), m.end())
            label = visible_text(outer) if outer else ""
            siblings = SVG_RE.findall(outer) if outer else [raw]

            key = geometry_key(raw)
            if key not in seen:
                seen.add(key)
                svg = normalize(raw)
                icon = {
                    "name": guess_name(raw, n, blob[m.end():m.end() + 60]),
                    "svg": svg,
                    "dims": dims(svg),
                    "currentColor": uses_currentcolor(svg),
                    "key": key,
                    "duplicate_of_library": key in known,
                }
                if label:
                    icon["button_label"] = label
                    icon["note"] = ('Ships as a labelled %s, not a bare glyph: the icon sits '
                                    'left of the text "%s". Stored here as the glyph alone; '
                                    'the assembled control is in the composite-controls '
                                    'section.' % (tag, label))
                if len(siblings) > 1:
                    icon["sibling_icons"] = len(siblings)
                out.append(icon)

            # a control pairing a glyph with visible text is its own reusable component
            if label:
                markup = clean_control(outer, tag, [normalize(s) for s in siblings])
                ckey = hashlib.sha1(markup.encode()).hexdigest()
                if ckey not in seen_components:
                    seen_components.add(ckey)
                    icon_names = [guess_name(s, 0) for s in siblings]
                    components.append({
                        "kind": "component",
                        "name": "%s button" % label,
                        "label": label,
                        "tag": tag,
                        "icon_count": len(siblings),
                        "markup": markup,
                        "icon_keys": [geometry_key(s) for s in siblings],
                        "icon_names": icon_names,
                    })
    fresh = [o for o in out if not o["duplicate_of_library"]]
    sys.stderr.write("scanned %d svg(s); %d unique; %d already in library; %d new\n"
                     % (n, len(out), len(out) - len(fresh), len(fresh)))
    if components:
        sys.stderr.write("%d labelled control(s): %s\n"
                         % (len(components), ", ".join(c["label"] for c in components)))
    json.dump(out + components, sys.stdout, indent=2, ensure_ascii=False)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
