#!/usr/bin/env python3
"""
build_tokens.py — mine pastes/*.html for the design tokens that surround the
icons, so generated UI has correct chrome and not just correct glyphs.

Emits tokens.json (+ a `gaps` list). Every token carries the file it came from;
nothing here is invented. Where the captures don't cover something, it is listed
under `gaps` rather than guessed — an agent should treat a gap as "go capture
more markup", never as licence to make a value up.

    python3 tools/build_tokens.py
"""
import collections
import glob
import json
import os
import re

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PASTES = os.path.join(ROOT, "pastes", "*.html")
OUT = os.path.join(ROOT, "tokens.json")

# Tailwind's spacing scale is 4px per step; these appear as size-4 / size-8 etc.
TW_STEP = 4
TW_RADIUS = {"rounded-sm": "2px", "rounded": "4px", "rounded-md": "6px",
             "rounded-lg": "8px", "rounded-xl": "12px", "rounded-2xl": "16px",
             "rounded-full": "9999px"}

# Semantic reading of the presence palette, keyed off the status attribute that
# sits on the same element as the swatch — not off the colour value itself.
STATUS_RE = re.compile(r'status="(\w+)"[^>]*>.*?fill="(#[0-9A-Fa-f]{6})"', re.S)


def rel(p):
    return os.path.relpath(p, ROOT)


def main():
    files = sorted(glob.glob(PASTES))
    blob = {f: open(f, encoding="utf-8").read() for f in files}

    presence, colors, cssvars = {}, collections.defaultdict(set), {}
    sizes, radii = collections.Counter(), collections.Counter()
    widths = collections.defaultdict(set)

    for f, txt in blob.items():
        for status, hexv in STATUS_RE.findall(txt):
            presence.setdefault(status, {"value": hexv.upper(), "source": rel(f)})
        for hexv in re.findall(r'#[0-9A-Fa-f]{6}\b', txt):
            colors[hexv.upper()].add(rel(f))
        for name, val in re.findall(r'(--[a-z0-9-]+):\s*([^;"]+)', txt):
            if name.startswith(("--radix-", "--button-focus")):
                continue  # runtime layout values, not design tokens
            cssvars.setdefault(name, {"value": val.strip(), "source": rel(f)})
        for cls in re.findall(r'\bsize-(\d+)\b', txt):
            sizes[int(cls) * TW_STEP] += 1
        for cls in re.findall(r'\brounded(?:-[a-z0-9]+)?\b', txt):
            if cls in TW_RADIUS:
                radii[TW_RADIUS[cls]] += 1
        for prop, val in re.findall(r'\b(width|height):\s*(\d+)px', txt):
            if int(val) > 1:
                widths[f"{prop}:{val}px"].add(rel(f))

    # ---- typography, straight out of the editor's own custom properties
    typography = {}
    for k, v in cssvars.items():
        m = re.match(r'--(font-size|line-height)-(\w+)$', k)
        if m:
            typography.setdefault(m.group(2), {})[m.group(1)] = v["value"]

    tokens = {
        "_meta": {
            "generated_by": "tools/build_tokens.py",
            "sources": [rel(f) for f in files],
            "rule": "Every value below is quoted from captured Zoom markup. "
                    "Anything absent is listed in `gaps` — capture more DOM "
                    "rather than inventing a value.",
        },
        "presence": presence,
        "typography": typography,
        "control": {
            "iconButton": {"box": "32px", "glyph": "16px",
                           "note": "size-8 control wrapping a size-4 glyph; the "
                                   "dominant pairing across every capture",
                           "source": "pastes/*.html (size-8 x10, size-4 x59)"},
            "glyphSizes": {f"{k}px": v for k, v in sorted(sizes.items())},
        },
        "radius": {k: v for k, v in radii.most_common()},
        "layout": {
            "sidebarWidth": "328px",
            "aiPanelWidth": "384px",
            "composerMinHeight": "40px",
            "composerMaxHeight": "291px",
            "source": "pastes/paste-team-chat-tokens.html",
        },
        "colorsSeen": {k: sorted(v) for k, v in sorted(colors.items())},
        "cssVariables": cssvars,
        "gaps": [
            "No full neutral/grey ramp captured — only incidental values.",
            "No hover/active/focus state colours captured.",
            "No dark-theme values captured; every paste is data-theme=\"light\".",
            "No elevation/shadow tokens captured.",
            "Semantic roles (primary, danger, surface) are inferred from a single "
            "usage each — treat as provisional until a settings or theme panel is captured.",
        ],
    }

    json.dump(tokens, open(OUT, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    print(f"wrote tokens.json from {len(files)} paste(s)")
    print(f"   presence states : {', '.join(presence) or '—'}")
    print(f"   type scales     : {', '.join(sorted(typography)) or '—'}")
    print(f"   distinct colours: {len(colors)}")
    print(f"   radii           : {', '.join(tokens['radius']) or '—'}")
    print(f"   gaps flagged    : {len(tokens['gaps'])}")


if __name__ == "__main__":
    main()
