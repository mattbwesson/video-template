# Zoom icon index

Derived from `zoom-asset-library.html` by `tools/build_index.py`. Do not edit by hand.

190 icons. Resolve one to markup with:

```bash
python3 tools/icon_lookup.py "<query>"
```

`cc` = recolorable via `currentColor`. `px` = artboard size.

## Brand & wordmarks

_kind: `brand`_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `brand.zoom-workplace-lockup` | Zoom Workplace lockup | 91 | no | — |

## ZoomMate

_kind: `brand`_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `brand.zoommate-sparkle` | ZoomMate sparkle | 16 | yes | ai, assistant, genai, magic |

## Chat & navigation glyphs

_kind: `ui-glyph` · slots: nav-rail, sidebar_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.history-recents` | History (recents) | 16 | yes | — |
| `ui.team-chat-1` | Team Chat | 16 | yes | — |
| `ui.mentions` | Mentions | 16 | yes | @, at sign |
| `ui.chats` | Chats | 16 | yes | — |
| `ui.channels` | Channels | 16 | yes | — |
| `ui.meeting-chats` | Meeting chats | 16 | yes | — |

## Workflow node glyphs

_kind: `ui-glyph` · slots: canvas, workflow-node_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.ai-reasoning` | AI reasoning | 16 | no | — |
| `ui.meeting-event-calendar` | Meeting event (calendar) | 18 | no | date, schedule |
| `ui.condition-flow-controls` | Condition / Flow controls | 18 | no | — |

## Tool-set glyphs

_kind: `app-tile` · slots: app-launcher, tool-picker_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `app.zoom-clips` | Zoom Clips | 16 | yes | — |
| `app.zoom-docs` | Zoom Docs | 16 | yes | — |
| `app.mail-1` | Mail | 16 | yes | email, envelope, inbox |
| `app.zoom-meetings-16` | Zoom Meetings | 16 | yes | — |
| `app.zoom-tasks` | Zoom Tasks | 16 | yes | — |
| `app.zoom-team-chat-16` | Zoom Team Chat | 16 | yes | — |
| `app.zoom-whiteboards` | Zoom Whiteboards | 16 | yes | — |
| `app.web-search-generic-globe-approximation` | Web Search (generic globe — approximation) | 24 | no | find, lookup, magnifier, magnifying glass |
| `app.home` | Home | 16 | yes | — |
| `app.zoommate` | ZoomMate | 16 | yes | — |
| `app.meetings` | Meetings | 16 | yes | — |
| `app.calendar` | Calendar | 16 | yes | date, event, schedule |
| `app.chat` | Chat | 16 | yes | — |
| `app.phone` | Phone | 16 | yes | call, dial, telephone |
| `app.revenue-accelerator` | Revenue Accelerator | 16 | yes | — |
| `app.scheduler` | Scheduler | 16 | yes | — |
| `app.workspaces` | Workspaces | 16 | yes | — |
| `app.hub` | Hub | 16 | yes | — |
| `app.canvas` | Canvas | 16 | no | — |
| `app.paper` | Paper | 16 | no | — |
| `app.sheets` | Sheets | 28 | no | — |
| `app.slides` | Slides | 16 | no | — |
| `app.videos` | Videos | 16 | yes | camera, meet, webcam |
| `app.whiteboards` | Whiteboards | 16 | yes | — |
| `app.clips` | Clips | 16 | yes | — |
| `app.tasks` | Tasks | 16 | yes | — |
| `app.notes` | Notes | 16 | yes | — |
| `app.mail-2` | Mail | 16 | yes | email, envelope, inbox |
| `app.surveys` | Surveys | 16 | yes | — |
| `app.marketplace` | Marketplace | 16 | no | — |
| `app.contacts` | Contacts | 16 | yes | member, profile, user |
| `app.workflows` | Workflows | 16 | yes | — |
| `app.webinars` | Webinars | 16 | yes | — |
| `app.webinars-plus` | Webinars Plus | 27 | yes | add, create, new |
| `app.events` | Events | 16 | yes | — |
| `app.auto-dialer` | Auto Dialer | 16 | yes | — |

## Zoom product app icons (squircle logos)

_kind: `app-squircle`_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `app.zoom-meetings-121` | Zoom Meetings | 121 | no | — |
| `app.zoom-team-chat-121` | Zoom Team Chat | 121 | no | — |
| `app.zoom-contact-center` | Zoom Contact Center | 401 | no | member, profile, user |

## UI glyphs (16×16, currentColor)

_kind: `ui-glyph` · slots: toolbar, nav-rail, inline_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.sparkle-4-point-spark` | Sparkle (4-point + spark) | 16 | yes | ai, assistant, genai, magic |
| `ui.upload-to-cloud` | Upload to cloud | 16 | yes | cloud upload, import |
| `ui.pencil-edit` | Pencil / edit | 16 | yes | compose, modify, rename |
| `ui.trash-delete` | Trash / delete | 16 | yes | bin, discard, remove |
| `ui.hub` | Hub | 16 | yes | — |
| `ui.chat` | Chat | 16 | yes | — |
| `ui.home` | Home | 16 | yes | — |
| `ui.meetings` | Meetings | 16 | yes | — |
| `ui.phone` | Phone | 16 | yes | call, dial, telephone |
| `ui.more` | More | 16 | yes | kebab, meatball, more actions, overflow menu, three dots |
| `ui.settings-16` | Settings | 16 | yes | cog, gear, options, preferences |
| `ui.scheduler` | Scheduler | 16 | yes | — |
| `ui.workspaces` | Workspaces | 16 | yes | — |
| `ui.canvas` | Canvas | 16 | yes | — |
| `ui.videos` | Videos | 16 | yes | camera, meet, webcam |
| `ui.whiteboards` | Whiteboards | 16 | yes | — |
| `ui.clips` | Clips | 16 | yes | — |
| `ui.tasks` | Tasks | 16 | yes | — |
| `ui.notes` | Notes | 16 | yes | — |
| `ui.mail` | Mail | 16 | yes | email, envelope, inbox |
| `ui.surveys` | Surveys | 16 | yes | — |
| `ui.contacts` | Contacts | 16 | yes | member, profile, user |
| `ui.paper` | Paper | 16 | yes | — |
| `ui.sheets` | Sheets | 16 | yes | — |
| `ui.slides` | Slides | 16 | yes | — |

## Chat widget glyphs

_kind: `ui-glyph` · slots: composer, message-hover_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.chevron-collapse` | Chevron (collapse) | 25 | yes | caret, disclosure arrow, dropdown, expand arrow |
| `ui.overflow-menu-kebab` | Overflow menu (kebab) | 28 | yes | meatball, more actions, three dots |
| `ui.emoji-smiley` | Emoji / smiley | 26 | yes | reaction, smiley face |
| `ui.send-26` | Send | 26 | yes | paper plane, submit |
| `ui.attach-paperclip` | Attach (paperclip) | 23 | yes | attachment, file upload |

## Incoming-call screen glyphs

_kind: `ui-glyph` · slots: call-screen, status-bar_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.person-avatar` | Person (avatar) | 80 | yes | member, profile, user |
| `ui.phone-accept-call` | Phone (accept call) | 28 | yes | dial, telephone |
| `ui.skip-arrow-right` | Skip (arrow right) | 22 | no | — |
| `ui.status-bar-cellular` | Status bar — cellular | 20 | no | — |
| `ui.status-bar-wi-fi` | Status bar — wi-fi | 18 | no | — |
| `ui.status-bar-battery` | Status bar — battery | 25 | no | — |

## Skill & onboarding illustrations

_kind: `illustration`_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `illustration.call-routing` | Call routing | 200 | no | — |
| `illustration.transfer-by-name` | Transfer by name | 200 | no | — |
| `illustration.scheduling` | Scheduling | 200 | no | — |

## Zoom Docs toolbar glyphs

_kind: `ui-glyph` · slots: toolbar, formatting-bar_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.undo` | Undo | 17 | yes | — |
| `ui.redo` | Redo | 17 | yes | — |
| `ui.turn-into-text-formatting` | Turn into (text formatting) | 18 | yes | — |
| `ui.dropdown-arrow-8` | Dropdown arrow | 8 | yes | caret, disclosure arrow, expand arrow |
| `ui.bold` | Bold | 16 | yes | — |
| `ui.italicize` | Italicize | 16 | yes | — |
| `ui.underline` | Underline | 16 | yes | — |
| `ui.strikethrough` | Strikethrough | 16 | yes | — |
| `ui.text-color` | Text color | 12 | yes | — |
| `ui.link` | Link | 16 | yes | anchor, hyperlink, url |
| `ui.mark-as-code` | Mark as code | 16 | yes | — |
| `ui.turn-into-list` | Turn into list | 19 | yes | — |
| `ui.indent` | Indent | 16 | yes | — |
| `ui.insert` | Insert | 16 | no | — |

## Zoom Docs header controls

_kind: `ui-glyph` · slots: header, toolbar_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.share` | Share | 12 | yes | — |
| `ui.copy-doc-link` | Copy doc link | 16 | yes | anchor, hyperlink, url |
| `ui.polished-view` | Polished view | 15 | yes | — |
| `ui.document-meeting-options` | Document meeting options | 14 | yes | — |
| `ui.view-docs-activity-center` | View Docs activity center | 14 | yes | — |
| `ui.open-ai-chat` | Open AI chat | 32 | yes | — |

## Zoom Docs header toolbar (file info)

_kind: `ui-glyph` · slots: header_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.back` | Back | 20 | yes | — |
| `ui.add-page` | Add page | 16 | yes | create, new |
| `ui.dropdown-arrow-17` | Dropdown arrow | 17 | yes | caret, disclosure arrow, expand arrow |
| `ui.add-to-starred-16` | Add to starred | 16 | yes | bookmark, create, favorite, new, pin |
| `ui.synced` | Synced | 16 | yes | — |

## Zoom Docs file menu options

_kind: `ui-glyph` · slots: menu-item, dropdown_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.open-in-new-tab` | Open in new tab | 17 | yes | — |
| `ui.suggest-edits` | Suggest edits | 16 | yes | compose, modify, rename |
| `ui.subscribe-to-updates` | Subscribe to updates | 17 | yes | — |
| `ui.add-to-starred-19` | Add to starred | 19 | yes | bookmark, create, favorite, new, pin |
| `ui.copy-page-content` | Copy page content | 16 | yes | — |
| `ui.duplicate` | Duplicate | 17 | yes | — |
| `ui.move` | Move | 17 | yes | — |
| `ui.add-shortcut` | Add shortcut | 16 | yes | create, new |
| `ui.turn-into-a-presentation` | Turn into a presentation | 16 | yes | — |
| `ui.save-as-template` | Save as template | 16 | yes | — |
| `ui.submenu-arrow-chevron-right` | Submenu arrow (chevron right) | 19 | yes | caret, disclosure arrow, dropdown, expand arrow |
| `ui.find-and-replace` | Find and replace | 16 | yes | — |
| `ui.page-width-default` | Page width — Default | 63 | no | — |
| `ui.page-width-medium` | Page width — Medium | 62 | no | — |
| `ui.page-width-full` | Page width — Full | 63 | no | — |
| `ui.page-options` | Page options | 16 | yes | — |
| `ui.auto-suggest` | Auto-suggest | 17 | yes | — |
| `ui.instant-translate` | Instant translate | 16 | yes | — |
| `ui.shortcut-to-ai` | Shortcut to AI | 16 | yes | — |
| `ui.translate-full-page` | Translate full page | 14 | yes | — |
| `ui.page-info` | Page info | 16 | yes | — |
| `ui.version-history` | Version history | 16 | yes | — |
| `ui.save-version` | Save version | 16 | yes | — |
| `ui.comment-keyboard-shortcut` | Comment keyboard shortcut | 16 | yes | — |
| `ui.export` | Export | 16 | yes | download as, share out |
| `ui.print` | Print | 16 | yes | printer |
| `ui.help-and-resources` | Help and resources | 16 | yes | — |
| `ui.more-ellipsis` | More (ellipsis) | 12 | yes | kebab, meatball, more actions, overflow menu, three dots |
| `ui.delete` | Delete | 17 | yes | bin, discard, remove |

## ZoomMate UI Components

_kind: `ui-glyph` · slots: sidebar, toolbar, header_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.search` | Search | 24 | yes | find, lookup, magnifier, magnifying glass |
| `ui.collapse-sidebar` | Collapse sidebar | 24 | yes | hide sidebar, panel toggle |
| `ui.plus-24` | Plus | 24 | yes | add, create, new |
| `ui.workflow` | Workflow | 24 | yes | — |
| `ui.chevron-right` | Chevron right | 24 | yes | caret, disclosure arrow, dropdown, expand arrow |
| `ui.files` | Files | 24 | yes | — |
| `ui.calendar-clock` | Calendar clock | 24 | yes | date, event, schedule |
| `ui.calendar` | Calendar | 24 | yes | date, event, schedule |
| `ui.file-text` | File text | 24 | yes | — |
| `ui.star-24` | Star | 24 | yes | bookmark, favorite, pin |
| `ui.ellipsis` | Ellipsis | 24 | yes | kebab, meatball, more actions, overflow menu, three dots |
| `ui.list-filter` | List filter | 24 | yes | refine, sort |
| `ui.settings-24` | Settings | 24 | yes | cog, gear, options, preferences |
| `ui.zoom` | Zoom | 53 | no | — |
| `ui.wallet-credits` | Wallet / Credits | 24 | yes | compose, modify, rename |
| `ui.feedback` | Feedback | 16 | yes | — |
| `ui.bell-notifications` | Bell / Notifications | 24 | yes | alerts |
| `ui.apps-waffle-menu` | Apps / Waffle menu | 16 | no | app grid, launcher, nine dots |

## ZoomMate home quick actions

_kind: `ui-glyph` · slots: home, quick-action_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.drive-meeting` | Drive meeting | 16 | yes | — |
| `ui.build-slides` | Build slides | 16 | yes | — |
| `ui.draft-document` | Draft document | 16 | yes | — |
| `ui.create-image` | Create image | 16 | yes | — |
| `ui.chevron-down` | Chevron down | 24 | yes | caret, disclosure arrow, dropdown, expand arrow |
| `ui.build-project` | Build project | 24 | yes | — |
| `ui.explore-deep-research` | Explore deep research | 15 | yes | find, lookup, magnifier, magnifying glass |
| `ui.generate-video` | Generate video | 24 | yes | camera, meet, webcam |
| `ui.build-webpage` | Build webpage | 16 | yes | — |
| `ui.generate-audio` | Generate audio | 16 | yes | — |
| `ui.research-a-stock` | Research a stock | 24 | yes | find, lookup, magnifier, magnifying glass |
| `ui.create-diagrams` | Create diagrams | 16 | yes | — |
| `ui.schedule-task` | Schedule task | 16 | yes | — |

## Zoom Team Chat controls

_kind: `ui-glyph` · slots: header, toolbar, nav-rail, composer_

| id | name | px | cc | aliases |
|---|---|---|---|---|
| `ui.chevron-down-v2` | Chevron Down V2 | 16 | yes | caret, disclosure arrow, dropdown, expand arrow |
| `ui.plus-16` | Plus | 16 | yes | add, create, new |
| `ui.mention-v2` | Mention V2 | 16 | yes | @, at sign |
| `ui.team-chat-2` | Team Chat | 16 | yes | — |
| `ui.agentai-interact` | AgentAI Interact | 16 | yes | assistant, genai, magic |
| `ui.share-space` | Share Space | 16 | yes | — |
| `ui.folder` | Folder | 16 | yes | directory |
| `ui.star-16` | Star | 16 | yes | bookmark, favorite, pin |
| `ui.chevron-right-v2` | Chevron Right V2 | 16 | yes | caret, disclosure arrow, dropdown, expand arrow |
| `ui.arrow-down` | Arrow Down | 16 | yes | descend, download |
| `ui.ai-companion` | AI Companion | 16 | yes | assistant, genai, magic |
| `ui.file-resource` | File Resource | 16 | yes | — |
| `ui.add-canvas-doc` | Add Canvas Doc | 14 | yes | create, new |
| `ui.send-16` | Send | 16 | yes | paper plane, submit |
| `ui.chevron-small-down` | Chevron Small Down | 8 | yes | caret, disclosure arrow, dropdown, expand arrow |
| `ui.drag-handle-horizontal-dots` | Drag Handle Horizontal Dots | 16 | yes | grabber, grip, reorder |
