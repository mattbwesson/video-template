/**
 * Compile-time tests for MatchCut's props union. There is no runtime here — the
 * assertion IS the typecheck.
 *
 *   npm run typecheck
 *
 * Every `@ts-expect-error` below must ERROR. If a change makes one of them start
 * compiling, TypeScript reports "Unused '@ts-expect-error' directive" and the
 * typecheck fails — so this file fails in BOTH directions, which is what makes it
 * a real test rather than a comment.
 *
 * Why this file exists: the failure mode it guards is silent. Before the props
 * were discriminated, `<MatchCut mode="directional" scale={{...}} />` compiled
 * happily and did nothing at all — the scale config was simply ignored at
 * runtime. Guessing a plausible-but-wrong config key is one of the most common
 * ways an LLM uses a library, and a compile error is the only feedback fast
 * enough to catch it.
 */
import React from "react";
import { MatchCut, matchCutCutFrame, matchCutDuration, matchCutPanelLifetime } from "../match-cut";

const A = <div />;
const B = <div />;

// --- each mode accepts its own config -----------------------------------------
export const validScale = (
  <MatchCut mode="scale" outgoing={A} incoming={B} transitionDurationInFrames={16} scale={{ direction: "out", scaleFactor: 4 }} />
);
export const validDirectional = (
  <MatchCut mode="directional" outgoing={A} incoming={B} transitionDurationInFrames={16} directional={{ angleDeg: 180 }} />
);
export const validDirectionalNamed = (
  <MatchCut mode="directional" outgoing={A} incoming={B} transitionDurationInFrames={16} directional={{ enterFrom: "top" }} />
);
export const validDirectionalScale = (
  <MatchCut
    mode="directional-scale"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={16}
    directionalScale={{ enterFrom: "right", direction: "out", travelDistance: 0.7 }}
  />
);
export const validRotational = (
  <MatchCut mode="rotational" outgoing={A} incoming={B} transitionDurationInFrames={24} rotational={{ direction: "ccw", totalDegrees: 360 }} />
);
export const validScaleRotational = (
  <MatchCut mode="scale-rotational" outgoing={A} incoming={B} transitionDurationInFrames={24} scaleRotational={{ rotationDirection: "ccw" }} />
);
export const validPerspective = (
  <MatchCut mode="perspective" outgoing={A} incoming={B} transitionDurationInFrames={20} perspective={{ axis: "x", totalDegrees: 180 }} />
);

// --- the shared base is available on every mode -------------------------------
export const validBase = (
  <MatchCut
    mode="rotational"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={20}
    holdBefore={10}
    holdAfter={12}
    intensity="soft"
    debugAlign={false}
  />
);

// --- a config that belongs to a DIFFERENT mode is rejected --------------------
// This is the case that used to compile and silently do nothing.
export const wrongConfigForMode = (
  <MatchCut
    mode="directional"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={16}
    // @ts-expect-error — `scale` belongs to mode "scale", not "directional"
    scale={{ direction: "in" }}
  />
);

export const wrongConfigForMode2 = (
  <MatchCut
    mode="scale"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={16}
    // @ts-expect-error — `rotational` belongs to mode "rotational", not "scale"
    rotational={{ direction: "cw" }}
  />
);

export const wrongConfigForMode3 = (
  <MatchCut
    mode="perspective"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={16}
    // @ts-expect-error — `directionalScale` belongs to mode "directional-scale"
    directionalScale={{ angleDeg: 90 }}
  />
);

// --- misspelled / invented keys are rejected ----------------------------------
export const misspelledKey = (
  <MatchCut
    mode="directional"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={16}
    // @ts-expect-error — no such prop; the real one is `directional`
    direction={{ angleDeg: 0 }}
  />
);

export const invalidEnumValue = (
  <MatchCut
    mode="directional"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={16}
    // @ts-expect-error — "diagonal" is not one of the four cardinals
    directional={{ enterFrom: "diagonal" }}
  />
);

export const invalidIntensity = (
  <MatchCut
    mode="scale"
    outgoing={A}
    incoming={B}
    transitionDurationInFrames={16}
    // @ts-expect-error — intensity is "hard" | "medium" | "soft"
    intensity="strong"
  />
);

// @ts-expect-error — `mode` is required and must be one of the six
export const invalidMode = <MatchCut mode="zoom" outgoing={A} incoming={B} transitionDurationInFrames={16} />;

// @ts-expect-error — transitionDurationInFrames is required
export const missingRequired = <MatchCut mode="scale" outgoing={A} incoming={B} />;

// --- timing helpers accept a bare timing object (no scenes needed) ------------
export const duration: number = matchCutDuration({
  transitionDurationInFrames: 16,
  holdBefore: 18,
  holdAfter: 22,
});
export const cutAt: number = matchCutCutFrame({
  transitionDurationInFrames: 16,
  holdBefore: 18,
  mode: "perspective",
});
export const lifetime = matchCutPanelLifetime({
  transitionDurationInFrames: 16,
  holdBefore: 18,
  holdAfter: 22,
  mode: "directional",
});
export const outgoingFrames: number = lifetime.outgoing.durationInFrames;
