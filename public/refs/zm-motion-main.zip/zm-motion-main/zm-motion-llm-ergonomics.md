# Making `zm-motion` easier for an LLM to use

Recommendations for [mattbwesson/zm-motion](https://github.com/mattbwesson/zm-motion),
written from the outside — as the consumer that just spent a long session building
and refactoring a video against it.

**Method.** Every item below is grounded in something that actually cost time while
working on `Video_Auto Receptionist`, not in a general style checklist. Where a
recommendation has evidence, the evidence is a real incident from that session.
Read against the installed copy: `node_modules/zm-motion`, `version 0.1.0`,
resolved from commit `705a65d`. Your `main` may have moved since.

**The one-line summary.** The library's problem is not that it is
under-documented — `match-cut.tsx` carries ~90 lines of genuinely excellent
prose. The problem is that its most important facts live in **prose** when they
need to live in **types, names, exports and errors**. Prose is what an LLM reads
last and trusts least; a compile error is what it cannot ignore.

---

## Priority

| # | Change | Effort | Why it matters |
|---|---|---|---|
| 1 | Bound `DirectionalMatchCut`'s mounting + say so in its type | S | Caused the worst render bug in the consuming project |
| 2 | Export all 68 components from the barrel | S | The library is currently ~94% invisible |
| 3 | Export `MatchCut`'s timing math | S | Callers are re-deriving library internals by hand |
| 4 | Discriminate the `MatchCutProps` union | S | Wrong config silently compiles today |
| 5 | Re-export `lib/` from the barrel | XS | `framesFor` exists; the consumer hardcoded fps 18 times |
| 6 | Ship a machine-readable component inventory | M | This is the first file an LLM would read |
| 7 | Name directions instead of `angleDeg` | M | 180°-wrong output renders fine and looks subtly off |
| 8 | Delete the dead `holdAfter` prop | XS | A documented no-op is worse than a missing prop |
| 9 | Document the frame-space contract once | XS | Consumer re-explained it in 4 files |
| 10 | Golden-frame tests | M | Catches exactly the bugs this library is prone to |
| 11 | JSDoc the 66 vendored primitives' props | M | For an LLM, the type signature *is* the doc |
| 12 | Add `CLAUDE.md` / `AGENTS.md` | S | Conventions in the place agents look |
| 13 | Strip `"use client"` (67 files) | XS | Meaningless in Remotion; gets cargo-culted |
| 14 | Ship a `tsconfig.json` | XS | Consumers compile your raw `.ts` |
| 15 | Tag releases, bump the version | S | No signal when behaviour changes |

---

## 1. Make the occlusion difference impossible to miss

**The single most expensive thing in the session.** It was the #1 render-cost bug
in the consuming project, and finding it took an adversarial review pass plus
reading the library source directly.

Five of six modes draw one side per frame:

```tsx
// ScaleMatchCut, DirectionalScaleMatchCut, RotationalMatchCut,
// ScaleRotationalMatchCut, PerspectiveMatchCut
return <AbsoluteFill style={{transform, transformOrigin}}>
  {beforeCut ? outgoing : incoming}
</AbsoluteFill>;
```

`DirectionalMatchCut` draws both, unconditionally, for as long as it is mounted —
correctly, because a whip pan with one side drawn shows an empty sweeping edge.
But `matchCutTimeline` clamps progress to `[0, 1]`, so there is no *outside the
transition*: past `holdBefore + T` it keeps rendering the settled panel
off-canvas forever.

At the call site the two are indistinguishable:

```tsx
<MatchCut mode="scale"       outgoing={<A/>} incoming={<B/>} … />  // 1 scene/frame
<MatchCut mode="directional" outgoing={<A/>} incoming={<B/>} … />  // 2 scenes/frame, forever
```

In Remotion that is not a tidiness issue. Every frame is a full render plus a
screenshot, so a mounted-but-invisible element costs full price: layout, paint,
and a complete frame extraction per `<OffthreadVideo>`. In the consuming project
one such panel spanned 587 frames to be visible for 22 — about 1,700 wasted video
frame extractions per render.

**Fix.** Both halves are worth doing.

```diff
+  // Unlike every other mode this one needs BOTH panels on screen at once — a
+  // whip pan with one side drawn shows an empty edge sweeping past. But it needs
+  // them both only WITHIN the transition window. Outside it, matchCutTimeline has
+  // clamped disp to 0 or 1 and the dormant side is parked a full span off-canvas.
+  const showOutgoing = frame <= holdBefore + T;
+  const showIncoming = frame >= holdBefore;
+
   return (
     <AbsoluteFill>
-      {panel(incoming, "incoming")}
-      {panel(outgoing, "outgoing")}
+      {showIncoming && panel(incoming, "incoming")}
+      {showOutgoing && panel(outgoing, "outgoing")}
     </AbsoluteFill>
   );
```

Those bounds are exactly safe, not approximately: `dirTransform` computes
`span = |ux|·width + |uy|·height`, the L1 combination, which is ≥ the true
projected extent along the travel axis for every angle. So `disp` of 0 and 1 are
guaranteed fully clear — including on diagonals, where `span` overshoots.

Then say it in the type, so the cost is legible even to a caller who never opens
the file:

```ts
/** NOTE: "directional" is the only mode that mounts BOTH panels at once (a whip
 *  pan needs edge-to-edge coverage). Every other mode occludes, drawing one side
 *  per frame. Mount cost differs accordingly. */
mode: "scale" | "directional" | …;
```

A side benefit: an off-canvas panel can be dragged back into view by an ancestor
`scale()`. The consuming project hit exactly that and worked around it with an
explicit `opacity: 0` (its comment describes the stray sliver). Unmounted content
cannot be dragged back, so this also removes a real visual-bug class.

## 2. Export all 68 components from the barrel

`index.ts` is 13 lines and exports 4 components. There are 68 `.tsx` files.
Everything else is reachable only by path import.

**This matters more to an LLM than to you.** You know `stepper.tsx` exists. I
found `whip-pan` only because the project already imported it — otherwise I'd
have hand-rolled a whip pan while a tested one sat three files away. Discovering
the library currently requires `ls`, which a model only runs if it already
suspects there's something to find. A barrel means **one file read reveals the
entire surface**, which is the single cheapest thing you can do for agent
usability.

Keep the path imports working for tree-shaking; add the barrel for discovery.

## 3. Export the timing math instead of making callers re-derive it

The pattern already exists in the library — `typewriterTrackingMatchCutDuration`,
`imessageChatFlowDuration` — it just doesn't cover `MatchCut`. So the consuming
project reimplemented library internals in application code:

```tsx
// Main.tsx — reimplementing matchCutTimeline's own split calculation
const INTRO_CUT_SPLIT =
  INTRO_CUT_START_FRAC / (INTRO_CUT_START_FRAC + (1 - INTRO_CUT_END_FRAC));

// …and its clamp point, to know when a panel is safe to unmount
const introCutOutgoingFrames = Math.ceil(holdBefore + INTRO_CUT_DUR) + 2;
```

Both are right only because I read `matchCutTimeline` line by line. Both fail
**silently** when wrong — a slightly-off split just makes the cut feel wrong,
with nothing to debug and no error to search for.

**Fix.** Export the three questions callers actually ask:

```ts
export const matchCutCutFrame      = (o: MatchCutTiming) => number; // where the hard cut lands
export const matchCutWindow        = (o: MatchCutTiming) => {start: number; end: number};
export const matchCutPanelLifetime = (o: MatchCutTiming) => {outgoing: number; incoming: number};
```

Generalise it: **every timed component should export a duration helper.**
Currently 2 of 68 do.

## 4. Discriminate the props union

```ts
mode: "scale" | "directional" | "directional-scale" | …;
scale?: {…};            // all optional
directional?: {…};      // all unrelated to `mode`
rotational?: {…};
```

`<MatchCut mode="directional" scale={{direction: "in"}} />` typechecks and does
nothing.

LLMs guess config-object names constantly — it's one of the most common failure
modes — and this shape guarantees the guess **compiles**. A discriminated union
turns every one of those into a compile error, which is the cheapest feedback
loop available to a model.

```ts
export type MatchCutProps = MatchCutBase &
  ( | {mode: "scale"; scale?: ScaleConfig}
    | {mode: "directional"; directional?: DirectionalConfig}
    | … );
```

**Better still:** export the six modes as six named components
(`ScaleMatchCut`, `DirectionalMatchCut`, …). Each gets its own props type, its
own docstring, and — crucially — its own honest statement about mounting
behaviour, which folds #1 in for free. Keep `<MatchCut mode>` as a thin wrapper
for existing callers.

## 5. Re-export `lib/` from the barrel

`lib/` has a proper barrel of its own — `easings`, `springs`, `framesFor`,
`clamp01`, `revealCount`, OKLCH colour helpers, theme provider — and `index.ts`
mentions it **only in a header comment**. It is invisible to anyone who doesn't
list the package directory.

Evidence of the cost: `lib/timeline.ts` exports

```ts
export function framesFor(d: number | {seconds: number}, fps: number): number
```

which is precisely the "seconds → frames at this composition's fps" problem. The
consuming project solves it by hand **18 times**, each with a hardcoded `24`:

```tsx
const INTRO_WHIP_1_FULLSCREEN_LOOP = Math.round(11.28 * 24);
const INTRO_WHIP_2_STOCK_LOOP      = Math.round(14.6 * 24);
// …16 more
```

Every one of those silently breaks if the composition ever moves off 24fps. The
library already had the answer and nobody could see it.

## 6. Ship a machine-readable component inventory

Add `COMPONENTS.md` (and/or `llms.txt`) with **one row per component** — this is
the first file an agent should read, and the highest-value artifact you can write:

| Component | Import | Does | Key props | Duration helper | Mounts |
|---|---|---|---|---|---|
| `WhipPan` | `zm-motion/whip-pan` | Transition presentation: pan + motion blur | `direction`, `blur` | — | — |
| `MatchCut` | `zm-motion/match-cut` | A→B cut hidden in fast motion | `mode`, `outgoing`, `incoming`, … | `matchCutWindow` | **2 scenes in `directional`**, 1 otherwise |

The **Mounts** column is the one you won't find in other libraries' docs, and
it's the one this session proves you need: in Remotion, "what does this keep
mounted, and for how long" is a first-class cost that nothing else surfaces.

Prose descriptions of two custom compositions (the current README) don't help an
agent choose between 68 options.

## 7. Name directions instead of `angleDeg`

`whip-pan.tsx` already has the good API:

```ts
direction?: "left" | "right" | "up" | "down";
```

`match-cut.tsx` has `angleDeg`, where `0` means *"incoming enters from the LEFT
while both panels travel right."*

The consuming project needed **three separate comments** to pin that down — and
in one place a parent `rotateY(180deg)` makes `angleDeg: 0` read as pan-*left*,
which its own comment has to explain twice. This is a category of bug where the
output renders perfectly and is simply backwards, so nothing catches it but eyes.

Accept `direction: "down"` as the primary API; keep `angleDeg` as the escape
hatch for genuine diagonals. And make the two files agree — an LLM generalises
from whichever it read first.

## 8. Delete `holdAfter`

Declared at `match-cut.tsx:115`, documented as *"Optional static hold on A before
the move, and on B after it"* — and read by **zero** mode components. It appears
exactly once in the file: its own declaration.

I checked it specifically, because I needed to know whether it affected the
unmount bound in #1. A documented prop that does nothing is strictly worse than a
missing one: a model will pass it, get no error, observe no effect, and conclude
the timing problem lies somewhere else entirely.

Either implement it or delete it. Don't leave it declared.

## 9. Document the frame-space contract once

`MatchCut` renders its panels as plain `<div>`s, not `<Sequence>`s, so
`useCurrentFrame()` inside a panel returns the **parent's** frame, not a rebased
one. That is the right design — but it's undocumented, so the consuming project
rediscovered and re-explained it in four separate places (`Main.tsx` twice,
`SchedulingModalsScene.tsx`, `IncomingCallRipple.tsx`).

One sentence on `MatchCutProps` replaces all four:

```ts
/** `outgoing`/`incoming` are rendered as plain elements, NOT wrapped in a
 *  Sequence — so useCurrentFrame() inside them is THIS component's frame,
 *  un-rebased. Wrap a panel in your own <Sequence> if you want it rebased or
 *  time-bounded. */
```

State the same contract for every component that takes `ReactNode` children.

## 10. Add golden-frame tests

There are no tests. For a motion library the obvious objection is "how do you
test animation?" — but this session answered that empirically, and the method
worked extremely well:

```bash
npx remotion still src/index.tsx <Comp> /tmp/new/f100.png --frame=100
# compare md5 against a committed golden
```

Across ~40 verification renders it caught real regressions and, just as usefully,
**proved refactors were byte-identical** — 14 of 17 frames exactly equal after a
1,500-line refactor. That's the difference between "I think this is safe" and "I
know it is."

Two caveats worth encoding in the harness:

- **Not every frame is deterministic.** Frames containing `OffthreadVideo` output
  varied between renders — the same code produced two different hashes, differing
  by max channel delta 1/255. Use a tolerance comparison (max delta ≤ 2), not a
  bare hash, for any frame containing video.
- **Test the mount count, not just the pixels.** The #1 bug here was invisible in
  every frame. A test that renders a component and asserts how many
  `<OffthreadVideo>` elements are mounted at frame N would have caught it
  instantly, and nothing pixel-based ever will.

That second point is the highest-value test you could write for this library.

## 11. JSDoc the vendored primitives' props

Sampled `whip-pan`, `typewriter`, `toast`, `switch`, `drift`: **zero** JSDoc
blocks between them. Your custom pieces are documented well — the gap is entirely
the 66 vendored files.

For an LLM the type signature *is* the documentation: it's what appears in
completions, in hover, and in the error when it gets something wrong. `blur?:
number` tells me nothing; `/** Motion-blur strength in px at peak velocity.
Default 24. */` tells me everything and costs one line.

Prioritise: default values, units (px? frames? seconds? 0–1?), and valid ranges.

## 12. Add `CLAUDE.md` / `AGENTS.md` to the repo root

Agents look there first. It should state the things that aren't inferable from
any single file:

- The frame-space contract (#9).
- The mounting rules — which components keep things mounted, and for how long.
- Naming conventions: what `xFrame` means (does it name where motion *starts* or
  where the cut *lands*? `MatchCut` uses both conventions in different props).
- That primitives are vendored from remocn and shouldn't be hand-edited.
- How to add a component: barrel export + inventory row + duration helper + golden test.

## 13. Strip `"use client"`

67 of 68 files carry it. It's a Next.js App Router directive with no meaning in
Remotion — harmless at runtime, but it signals "this came from a web app context"
and models cargo-cult it into new files they write for you.

## 14. Ship a `tsconfig.json`

`main` and `types` both point at `index.ts`, so consumers compile your raw
TypeScript rather than built `.d.ts` files. That means your source must satisfy
*their* compiler settings, and there's currently no declaration of what settings
you expect (`strict`? `jsx: react-jsx`? `moduleResolution: bundler`?).

It happens to compile clean under this project's config. That's luck, not
contract. Either ship a `tsconfig.json` documenting the requirement, or publish
built types.

## 15. Tag releases and bump the version

`package.json` is `"version": "0.1.0"`, `"private": true`, and consumers install
from `github:mattbwesson/zm-motion` — an unpinned ref that resolves to whatever
the default branch HEAD is.

The consuming lockfile does pin a SHA (`705a65d`), so day-to-day reproducibility
is fine. But there is no signal when behaviour changes: if `DirectionalMatchCut`'s
mounting gets fixed (#1), every consumer's render cost and timing assumptions
shift with no version to notice. Tag releases, bump the version, keep a
`CHANGELOG.md` — and note behaviour changes, not just API changes.

---

## What is deliberately *not* on this list

**More prose.** `match-cut.tsx` already has ~90 lines of high-quality
explanation, including an accurate description of the cut mechanic and its
easing. It did not stop me from missing the mounting bug — because the fact lived
in prose about *motion design* while the cost was a *rendering* property, and
those were 300 lines apart.

Adding more paragraphs would not have helped. A type, a name, an export, or a
compile error would have. That's the whole thesis: **move facts from prose into
the places a machine cannot skip.**

---

## Suggested first PR

Items 1–5 are independent, mechanical, and low-risk, and together they change the
dominant failure mode from *silently wrong render* to *doesn't compile*:

1. Bound `DirectionalMatchCut` mounting (patch above; verified byte-identical
   across 8 frames in the consuming project, including both boundary frames).
2. Barrel-export all components.
3. Export `MatchCut` timing helpers.
4. Discriminate `MatchCutProps`.
5. Re-export `lib/`.

`docs/match-cut-mounting.md` in the consuming repo has the full write-up for #1,
including why the bounds are exactly safe and a verification recipe.
