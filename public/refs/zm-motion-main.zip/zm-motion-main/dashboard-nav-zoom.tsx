/**
 * dashboard-nav-zoom.tsx — the camera pushes into a Zoom account dashboard's
 * left nav while a blue selection pill slides down onto one submenu row.
 *
 * THE SHOT is one continuous push: the whole dashboard (header, sidebar, main
 * canvas) sits inside a single scale+translate wrapper that zooms toward the
 * sidebar's lower-left, so the eye is already headed for the submenu by the
 * time the pill starts moving. Three things happen on their own clocks inside
 * that push:
 *   1. CAMERA  — scale 1 → 2.22, panning toward the submenu. Eased in-out, so
 *               it leaves and arrives slowly and does its travelling in the
 *               middle.
 *   2. ROWS    — the six submenu rows fade + rise in, staggered ~1.8 frames
 *               apart, so they read as a cascade rather than a block appearing.
 *   3. PILL    — a rounded selection pill slides down from off the top of the
 *               list and settles on `targetIndex`. Whichever row it is
 *               currently over gets white text; every other row stays grey —
 *               so if the target is more than one row down, the rows between
 *               it and the top light up briefly as the pill passes them, the
 *               way a real selection affordance reads.
 *
 * SCOPE: ported from a source composition's local frames 0–64, where a hard
 * cut takes the camera to something else mid-zoom (`zoomDurationInFrames`
 * defaults to 84 — the zoom is still travelling when the source cuts away at
 * 65). `dashboardNavZoomDuration()` returns the frame everything has actually
 * settled by; use `durationInFrames={65}` on your own `<Sequence>` instead if
 * you want that exact mid-motion cut.
 *
 * Authored in a 1920x1080 coordinate space, absolutely positioned throughout —
 * to use it at another size, scale the whole component rather than the numbers
 * inside it.
 *
 * The nav copy, colours and layout are kept as the real thing rather than
 * genericized — same call as `zoommate-simple`/`zoommate-full`: this recreates
 * an actual Zoom surface, and abstracting the chrome away would just lose the
 * thing that makes it read as Zoom. What's realistically variable (the row
 * labels, which row is selected, what sits in the empty canvas) is exposed as
 * props with the source's own content as their defaults.
 */
import type { CSSProperties, ReactNode } from "react";
import { AbsoluteFill, Easing, interpolate, useCurrentFrame } from "remotion";

// ── Curves ──────────────────────────────────────────────────────────────────────────

/** Slow out, slow in — the camera push. */
const EASE_ZOOM = Easing.bezier(0.2, 0.81, 0, 0.91);
/** A quick, decisive settle — the selection pill's slide. */
const EASE_PILL = Easing.bezier(0.35, 1, 0.45, 1);
/** Fast start, long settle — each row's own fade + rise. */
const EASE_ROW = Easing.bezier(0.16, 1, 0.3, 1);

const UI_FONT_STACK =
  'Inter, -apple-system, BlinkMacSystemFont, "SF Pro Text", "SF Pro Display", "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
/**
 * The source's wordmark used a licensed display face this library doesn't
 * bundle (see AGENTS.md on shipping assets — a font file isn't something a
 * consumer can be handed for free). This system-font approximation — heavier
 * weight, tightened tracking — reads as a wordmark without it. Pass your own
 * `brandFontFamily` if you have the real face loaded.
 */
const BRAND_FONT_STACK =
  '"SF Pro Display", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';

const DEFAULT_BRAND_COLOR = "#0053f9";

const DEFAULT_NAV_LINKS = ["Products", "Solutions", "Resources", "Plans & pricing"];
const DEFAULT_PERSONAL_SECTION = {
  heading: "PERSONAL",
  items: [
    "Profile",
    "Meetings",
    "Webinars",
    "Personal Audio Conference",
    "Phone",
    "Recordings",
    "Settings",
  ],
};
const DEFAULT_ADMIN_SECTION = { heading: "ADMIN", item: "Dashboard" };
const DEFAULT_SUBMENU_HEADING = { label: "AI Studio", badge: "NEW" };
const DEFAULT_SUBMENU_ITEMS = [
  "Custom Agents",
  "Virtual Agents",
  "AI Expert Assist",
  "Custom AI Companion",
  "Knowledge",
  "Tools",
];

/** Row height + the gap between rows — the pill is sized to one row, so this
 *  is also its own travel step between adjacent targets. */
const SUBMENU_ROW_HEIGHT = 48;
const SUBMENU_ROW_GAP = 4;
const SUBMENU_ROW_PITCH = SUBMENU_ROW_HEIGHT + SUBMENU_ROW_GAP;
/** Where the pill starts: off the top of the list, above row 0, regardless of
 *  how many rows there are or which one is the target. */
const PILL_START_Y = -80;

// ── Schedule ────────────────────────────────────────────────────────────────────────

export interface DashboardNavZoomSchedule {
  /** Frame the camera push begins. Default 0. */
  zoomStart?: number;
  /**
   * Frames the push takes to fully settle (then holds at its final scale).
   * Default 84. The source's own hard cut lands at local frame 65 — well
   * before this — so at the component's literal default duration the camera
   * is still travelling when playback stops. That's intentional; see the file
   * header.
   */
  zoomDurationInFrames?: number;
  /** Frame the first submenu row begins fading up. Default 10. */
  itemsStart?: number;
  /** Frames between each row's own start. Default 1.8 (fractional frames are
   *  fine — `interpolate` doesn't require whole ones). */
  itemStagger?: number;
  /** Frames each row's own fade + rise takes. Default 12. */
  itemDurationInFrames?: number;
  /** Frame the selection pill begins sliding onto `targetIndex`. Default 35. */
  pillStart?: number;
  /** Frames the pill's slide takes. Default 25. */
  pillDurationInFrames?: number;
}

function resolve(schedule: DashboardNavZoomSchedule) {
  return {
    zoomStart: schedule.zoomStart ?? 0,
    zoomDurationInFrames: schedule.zoomDurationInFrames ?? 84,
    itemsStart: schedule.itemsStart ?? 10,
    itemStagger: schedule.itemStagger ?? 1.8,
    itemDurationInFrames: schedule.itemDurationInFrames ?? 12,
    pillStart: schedule.pillStart ?? 35,
    pillDurationInFrames: schedule.pillDurationInFrames ?? 25,
  };
}

export interface DashboardNavZoomBeats {
  zoomStart: number;
  /** Frame the camera has fully settled at its final scale. */
  zoomEnd: number;
  itemsStart: number;
  /** Frame the last row finishes fading + rising in. */
  itemsEnd: number;
  pillStart: number;
  /** Frame the pill has finished sliding onto its target. */
  pillEnd: number;
}

/** Resolves a schedule (and the row count, which the last row's start depends
 *  on) into the absolute frames every beat starts and ends on. */
export function dashboardNavZoomBeats(
  schedule: DashboardNavZoomSchedule = {},
  itemCount: number = DEFAULT_SUBMENU_ITEMS.length,
): DashboardNavZoomBeats {
  const r = resolve(schedule);
  const lastItemStart = r.itemsStart + Math.max(0, itemCount - 1) * r.itemStagger;
  return {
    zoomStart: r.zoomStart,
    zoomEnd: r.zoomStart + r.zoomDurationInFrames,
    itemsStart: r.itemsStart,
    itemsEnd: lastItemStart + r.itemDurationInFrames,
    pillStart: r.pillStart,
    pillEnd: r.pillStart + r.pillDurationInFrames,
  };
}

/**
 * Frame every beat has finished — the camera has settled, every row is in,
 * and the pill has landed. Use this for the "let it settle" version.
 *
 * For the source's own cut (mid-zoom, at local frame 65), don't use this
 * helper — just pass `durationInFrames={65}` to your own `<Sequence>`.
 */
export function dashboardNavZoomDuration(
  schedule: DashboardNavZoomSchedule = {},
  itemCount: number = DEFAULT_SUBMENU_ITEMS.length,
): number {
  const beats = dashboardNavZoomBeats(schedule, itemCount);
  return Math.max(beats.zoomEnd, beats.itemsEnd, beats.pillEnd) + 1;
}

// ── Component ───────────────────────────────────────────────────────────────────────

export interface DashboardNavZoomProps {
  /** Wordmark, top-left of the header. Default "zoom". */
  brand?: string;
  /** Top-nav links, right of the wordmark. Default: the source's own four
   *  links. See `activeLinkIndex` for which one renders active. */
  navLinks?: string[];
  /** Index into `navLinks` that renders active (bold, brand-coloured).
   *  Default 2 — "Resources" in the default `navLinks`, matching the source. */
  activeLinkIndex?: number;
  /** Heading + rows above the divider. Default: the source's own seven rows
   *  under "PERSONAL". */
  personalSection?: { heading: string; items: string[] };
  /** Heading + single row below the divider, before the submenu. Default
   *  "ADMIN" / "Dashboard". */
  adminSection?: { heading: string; item: string };
  /** The row that owns the submenu below it — a checkmark glyph, a label, and
   *  an optional badge. Default "AI Studio" with a "NEW" badge; pass
   *  `badge: undefined` to drop the badge. */
  submenuHeading?: { label: string; badge?: string };
  /** Submenu rows; one of them is the pill's target. Default: the source's own
   *  six AI Studio rows. */
  submenuItems?: string[];
  /** Index into `submenuItems` the pill slides onto and highlights. Default 1
   *  ("Virtual Agents"), matching the source. */
  targetIndex?: number;
  /** Rendered in the empty main canvas, right of the sidebar. Default: nothing
   *  (a plain white area, matching the source). */
  rightPanel?: ReactNode;
  /** Brand colour — the wordmark, the active nav link, and the selection pill.
   *  Default "#0053f9", the source's own value. */
  brandColor?: string;
  /** Font for the wordmark. Default a system approximation — see the file
   *  header on why no font file ships with this component. */
  brandFontFamily?: string;
  /** Font for everything else. Defaults to a system stack. */
  fontFamily?: string;
  /** Timing overrides; see `DashboardNavZoomSchedule`. */
  schedule?: DashboardNavZoomSchedule;
  /** Merged onto the outer wrapper. */
  style?: CSSProperties;
}

/**
 * See the file header for the shot. Use `dashboardNavZoomDuration` for this
 * component's settled length rather than guessing a frame count — the camera
 * is still moving well past when the rows and pill have finished.
 */
export function DashboardNavZoom({
  brand = "zoom",
  navLinks = DEFAULT_NAV_LINKS,
  activeLinkIndex = 2,
  personalSection = DEFAULT_PERSONAL_SECTION,
  adminSection = DEFAULT_ADMIN_SECTION,
  submenuHeading = DEFAULT_SUBMENU_HEADING,
  submenuItems = DEFAULT_SUBMENU_ITEMS,
  targetIndex = 1,
  rightPanel,
  brandColor = DEFAULT_BRAND_COLOR,
  brandFontFamily = BRAND_FONT_STACK,
  fontFamily = UI_FONT_STACK,
  schedule = {},
  style,
}: DashboardNavZoomProps) {
  const frame = useCurrentFrame();
  const r = resolve(schedule);

  // ── Camera ──
  const zoomProgress = EASE_ZOOM(
    interpolate(frame, [r.zoomStart, r.zoomStart + r.zoomDurationInFrames], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }),
  );
  const scale = interpolate(zoomProgress, [0, 1], [1.0, 2.22]);
  const translateX = interpolate(zoomProgress, [0, 1], [260, -180]);
  const translateY = interpolate(zoomProgress, [0, 1], [0, -210]);

  // ── Selection pill ──
  // Starts off the top of the list and settles on targetIndex's own row.
  const pillProgress = EASE_PILL(
    interpolate(frame, [r.pillStart, r.pillStart + r.pillDurationInFrames], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }),
  );
  const pillTargetY = targetIndex * SUBMENU_ROW_PITCH;
  const pillY = interpolate(pillProgress, [0, 1], [PILL_START_Y, pillTargetY]);
  // Whichever row the pill currently sits over reads white; every other row
  // stays grey. A target more than one row down means the rows between it and
  // the top light up briefly as the pill passes them — the way a real
  // selection slide reads, not just a jump between two fixed states.
  const isRowSelected = (i: number) =>
    Math.abs(pillY - i * SUBMENU_ROW_PITCH) < SUBMENU_ROW_PITCH / 2;

  return (
    <AbsoluteFill style={{ overflow: "hidden", ...style }}>
      <AbsoluteFill
        style={{
          transform: `scale(${scale}) translate(${translateX}px, ${translateY}px)`,
          transformOrigin: "50% 50%",
          fontFamily,
        }}
      >
        {/* Dashboard panel */}
        <div
          style={{
            position: "absolute",
            left: 780,
            right: 0,
            top: 0,
            bottom: 0,
            background: "#ffffff",
            display: "flex",
            flexDirection: "column",
          }}
        >
          {/* Header */}
          <div
            style={{
              height: 72,
              display: "flex",
              alignItems: "center",
              padding: "0 40px",
              background: "#ffffff",
              borderBottom: "1px solid #f0f0f4",
            }}
          >
            <div
              style={{
                fontFamily: brandFontFamily,
                fontWeight: 700,
                fontSize: 32,
                color: brandColor,
                letterSpacing: "-0.03em",
                marginRight: 56,
              }}
            >
              {brand}
            </div>

            <div style={{ display: "flex", gap: 44, fontSize: 17, color: "#5b5977", fontWeight: 400 }}>
              {navLinks.map((link, i) => (
                <span
                  key={link}
                  style={
                    i === activeLinkIndex
                      ? { color: brandColor, fontWeight: 600 }
                      : undefined
                  }
                >
                  {link}
                </span>
              ))}
            </div>
          </div>

          {/* Body */}
          <div style={{ flex: 1, display: "flex", background: "#f6f6f9" }}>
            <div
              style={{
                width: 440,
                background: "#f6f6f9",
                padding: "24px 0",
                display: "flex",
                flexDirection: "column",
                gap: 4,
              }}
            >
              <div
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#8a8a93",
                  letterSpacing: "0.06em",
                  padding: "12px 32px 6px 32px",
                }}
              >
                {personalSection.heading}
              </div>

              {personalSection.items.map((item) => (
                <div
                  key={item}
                  style={{
                    height: 48,
                    display: "flex",
                    alignItems: "center",
                    paddingLeft: 60,
                    fontSize: 22,
                    color: "#3d3d52",
                    fontWeight: 500,
                  }}
                >
                  {item}
                </div>
              ))}

              <div
                style={{
                  fontSize: 16,
                  fontWeight: 700,
                  color: "#8a8a93",
                  letterSpacing: "0.06em",
                  padding: "24px 32px 6px 32px",
                }}
              >
                {adminSection.heading}
              </div>

              <div
                style={{
                  height: 48,
                  display: "flex",
                  alignItems: "center",
                  paddingLeft: 60,
                  fontSize: 22,
                  color: "#3d3d52",
                  fontWeight: 500,
                }}
              >
                {adminSection.item}
              </div>

              <div
                style={{
                  height: 50,
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  paddingLeft: 38,
                  fontSize: 22,
                  fontWeight: 600,
                  color: brandColor,
                }}
              >
                <svg width="16" height="16" viewBox="0 0 12 12" fill="none">
                  <path
                    d="M2.5 4.5 6 8l3.5-3.5"
                    stroke={brandColor}
                    strokeWidth="1.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
                <span>{submenuHeading.label}</span>
                {submenuHeading.badge != null && (
                  <span
                    style={{
                      fontSize: 12,
                      fontWeight: 700,
                      color: "#1e71c2",
                      border: "1px solid #9dc8f4",
                      background: "#ffffff",
                      borderRadius: 10,
                      padding: "3px 8px",
                      lineHeight: 1,
                    }}
                  >
                    {submenuHeading.badge}
                  </span>
                )}
              </div>

              <div
                style={{
                  position: "relative",
                  display: "flex",
                  flexDirection: "column",
                  gap: SUBMENU_ROW_GAP,
                  paddingLeft: 60,
                  marginTop: 6,
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    position: "absolute",
                    top: 0,
                    left: 60,
                    right: 28,
                    height: SUBMENU_ROW_HEIGHT,
                    borderRadius: 12,
                    background: brandColor,
                    boxShadow: `0 4px 18px ${brandColor}73`,
                    transform: `translateY(${pillY}px)`,
                    zIndex: 0,
                  }}
                />

                {submenuItems.map((label, i) => {
                  const itemStart = r.itemsStart + i * r.itemStagger;
                  const itemProgress = interpolate(
                    frame,
                    [itemStart, itemStart + r.itemDurationInFrames],
                    [0, 1],
                    { easing: EASE_ROW, extrapolateLeft: "clamp", extrapolateRight: "clamp" },
                  );
                  const itemY = interpolate(itemProgress, [0, 1], [-14, 0]);
                  const selected = isRowSelected(i);

                  return (
                    <div
                      key={label}
                      style={{
                        position: "relative",
                        height: SUBMENU_ROW_HEIGHT,
                        borderRadius: 12,
                        display: "flex",
                        alignItems: "center",
                        padding: "0 22px",
                        fontSize: 21,
                        opacity: itemProgress,
                        transform: `translateY(${itemY}px)`,
                        color: selected ? "#ffffff" : "#6c6c70",
                        fontWeight: selected ? 500 : 400,
                        zIndex: 1,
                      }}
                    >
                      <span>{label}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            <div style={{ flex: 1, background: "#ffffff", padding: 40 }}>{rightPanel}</div>
          </div>
        </div>
      </AbsoluteFill>
    </AbsoluteFill>
  );
}
