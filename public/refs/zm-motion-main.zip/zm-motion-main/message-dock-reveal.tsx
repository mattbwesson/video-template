/**
 * message-dock-reveal.tsx — a message sitting alone in the middle of the frame
 * docks into a chat sidebar while the app shell fades up around it and a deck
 * editor slides in from the right. Then a cursor flies in and clicks its way
 * down the slide thumbnails. One continuous move, then one deliberate gesture.
 *
 * THE MECHANIC. The dock rides a single eased progress value, which is what
 * makes it read as one gesture rather than three:
 *
 *   • The message morphs rather than travels. Font size, padding, corner radius,
 *     max-width, shadow and scale all interpolate together from "hero" to
 *     "chat bubble", so it never looks like a large thing shrinking — it looks
 *     like the same thing arriving somewhere smaller.
 *   • The column narrows from full width to sidebar width underneath it. The
 *     message is never re-parented or re-positioned; the container it already
 *     lives in simply becomes the sidebar.
 *   • The artifact slides in from the right, into the space the column gave up.
 *     It starts slightly behind the shell (15% in) and is multiplied by the
 *     shell's own opacity, so it can never lead the frame it sits inside.
 *   • The shell settles ahead of the layout — 60% of the way through — so the
 *     panels never ghost against a half-formed background.
 *
 * Thread items cascade in against the tail of that move rather than waiting for
 * it, which is what stops the sidebar feeling empty on arrival.
 *
 * WHAT'S IN THE BOX. This is a whole surface, not a layout with holes in it:
 * the left icon rail, the conversation column with its composer, and a full
 * deck editor — header, menus, toolbar, slide thumbnails, the big slide canvas,
 * the prompt bar and the status footer. Everything realistically variable is a
 * prop with the source shot's own content as its default, the same call
 * `dashboard-nav-zoom` and `zoommate-full` make: abstracting the chrome away
 * would leave nothing that reads as an app.
 *
 * ONE DATA MODEL, TWO RENDERINGS. A `MessageDockSlide` is drawn twice — once at
 * ~5px as a thumbnail and once at full size on the canvas — from the same
 * descriptor. Add a slide and both appear, in step, and the click schedule and
 * "Slide n / N" footer follow it. Bodies compose from four optional parts
 * (timeline, bars, cards, notes) rather than being bespoke per slide.
 *
 * THE CLICK. The cursor flies up from below the shell onto the first target,
 * pauses, presses, then drops to the next. Each click swaps the active slide —
 * thumbnail selection, canvas, corner label and footer all follow from one
 * index. The press dip carries a short ripple: the source sold its clicks with
 * a sound effect, which a component can't ship, so the affordance has to be
 * visible.
 *
 * Authored in a 1536x822 shell coordinate space and scaled to fit — see
 * `width`. To use it at another size, scale the whole component rather than the
 * numbers inside it.
 */
import type { CSSProperties, ReactNode } from "react";
import { Easing, interpolate, useCurrentFrame, useVideoConfig } from "remotion";
import { Cursor } from "./cursor";
import { framesFor } from "./lib";

/** The shell's own pixel dimensions; every layout number below is in these units. */
export const MESSAGE_DOCK_SHELL_WIDTH = 1536;
export const MESSAGE_DOCK_SHELL_HEIGHT = 822;

// ── Layout ──────────────────────────────────────────────────────────────────────────

/** Width of the left icon rail. */
const RAIL_WIDTH = 69;
/** The conversation column, full-bleed at the start and docked at the end. */
const COLUMN_WIDE = MESSAGE_DOCK_SHELL_WIDTH - RAIL_WIDTH;
const COLUMN_DOCKED = 388;
/**
 * Empty strip above the conversation. The source hid its header icons here once
 * the dock became concurrent with the fade-in (they would only have flashed),
 * but kept the space they occupied — the thread hangs off this offset, so
 * removing it would lift the whole column.
 */
const COLUMN_HEADER_HEIGHT = 60;

const DECK_HEADER_H = 64;
const DECK_MENU_ROW_H = 18;
const DECK_TOOL_ROW_H = 20;
/** Menus + tools, including the hairline under them. */
const DECK_TOOLBAR_H = 10 + DECK_MENU_ROW_H + 8 + DECK_TOOL_ROW_H + 8 + 1;
const DECK_CANVAS_PAD_X = 18;
const DECK_CANVAS_PAD_TOP = 14;

const THUMB_COLUMN_WIDTH = 150;
const THUMB_ROW_H = 68;
const THUMB_GAP = 12;
/** Centre-to-centre distance between adjacent thumbnails — the cursor's step. */
const THUMB_PITCH = THUMB_ROW_H + THUMB_GAP;
/** Top of the first thumbnail row, in shell coordinates. */
const THUMB_TOP = DECK_HEADER_H + DECK_TOOLBAR_H + DECK_CANVAS_PAD_TOP;

/** Where the cursor sits horizontally: over the thumbnail cards, not their numbers. */
const CURSOR_X = RAIL_WIDTH + COLUMN_DOCKED + DECK_CANVAS_PAD_X + 98;
/** The cursor starts below the shell and flies up into it. */
const CURSOR_START_Y = MESSAGE_DOCK_SHELL_HEIGHT + 100;

const UI_FONT_STACK =
  '-apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", "Public Sans", Roboto, Helvetica, Arial, sans-serif';

const INK = "#1c1c1a";
const INK_DIM = "#8a8a85";
const HAIRLINE = "#ece9e3";
const PAPER = "#f6f5f2";

// ── Curves ──────────────────────────────────────────────────────────────────────────

/** An anticipate-then-settle curve: it leans back slightly before committing,
 *  which is what sells the dock as deliberate rather than mechanical. */
const MOVE_EASE = Easing.bezier(0.81, -0.01, 0.35, 1);
const SHELL_EASE = Easing.bezier(0.4, 0, 0.2, 1);
/** Fast start, long settle — each thread item's own fade + rise. */
const RISE_EASE = Easing.bezier(0.16, 1, 0.3, 1);
/** The cursor's fly-in: quick off the mark, gliding into place. */
const CURSOR_FLY_EASE = Easing.bezier(0.19, 0.88, 0.24, 0.99);
/** Its shorter hop between adjacent thumbnails. */
const CURSOR_HOP_EASE = Easing.bezier(0.22, 1, 0.36, 1);

const MOVE_SECONDS = 0.7;

// ── Content model ───────────────────────────────────────────────────────────────────

export interface MessageDockSlideCard {
  /** Small tracked index above the title, e.g. "01" or a date. */
  index?: string;
  title: string;
  /** Supporting line under the title. */
  body?: string;
  /** Status line under a hairline, preceded by a dot. Omit for no footer row. */
  status?: string;
  /** Dot colour beside `status`. Defaults to the slide's accent. */
  statusColor?: string;
}

/** One line in a thumbnail's body. Derived from `cards` when not given. */
export interface MessageDockSlideNote {
  title: string;
  body?: string;
}

export interface MessageDockSlide {
  /** Tracked line above the title on the canvas, e.g. "ACME · Q2 REVIEW". */
  eyebrow?: string;
  /** Shorter eyebrow for the thumbnail. Rendered only on `dark` slides, where
   *  the source treated the thumbnail as a cover. */
  thumbEyebrow?: string;
  /** Top-right label on the canvas, e.g. "01 · COMMITTED". Fades in as the panel
   *  reaches full width rather than on selection. */
  cornerLabel?: string;
  title: string;
  /** Standfirst under the rule. */
  lede?: string;
  /** Rule, card indices, chart highlight and status dots. Default "#2a6df5". */
  accent?: string;
  /** Cover treatment: dark ground, white type. Default false. */
  dark?: boolean;
  /** Dots across a rule above the cards, as fractions 0–1. The last is accented. */
  timeline?: number[];
  /** Relative bar heights for a chart body. The tallest is accented. */
  bars?: number[];
  /** The card row — the dominant body layout. */
  cards?: MessageDockSlideCard[];
  /** Pills in the thumbnail body, e.g. ["SSO", "CSM", "50 seats"]. */
  chips?: string[];
  /** Thumbnail body lines. Defaults to the first three `cards` — which is how a
   *  card-bodied slide reads at thumbnail size. */
  thumbNotes?: MessageDockSlideNote[];
  /** Accent tick beside each thumbnail note. Defaults to true when the notes are
   *  derived from `cards`, false when you write them yourself. */
  thumbNoteTicks?: boolean;
}

export type MessageDockStepIcon = "edit" | "run" | "bullet" | "check";

export type MessageDockThreadItem =
  /** A tool or reasoning line: icon, optional bold label, text. */
  | { kind: "step"; icon?: MessageDockStepIcon; label?: string; text: string }
  /** The assistant's answer: intro, bulleted list, sources pill. */
  | {
      kind: "answer";
      intro?: string;
      bullets?: { label: string; text: string }[];
      sources?: string;
    }
  /** A follow-up user bubble, right-aligned like the docked message. */
  | { kind: "message"; text: string }
  /** Anything else. Rendered on the parent's timeline, in its own cascade slot. */
  | { kind: "custom"; node: ReactNode };

/** A cursor click: which slide it selects, and when. */
export interface MessageDockSlideClick {
  /** Absolute frame the press lands. */
  atFrame: number;
  /** Zero-based index into `slides`. */
  index: number;
}

// ── Defaults ────────────────────────────────────────────────────────────────────────

const DEFAULT_ACCENT = "#0B5CFF";

const DEFAULT_MESSAGE =
  "Build me a QBR deck that gets ahead of the tough questions and makes the case for expanding the pilot.";

const DEFAULT_THREAD: MessageDockThreadItem[] = [
  { kind: "step", icon: "edit", label: "Edit", text: "Reading the pilot results document." },
  { kind: "step", icon: "run", label: "Execute", text: "Pulling the headline metrics." },
  { kind: "step", icon: "bullet", text: "Four slides looks right for a 10-minute slot." },
  { kind: "step", icon: "check", text: "Building the deck outline and slide copy" },
  {
    kind: "answer",
    intro: "Done — here's your 4-slide QBR prep deck for ACME. It covers:",
    bullets: [
      { label: "Committed", text: "SSO by end of Q2, dedicated CSM, 50-seat Contact Center pilot" },
      { label: "What's shifted", text: "pilot slipped two weeks; security review moved to May 12" },
      { label: "Open items", text: "the API rate limits and the DPA, each with a close date" },
      { label: "The expansion story", text: "ticket volume outgrowing their setup" },
    ],
    sources: "Sources(2)",
  },
];

const EYEBROW = "ACME · Q2 QUARTERLY BUSINESS REVIEW";

const DEFAULT_SLIDES: MessageDockSlide[] = [
  {
    dark: true,
    accent: "#3f7fd6",
    eyebrow: EYEBROW,
    thumbEyebrow: "ACME · Q2 QBR",
    cornerLabel: "01 · COMMITTED",
    title: "What we committed to",
    lede: "Three commitments on the table from last quarter — all still in flight.",
    chips: ["SSO", "CSM", "50 seats"],
    cards: [
      { index: "01", title: "SSO rollout", body: "Complete by end of Q2", status: "On track", statusColor: "#5fbf8c" },
      { index: "02", title: "Dedicated CSM", body: "Named coverage on the account", status: "In place", statusColor: "#5fbf8c" },
      { index: "03", title: "Contact Center pilot", body: "50 seats across their support org", status: "Slipped two weeks", statusColor: "#e0a04a" },
    ],
  },
  {
    accent: "#e0872b",
    eyebrow: EYEBROW,
    cornerLabel: "02 · WHAT'S SHIFTED",
    title: "What's shifted",
    lede: "The pilot slipped two weeks — their IT team moved the security review to May 12.",
    timeline: [0.04, 0.5, 0.96],
    cards: [
      { index: "APR 18", title: "Flagged early", body: "You raised the timeline risk before it became one." },
      { index: "MAY 12", title: "Security review moved", body: "ACME's IT team pushed their review to accommodate their own audit." },
      { index: "TODAY", title: "They accepted the slip", body: "No pushback — the two-week delay is acknowledged and expected." },
    ],
    thumbNotes: [
      { title: "Pilot slips two weeks", body: "IT moved security review → May 12" },
      { title: "", body: "Flagged Apr 18 · they accepted" },
    ],
  },
  {
    accent: "#c2453f",
    eyebrow: EYEBROW,
    cornerLabel: "03 · OPEN ITEMS",
    title: "Open items & next steps",
    lede: "Two items you've raised — where each stands, and when it closes.",
    cards: [
      { index: "01", title: "API rate limits", body: "Moving your org to the higher-throughput tier at no additional cost.", status: "Written confirmation by May 20", statusColor: "#e0a04a" },
      { index: "02", title: "Updated DPA", body: "Revised agreement is in final review with our legal team.", status: "Delivered by May 15", statusColor: "#e0a04a" },
    ],
    // The cards' own bodies are a paragraph each; at 4px a thumbnail needs the
    // shorter form, which is what the source wrote by hand here.
    thumbNotes: [
      { title: "API rate limits", body: "Higher-throughput tier · confirmed May 20" },
      { title: "Updated DPA", body: "In legal review · delivered May 15" },
    ],
    thumbNoteTicks: true,
  },
  {
    accent: "#2a6df5",
    eyebrow: EYEBROW,
    cornerLabel: "04 · THE EXPANSION STORY",
    title: "The expansion story",
    lede: "Ticket volume is up in every call — growing faster than their current setup handles.",
    bars: [5, 7, 10, 12, 15],
    cards: [
      { index: "NOW", title: "Ticket volume up in every call", body: "Five straight quarters of growth across their support org." },
      { index: "NEXT", title: "Growing faster than their setup", body: "The 50-seat pilot is already the constraint, not the experiment." },
    ],
    thumbNotes: [
      { title: "Ticket volume up in every call", body: "Growing faster than their setup handles" },
    ],
  },
];

/** Menu labels in the deck editor's menu bar. */
const DECK_MENUS = ["Edit", "View", "Insert", "Format", "Slide", "Arrange", "Help"];

// ── Timing ──────────────────────────────────────────────────────────────────────────

export interface MessageDockRevealSchedule {
  /** Frame the move begins. Default 0. */
  startFrame?: number;
  /** Length of the move. Defaults to 0.7s at the composition's rate. */
  durationInFrames?: number;
  /**
   * Frame the first thread item appears. Defaults to 14 frames after the start —
   * deliberately *during* the move, so the sidebar is filling as it forms rather
   * than sitting empty until the layout finishes.
   */
  threadStartFrame?: number;
  /** Frames between thread items. Default 3. */
  threadStaggerFrames?: number;
  /** Frame the cursor starts flying in. Default 14 frames after the start. */
  cursorStartFrame?: number;
  /** Frames the fly-in from below the shell takes. Default 16. */
  cursorTravelFrames?: number;
  /** Frames the cursor waits after a click before hopping to the next target. Default 4. */
  cursorHoldFrames?: number;
  /** Frames each hop between adjacent thumbnails takes. Default 8. */
  cursorHopFrames?: number;
  /** Frame the cursor begins fading out. Defaults to 14 frames after the last click. */
  cursorExitFrame?: number;
}

export interface MessageDockRevealBeats {
  moveStart: number;
  moveEnd: number;
  /** The shell has finished fading up — ahead of the layout, by design. */
  shellSettled: number;
  /** The artifact starts fading and sliding in. */
  artifactIn: number;
  /** First and last thread item begin arriving. */
  threadStart: number;
  threadEnd: number;
  /** The cursor starts flying in, and the frame it has fully faded out. */
  cursorIn: number;
  cursorOut: number;
  /** Every click, in order — the frames the active slide changes. */
  clicks: number[];
}

const ITEM_FADE_FRAMES = 7;
const CURSOR_FADE_FRAMES = 6;
/** Frames either side of a press that the dip and its ripple occupy. */
const CLICK_DIP_FRAMES = 1.5;
const RIPPLE_FRAMES = 9;

function defaultClicks(startFrame: number, slideCount: number): MessageDockSlideClick[] {
  // The source clicked its second and third thumbnails 34 and 54 frames into the
  // move. Keep that spacing, and only for slides that exist.
  return [
    { atFrame: startFrame + 34, index: 1 },
    { atFrame: startFrame + 54, index: 2 },
  ].filter((c) => c.index < slideCount);
}

function resolve(
  schedule: MessageDockRevealSchedule,
  fps: number,
  itemCount: number,
  slideCount: number,
  clicksProp: MessageDockSlideClick[] | undefined,
) {
  const {
    startFrame = 0,
    durationInFrames = framesFor({ seconds: MOVE_SECONDS }, fps),
    threadStartFrame,
    threadStaggerFrames = 3,
    cursorStartFrame,
    cursorTravelFrames = 16,
    cursorHoldFrames = 4,
    cursorHopFrames = 8,
    cursorExitFrame,
  } = schedule;

  const threadStart = threadStartFrame ?? startFrame + 14;
  const clicks = [...(clicksProp ?? defaultClicks(startFrame, slideCount))].sort(
    (a, b) => a.atFrame - b.atFrame,
  );
  const cursorStart = cursorStartFrame ?? startFrame + 14;
  const lastClick = clicks.length > 0 ? clicks[clicks.length - 1].atFrame : cursorStart;

  return {
    startFrame,
    durationInFrames,
    threadStart,
    threadStaggerFrames,
    threadEnd:
      threadStart + Math.max(0, itemCount - 1) * threadStaggerFrames + ITEM_FADE_FRAMES,
    clicks,
    cursorStart,
    cursorTravelFrames,
    cursorHoldFrames,
    cursorHopFrames,
    cursorExit: cursorExitFrame ?? lastClick + 14,
  };
}

/**
 * Every beat as a frame number. Use it to schedule anything against the dock —
 * a camera push once `moveEnd` lands, a cut once the last click has registered.
 */
export function messageDockRevealBeats(
  schedule: MessageDockRevealSchedule = {},
  fps = 30,
  itemCount = DEFAULT_THREAD.length,
  slideCount = DEFAULT_SLIDES.length,
  slideClicks?: MessageDockSlideClick[],
): MessageDockRevealBeats {
  const r = resolve(schedule, fps, itemCount, slideCount, slideClicks);
  return {
    moveStart: r.startFrame,
    moveEnd: r.startFrame + r.durationInFrames,
    shellSettled: Math.round(r.startFrame + r.durationInFrames * 0.6),
    artifactIn: Math.round(r.startFrame + r.durationInFrames * 0.15),
    threadStart: r.threadStart,
    threadEnd: Math.ceil(r.threadEnd),
    cursorIn: r.cursorStart,
    cursorOut: r.cursorExit + CURSOR_FADE_FRAMES,
    clicks: r.clicks.map((c) => c.atFrame),
  };
}

/**
 * Total frames the shot occupies, ending once the cursor has left and the last
 * thread item has landed. Add your own hold to sit on the result.
 */
export function messageDockRevealDuration(
  schedule: MessageDockRevealSchedule = {},
  fps = 30,
  itemCount = DEFAULT_THREAD.length,
  slideCount = DEFAULT_SLIDES.length,
  slideClicks?: MessageDockSlideClick[],
): number {
  const b = messageDockRevealBeats(schedule, fps, itemCount, slideCount, slideClicks);
  return Math.max(b.moveEnd, b.threadEnd, b.cursorOut) + 1;
}

// ── Icons ───────────────────────────────────────────────────────────────────────────
// Inline rather than shared: this component is self-contained by design, and the
// set is small enough that a cross-module dependency would cost more than it saves.

const stroke = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2,
  strokeLinecap: "round",
  strokeLinejoin: "round",
} as const;

/** Top of each rail icon, in shell px — the source's own spacing, which tightens
 *  slightly after the first pair rather than running on an even pitch. */
const RAIL_ICON_TOPS = [12, 59, 96, 132, 168, 204];

const RAIL_ICONS: ReactNode[] = [
  <svg key="panel" width="18" height="18" viewBox="0 0 24 24" {...stroke}><rect width="18" height="18" x="3" y="3" rx="2" /><path d="M9 3v18" /></svg>,
  <svg key="plus" width="18" height="18" viewBox="0 0 24 24" {...stroke}><path d="M5 12h14" /><path d="M12 5v14" /></svg>,
  <svg key="flow" width="18" height="18" viewBox="0 0 24 24" {...stroke}><rect width="8" height="8" x="3" y="3" rx="2" /><path d="M7 11v4a2 2 0 0 0 2 2h4" /><rect width="8" height="8" x="13" y="13" rx="2" /></svg>,
  <svg key="docs" width="18" height="18" viewBox="0 0 24 24" {...stroke}><path d="M15 2h-4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V8" /><path d="M16.706 2.706A2.4 2.4 0 0 0 15 2v5a1 1 0 0 0 1 1h5a2.4 2.4 0 0 0-.706-1.706z" /><path d="M5 7a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h8a2 2 0 0 0 1.732-1" /></svg>,
  <svg key="search" width="18" height="18" viewBox="0 0 24 24" {...stroke}><path d="m21 21-4.34-4.34" /><circle cx="11" cy="11" r="8" /></svg>,
  <svg key="chat" width="18" height="18" viewBox="0 0 24 24" {...stroke}><path d="M8 12h8M8 8h5" /><path d="M21 15a2 2 0 0 1-2 2H8l-4 4V5a2 2 0 0 1 2-2h13a2 2 0 0 1 2 2z" /></svg>,
];

const RAIL_FOOTER_ICONS: ReactNode[] = [
  <svg key="puzzle" width="18" height="18" viewBox="0 0 24 24" {...stroke}><path d="M15.39 4.39a1 1 0 0 0 1.68-.474 2.5 2.5 0 1 1 3.014 3.015 1 1 0 0 0-.474 1.68l1.683 1.682a2.414 2.414 0 0 1 0 3.414L19.61 15.39a1 1 0 0 1-1.68-.474 2.5 2.5 0 1 0-3.014 3.015 1 1 0 0 1 .474 1.68l-1.683 1.682a2.414 2.414 0 0 1-3.414 0L8.61 19.61a1 1 0 0 0-1.68.474 2.5 2.5 0 1 1-3.014-3.015 1 1 0 0 0 .474-1.68l-1.683-1.682a2.414 2.414 0 0 1 0-3.414L4.39 8.61a1 1 0 0 1 1.68.474 2.5 2.5 0 1 0 3.014-3.015 1 1 0 0 1-.474-1.68l1.683-1.682a2.414 2.414 0 0 1 3.414 0z" /></svg>,
  <svg key="gear" width="18" height="18" viewBox="0 0 24 24" {...stroke}><path d="M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915" /><circle cx="12" cy="12" r="3" /></svg>,
];

function StepIcon({ name }: { name: MessageDockStepIcon }) {
  if (name === "bullet") {
    return <span style={{ width: 8, height: 8, borderRadius: "50%", background: INK, margin: "0 8px" }} />;
  }
  if (name === "check") {
    return (
      <span style={{ width: 20, height: 20, borderRadius: "50%", background: "#c8c7c2", display: "flex", alignItems: "center", justifyContent: "center" }}>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="3.2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 12l5 5L20 6" /></svg>
      </span>
    );
  }
  return (
    <span style={{ width: 24, height: 24, display: "flex", alignItems: "center", justifyContent: "center", color: "#a3a29d" }}>
      {name === "edit" ? (
        <svg width="16" height="16" viewBox="0 0 24 24" {...stroke}><path d="M12.659 22H18a2 2 0 0 0 2-2V8a2.4 2.4 0 0 0-.706-1.706l-3.588-3.588A2.4 2.4 0 0 0 14 2H6a2 2 0 0 0-2 2v9.34" /><path d="M14 2v5a1 1 0 0 0 1 1h5" /><path d="M10.378 12.622a1 1 0 0 1 3 3.003L8.36 20.637a2 2 0 0 1-.854.506l-2.867.837a.5.5 0 0 1-.62-.62l.836-2.869a2 2 0 0 1 .506-.853z" /></svg>
      ) : (
        <svg width="16" height="16" viewBox="0 0 24 24" {...stroke}><path d="m7 11 2-2-2-2" /><path d="M11 13h4" /><rect width="18" height="18" x="3" y="3" rx="2" ry="2" /></svg>
      )}
    </span>
  );
}

// ── Deck editor pieces ──────────────────────────────────────────────────────────────

function notesFor(slide: MessageDockSlide): { notes: MessageDockSlideNote[]; ticks: boolean } {
  if (slide.thumbNotes) {
    return { notes: slide.thumbNotes, ticks: slide.thumbNoteTicks ?? false };
  }
  const cards = slide.cards ?? [];
  return {
    notes: cards.slice(0, 3).map((c) => ({ title: c.title, body: c.body })),
    ticks: slide.thumbNoteTicks ?? true,
  };
}

/** One thumbnail: the same descriptor as the canvas, drawn at ~1/9 scale. */
function SlideThumb({ slide, active }: { slide: MessageDockSlide; active: boolean }) {
  const accent = slide.accent ?? "#2a6df5";
  const { notes, ticks } = notesFor(slide);
  const hasBody = Boolean(slide.chips || slide.bars || slide.timeline || notes.length > 0);
  return (
    <div
      style={{
        flex: 1,
        height: THUMB_ROW_H,
        borderRadius: 5,
        background: slide.dark ? "#0f2d4a" : "#fff",
        border: active
          ? "2px solid #2a6df5"
          : slide.dark
            ? "1px solid rgba(255,255,255,.18)"
            : "1px solid #e7e3db",
        padding: "8px 9px",
        overflow: "hidden",
        color: slide.dark ? "#fff" : undefined,
      }}
    >
      {slide.dark && slide.thumbEyebrow && (
        <div style={{ fontSize: 4.5, letterSpacing: ".14em", color: "#7ba0d4", fontWeight: 700 }}>
          {slide.thumbEyebrow}
        </div>
      )}
      <div
        style={{
          fontSize: slide.dark ? 9 : 8,
          fontWeight: 800,
          lineHeight: 1.1,
          marginTop: slide.dark && slide.thumbEyebrow ? 3 : 0,
          letterSpacing: "-.01em",
          color: slide.dark ? "#fff" : "#1f3a5c",
        }}
      >
        {slide.title}
      </div>
      <div
        style={{
          width: slide.dark ? 14 : 12,
          height: 1.5,
          background: accent,
          borderRadius: 1,
          margin: hasBody ? "4px 0 5px" : "4px 0 0",
        }}
      />

      {slide.timeline && (
        <div style={{ position: "relative", height: 3, marginBottom: 5 }}>
          <div style={{ position: "absolute", left: 0, right: 0, top: 1, height: 1, background: "#e6ebf2" }} />
          {slide.timeline.map((pos, i) => (
            <div
              key={i}
              style={{
                position: "absolute",
                left: `${pos * 100}%`,
                top: 0,
                width: 3,
                height: 3,
                borderRadius: "50%",
                background: i === slide.timeline!.length - 1 ? accent : "#c3ccd8",
                transform: "translateX(-50%)",
              }}
            />
          ))}
        </div>
      )}

      {slide.bars && (
        <div style={{ display: "flex", alignItems: "flex-end", gap: 2, height: 15 }}>
          {slide.bars.map((h, i) => (
            <div
              key={i}
              style={{
                flex: 1,
                height: (h / Math.max(...slide.bars!)) * 15,
                borderRadius: 1,
                background: h === Math.max(...slide.bars!) ? accent : "#c8d9f5",
              }}
            />
          ))}
        </div>
      )}

      {slide.chips && (
        <div style={{ display: "flex", gap: 3 }}>
          {slide.chips.map((t) => (
            <div
              key={t}
              style={{
                flex: 1,
                borderRadius: 2,
                background: slide.dark ? "rgba(255,255,255,.09)" : "#eef6f1",
                border: slide.dark ? "0.5px solid rgba(255,255,255,.16)" : "0.5px solid #d3e9dd",
                padding: "3px 2px",
                fontSize: 4,
                fontWeight: 700,
                color: slide.dark ? "#cfdff2" : accent,
                textAlign: "center",
              }}
            >
              {t}
            </div>
          ))}
        </div>
      )}

      {!slide.chips &&
        notes.map((n, i) => (
          <div key={i} style={{ display: "flex", gap: 3, marginBottom: 3, marginTop: slide.bars && i === 0 ? 4 : 0 }}>
            {ticks && <div style={{ width: 1.5, flex: "none", borderRadius: 1, background: accent }} />}
            <div>
              {n.title && (
                <div style={{ fontSize: 4.2, fontWeight: 700, color: "#42506a", lineHeight: 1.4 }}>{n.title}</div>
              )}
              {n.body && <div style={{ fontSize: 4, color: "#8a95a6", lineHeight: 1.4 }}>{n.body}</div>}
            </div>
          </div>
        ))}
    </div>
  );
}

/** The big canvas: the same descriptor at full size. */
function SlideCanvas({
  slide,
  index,
  total,
  cornerOpacity,
  footerLabel,
}: {
  slide: MessageDockSlide;
  index: number;
  total: number;
  cornerOpacity: number;
  footerLabel: string;
}) {
  const accent = slide.accent ?? "#2a6df5";
  const dark = slide.dark ?? false;
  return (
    <div
      style={{
        flex: 1,
        borderRadius: 6,
        background: dark ? "#0f2d4a" : "#fff",
        border: dark ? "none" : "1px solid #e7e3db",
        position: "relative",
        overflow: "hidden",
        padding: "48px 52px",
        minHeight: 0,
        display: "flex",
        flexDirection: "column",
        color: dark ? "#fff" : INK,
      }}
    >
      {dark && (
        <>
          <div style={{ position: "absolute", right: -70, top: -50, width: 300, height: 300, borderRadius: "50%", background: "radial-gradient(circle, #1c4674 0%, rgba(15,45,74,0) 70%)" }} />
          <div style={{ position: "absolute", right: 50, bottom: -100, width: 260, height: 260, borderRadius: "50%", background: "radial-gradient(circle, #16395f 0%, rgba(15,45,74,0) 70%)" }} />
        </>
      )}

      <div style={{ display: "flex", alignItems: "baseline", justifyContent: "space-between", gap: 24, position: "relative" }}>
        <div style={{ fontSize: 13, letterSpacing: ".22em", color: dark ? "#7ba0d4" : "#8a95a6", fontWeight: 700 }}>
          {slide.eyebrow}
        </div>
        {slide.cornerLabel && (
          <div style={{ fontSize: 11, letterSpacing: ".2em", color: dark ? "#4f688a" : "#a9b2bd", fontWeight: 700, whiteSpace: "nowrap", opacity: cornerOpacity }}>
            {slide.cornerLabel}
          </div>
        )}
      </div>

      <h1 style={{ fontSize: 44, lineHeight: 1.04, fontWeight: 800, color: dark ? "#fff" : "#1f3a5c", margin: "12px 0 0", letterSpacing: "-.025em", position: "relative" }}>
        {slide.title}
      </h1>
      {/* flex:none matters — this is a 4px child of a flex column, and a tall
          body (a chart plus cards) will otherwise shrink it to nothing. */}
      <div style={{ width: 52, height: 4, flex: "none", background: accent, margin: "16px 0", borderRadius: 2, position: "relative" }} />
      {slide.lede && (
        <div style={{ fontSize: 17, color: dark ? "#dbe4f1" : "#5f6b7d", fontWeight: 500, position: "relative", maxWidth: 620, lineHeight: 1.4 }}>
          {slide.lede}
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", marginTop: "auto", marginBottom: "auto", position: "relative" }}>
        {slide.timeline && (
          <div style={{ position: "relative", height: 4, margin: "0 40px 36px" }}>
            <div style={{ position: "absolute", left: 0, right: 0, top: 1, height: 2, background: dark ? "rgba(255,255,255,.16)" : "#e7e3db" }} />
            {slide.timeline.map((pos, i) => (
              <div
                key={i}
                style={{
                  position: "absolute",
                  left: `${pos * 100}%`,
                  top: -5,
                  width: 12,
                  height: 12,
                  borderRadius: "50%",
                  background: i === slide.timeline!.length - 1 ? accent : "#8a95a6",
                  transform: "translateX(-50%)",
                }}
              />
            ))}
          </div>
        )}

        {slide.bars && (
          <div
            style={{
              // inline-flex + alignSelf so the baseline hugs the bars rather than
              // running on to the edge of the slide.
              display: "inline-flex",
              alignSelf: "flex-start",
              alignItems: "flex-end",
              gap: 14,
              height: 108,
              flex: "none",
              marginBottom: 26,
              borderBottom: `1px solid ${dark ? "rgba(255,255,255,.16)" : "#e7e3db"}`,
              paddingBottom: 1,
            }}
          >
            {slide.bars.map((h, i) => (
              <div
                key={i}
                style={{
                  width: 56,
                  flex: "none",
                  height: `${(h / Math.max(...slide.bars!)) * 100}%`,
                  borderRadius: "4px 4px 0 0",
                  background: h === Math.max(...slide.bars!) ? accent : dark ? "rgba(255,255,255,.18)" : "#c8d9f5",
                }}
              />
            ))}
          </div>
        )}

        {slide.cards && (
          <div style={{ display: "flex", gap: 14 }}>
            {slide.cards.map((c, i) => (
              <div
                key={i}
                style={{
                  flex: 1,
                  background: dark ? "rgba(255,255,255,.06)" : PAPER,
                  border: dark ? "1px solid rgba(255,255,255,.13)" : `1px solid ${HAIRLINE}`,
                  borderRadius: 10,
                  padding: "18px 18px 16px",
                  display: "flex",
                  flexDirection: "column",
                }}
              >
                {c.index && (
                  <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: ".16em", color: dark ? "#6f9fe0" : accent }}>
                    {c.index}
                  </div>
                )}
                <div style={{ fontSize: 20, fontWeight: 700, color: dark ? "#fff" : "#1f3a5c", marginTop: 10, letterSpacing: "-.015em" }}>
                  {c.title}
                </div>
                {c.body && (
                  <div style={{ fontSize: 13.5, color: dark ? "#a8bdd8" : "#6b7686", marginTop: 7, lineHeight: 1.45 }}>
                    {c.body}
                  </div>
                )}
                {c.status && (
                  <>
                    <div style={{ height: 1, background: dark ? "rgba(255,255,255,.11)" : HAIRLINE, margin: "16px 0 12px" }} />
                    <div style={{ display: "flex", alignItems: "center", gap: 7, fontSize: 12, color: dark ? "#c3d3e8" : "#5f6b7d", fontWeight: 500 }}>
                      <span style={{ width: 6, height: 6, borderRadius: "50%", background: c.statusColor ?? accent, flex: "none" }} />
                      {c.status}
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ paddingTop: 20, display: "flex", justifyContent: "space-between", fontSize: 11, color: dark ? "#5d7596" : "#a3a29d", position: "relative" }}>
        <span>{footerLabel}</span>
        <span>{`${index + 1}/${total}`}</span>
      </div>
    </div>
  );
}

// ── Component ───────────────────────────────────────────────────────────────────────

export interface MessageDockRevealProps {
  /** The message that starts centred and docks into the sidebar. Default: the
   *  source's QBR prompt. */
  message?: ReactNode;
  /**
   * Blocks that cascade into the sidebar under the docked message: the steps the
   * assistant takes, its answer, a follow-up. Each fades and rises on its own
   * slot. Defaults to the source's five-item thread.
   */
  thread?: MessageDockThreadItem[];
  /**
   * The deck. Each entry renders twice — once as a thumbnail, once on the canvas
   * when it is the active slide. Defaults to the source's four slides.
   */
  slides?: MessageDockSlide[];
  /** Zero-based slide selected before the first click. Default 0. */
  initialSlide?: number;
  /**
   * Cursor clicks, each selecting a slide. Defaults to two clicks — the second
   * and third thumbnails, 34 and 54 frames into the move, the source's own
   * spacing. Pass `[]` for a still deck (the cursor is then not mounted at all).
   */
  slideClicks?: MessageDockSlideClick[];
  /** Show the left icon rail. Default true. */
  showRail?: boolean;
  /** Replaces the built-in rail's contents. */
  rail?: ReactNode;
  /** Show the composer at the foot of the conversation. Default true. */
  showComposer?: boolean;
  /** Composer placeholder. Default "Reply to the assistant". */
  composerPlaceholder?: string;
  /** Small print under the composer. Default "AI can make mistakes. Review for accuracy." */
  composerNote?: string;
  /** Title in the deck editor's header. Default "ACME — Q2 QBR Prep". */
  artifactTitle?: string;
  /** Glyph left of that title. Defaults to a neutral deck mark. */
  artifactIcon?: ReactNode;
  /** Placeholder in the prompt bar under the slide. Default "Open on the three
   *  commitments, then the slip". */
  promptPlaceholder?: string;
  /** Bottom-left of every slide. Default "© 2026 Acme, Inc." */
  slideFooterLabel?: string;
  /**
   * Replaces the whole deck editor — a doc, a sheet, a chart. The slide, cursor
   * and footer props are then unused.
   */
  artifact?: ReactNode;
  /** Replaces the deck editor's header strip. */
  artifactHeader?: ReactNode;
  /** Accent for the send button, sources pill and rail highlight. Default "#0B5CFF". */
  accent?: string;
  /**
   * Shell width in composition px; height follows the 1536:822 ratio. Defaults
   * to 80% of the composition width — the source's framing, which leaves the
   * drop shadow room to fall.
   */
  width?: number;
  schedule?: MessageDockRevealSchedule;
  style?: CSSProperties;
}

export function MessageDockReveal({
  message = DEFAULT_MESSAGE,
  thread = DEFAULT_THREAD,
  slides = DEFAULT_SLIDES,
  initialSlide = 0,
  slideClicks,
  showRail = true,
  rail,
  showComposer = true,
  composerPlaceholder = "Reply to the assistant",
  composerNote = "AI can make mistakes. Review for accuracy.",
  artifactTitle = "ACME — Q2 QBR Prep",
  artifactIcon,
  promptPlaceholder = "Open on the three commitments, then the slip",
  slideFooterLabel = "© 2026 Acme, Inc.",
  artifact,
  artifactHeader,
  accent = DEFAULT_ACCENT,
  width,
  schedule = {},
  style,
}: MessageDockRevealProps) {
  const frame = useCurrentFrame();
  const { fps, width: compositionWidth, height: compositionHeight } = useVideoConfig();
  const r = resolve(schedule, fps, thread.length, slides.length, slideClicks);

  const aspect = MESSAGE_DOCK_SHELL_WIDTH / MESSAGE_DOCK_SHELL_HEIGHT;
  const renderedWidth =
    width ?? Math.min(compositionWidth * 0.8, compositionHeight * 0.92 * aspect);
  const scale = renderedWidth / MESSAGE_DOCK_SHELL_WIDTH;
  const renderedHeight = renderedWidth / aspect;

  // The one value everything in the dock rides.
  const move = interpolate(
    frame,
    [r.startFrame, r.startFrame + r.durationInFrames],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: MOVE_EASE },
  );

  // Settles ahead of the layout so the panels never ghost against a half-formed
  // background.
  const shellOpacity = interpolate(
    frame,
    [r.startFrame, r.startFrame + r.durationInFrames * 0.6],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: SHELL_EASE },
  );

  const columnWidth = interpolate(move, [0, 1], [COLUMN_WIDE, COLUMN_DOCKED]);
  const columnPadding = interpolate(move, [0, 1], [34, 18]);
  const columnMaxWidth = interpolate(move, [0, 1], [640, 350]);

  // Multiplied by the shell's own opacity so the artifact can never lead the
  // frame it sits inside.
  const artifactOpacity =
    interpolate(move, [0.15, 1], [0, 1], {
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    }) * shellOpacity;
  const artifactX = interpolate(move, [0.1, 1], [46, 0], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });
  // Tied to the panel reaching full width, not to which slide is active.
  const cornerOpacity = interpolate(move, [0.8, 1], [0, 1], {
    extrapolateLeft: "clamp",
    extrapolateRight: "clamp",
  });

  // The message morphs rather than travels: every property moves together, so it
  // reads as the same object arriving somewhere smaller.
  const bubble = {
    fontSize: interpolate(move, [0, 1], [32, 14]),
    padY: interpolate(move, [0, 1], [22, 14]),
    padX: interpolate(move, [0, 1], [36, 18]),
    radius: interpolate(move, [0, 1], [26, 16]),
    maxWidth: interpolate(move, [0, 1], [920, 440]),
    offsetY: interpolate(move, [0, 1], [281, 0]),
    offsetX: interpolate(move, [0, 1], [5, 0]),
    shadowBlur: interpolate(move, [0, 1], [30, 0]),
    shadowAlpha: interpolate(move, [0, 1], [0.05, 0]),
    // Scaled uniformly rather than by doubling font and padding, so wrapping,
    // radius and shadow all stay proportional through the move.
    scale: interpolate(move, [0, 1], [2, 1]),
  };

  // ── Cursor and slide selection ──
  // One index drives the thumbnail borders, the canvas, the corner label and the
  // footer count: the last click at or before this frame.
  let activeSlide = initialSlide;
  for (const c of r.clicks) {
    if (frame >= c.atFrame) activeSlide = c.index;
  }
  activeSlide = Math.min(Math.max(activeSlide, 0), Math.max(0, slides.length - 1));

  const thumbCentreY = (i: number) => THUMB_TOP + THUMB_ROW_H / 2 + i * THUMB_PITCH;

  // Fly up from below the shell onto the first target, then hop between targets:
  // each hop leaves `cursorHoldFrames` after the click it just made.
  let cursorY = CURSOR_START_Y;
  if (r.clicks.length > 0) {
    const flyIn = CURSOR_FLY_EASE(
      interpolate(frame, [r.cursorStart, r.cursorStart + r.cursorTravelFrames], [0, 1], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      }),
    );
    cursorY = CURSOR_START_Y + (thumbCentreY(r.clicks[0].index) - CURSOR_START_Y) * flyIn;
    for (let i = 1; i < r.clicks.length; i++) {
      const hopStart = r.clicks[i - 1].atFrame + r.cursorHoldFrames;
      const hop = CURSOR_HOP_EASE(
        interpolate(frame, [hopStart, hopStart + r.cursorHopFrames], [0, 1], {
          extrapolateLeft: "clamp",
          extrapolateRight: "clamp",
        }),
      );
      cursorY += (thumbCentreY(r.clicks[i].index) - thumbCentreY(r.clicks[i - 1].index)) * hop;
    }
  }

  // The press dip and its ripple: whichever click is nearest, if any is close.
  let press = 1;
  let rippleOpacity = 0;
  let rippleScale = 0;
  for (const c of r.clicks) {
    press = Math.min(
      press,
      interpolate(
        frame,
        [c.atFrame - CLICK_DIP_FRAMES, c.atFrame, c.atFrame + CLICK_DIP_FRAMES],
        [1, 0.4, 1],
        { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
      ),
    );
    if (frame >= c.atFrame && frame <= c.atFrame + RIPPLE_FRAMES) {
      const t = (frame - c.atFrame) / RIPPLE_FRAMES;
      rippleOpacity = Math.max(rippleOpacity, 0.28 * (1 - t));
      rippleScale = Math.max(rippleScale, 0.25 + 0.75 * t);
    }
  }

  const cursorOpacity =
    Math.min(
      interpolate(frame, [r.cursorStart, r.cursorStart + 8], [0, 1], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      }),
      interpolate(frame, [r.cursorExit, r.cursorExit + CURSOR_FADE_FRAMES], [1, 0], {
        extrapolateLeft: "clamp",
        extrapolateRight: "clamp",
      }),
    ) * shellOpacity;

  // Mounted only from the frame each thing first shows: in Remotion an invisible
  // element still costs a full render.
  const artifactMounted = frame >= r.startFrame;
  const cursorMounted =
    !artifact && r.clicks.length > 0 && frame >= r.cursorStart && frame < r.cursorExit + CURSOR_FADE_FRAMES;

  const railContent = rail ?? (
    <>
      {RAIL_ICONS.map((icon, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: 18,
            top: RAIL_ICON_TOPS[i] ?? 12 + i * 36,
            width: 32,
            height: 32,
            borderRadius: 8,
            background: i === 1 ? "#EBEBEB" : undefined,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: i === RAIL_ICONS.length - 1 ? accent : "#1A1A1A",
          }}
        >
          {icon}
        </div>
      ))}
      {RAIL_FOOTER_ICONS.map((icon, i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: 18,
            bottom: i === 0 ? 52 : 16,
            width: 32,
            height: 32,
            borderRadius: 8,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            color: "#1A1A1A",
          }}
        >
          {icon}
        </div>
      ))}
    </>
  );

  return (
    <div
      style={{
        position: "absolute",
        left: `calc(50% - ${renderedWidth / 2}px)`,
        top: `calc(50% - ${renderedHeight / 2}px)`,
        width: MESSAGE_DOCK_SHELL_WIDTH,
        height: MESSAGE_DOCK_SHELL_HEIGHT,
        transform: `scale(${scale})`,
        transformOrigin: "top left",
        background: `rgba(255,255,255,${shellOpacity})`,
        borderRadius: 14,
        overflow: "hidden",
        border: `1px solid rgba(235,235,235,${shellOpacity})`,
        boxShadow: `0 30px 90px rgba(0,0,0,${0.22 * shellOpacity}), 0 4px 16px rgba(0,0,0,${0.06 * shellOpacity})`,
        display: "flex",
        fontFamily: UI_FONT_STACK,
        color: INK,
        ...style,
      }}
    >
      {showRail && (
        <div
          style={{
            width: RAIL_WIDTH,
            flex: "none",
            position: "relative",
            height: "100%",
            zIndex: 10,
            background: `rgba(255,255,255,${shellOpacity})`,
            borderRight: `1px solid rgba(235,235,235,${shellOpacity})`,
            opacity: shellOpacity,
          }}
        >
          {railContent}
        </div>
      )}

      {/* The conversation column. It does not move — it narrows, and the message
          inside it is carried along rather than re-positioned. */}
      <div
        style={{
          width: columnWidth,
          flex: "none",
          minWidth: 0,
          display: "flex",
          flexDirection: "column",
          position: "relative",
          borderRight: move > 0.05 ? `1px solid rgba(236,233,227,${move})` : "none",
          overflow: "hidden",
        }}
      >
        {/* Space the source's header icons used to occupy — see COLUMN_HEADER_HEIGHT. */}
        <div style={{ height: COLUMN_HEADER_HEIGHT, flex: "none" }} />

        <div
          style={{
            flex: 1,
            minHeight: 0,
            overflow: "hidden",
            padding: `0 ${columnPadding}px`,
          }}
        >
          <div
            style={{
              maxWidth: columnMaxWidth,
              margin: "0 auto",
              width: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                transform: `translate(${bubble.offsetX}px, ${bubble.offsetY}px)`,
              }}
            >
              <div
                style={{
                  background: move < 1 ? "#eef1fb" : "#dbe3f4",
                  borderRadius: bubble.radius,
                  padding: `${bubble.padY}px ${bubble.padX}px`,
                  fontSize: bubble.fontSize,
                  lineHeight: 1.42,
                  color: "#23241f",
                  maxWidth: bubble.maxWidth,
                  boxShadow:
                    bubble.shadowBlur > 0
                      ? `0 8px ${bubble.shadowBlur}px rgba(0,0,0,${bubble.shadowAlpha})`
                      : "none",
                  letterSpacing: move < 0.5 ? "-0.3px" : "normal",
                  fontWeight: 500,
                  transform: `scale(${bubble.scale})`,
                  transformOrigin: "center",
                }}
              >
                {message}
              </div>
            </div>

            {thread.map((item, i) => {
              const start = r.threadStart + i * r.threadStaggerFrames;
              // Mounted only from its own slot: an invisible element still costs
              // a full render in Remotion, and a long thread would pay for every
              // item on every frame before any of them appear.
              if (frame < start) return null;
              const p = interpolate(frame, [start, start + ITEM_FADE_FRAMES], [0, 1], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
              });
              const y = interpolate(frame, [start, start + ITEM_FADE_FRAMES], [14, 0], {
                extrapolateLeft: "clamp",
                extrapolateRight: "clamp",
                easing: RISE_EASE,
              });
              // Consecutive steps sit tighter than the blocks around them, which
              // is what makes them read as one list rather than four paragraphs.
              const prev = i > 0 ? thread[i - 1] : undefined;
              const marginTop =
                i === 0 ? 18 : item.kind === "step" && prev?.kind === "step" ? 14 : 18;
              return (
                <div key={i} style={{ opacity: p, transform: `translateY(${y}px)`, marginTop }}>
                  <ThreadItem item={item} accent={accent} />
                </div>
              );
            })}
          </div>
        </div>

        {showComposer && (
          <div style={{ flex: "none", padding: `0 ${columnPadding}px 14px`, opacity: shellOpacity }}>
            <div style={{ maxWidth: columnMaxWidth, margin: "0 auto", width: "100%" }}>
              <div
                style={{
                  height: 46,
                  border: `1px solid ${HAIRLINE}`,
                  borderRadius: 14,
                  background: "#fff",
                  boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "0 8px 0 12px",
                }}
              >
                <div style={{ width: 26, height: 26, flex: "none", display: "flex", alignItems: "center", justifyContent: "center", color: "#5F5F5F" }}>
                  <svg width="17" height="17" viewBox="0 0 24 24" {...stroke}><path d="M5 12h14" /><path d="M12 5v14" /></svg>
                </div>
                <div style={{ flex: 1, minWidth: 0, fontSize: 14, color: "#9a9994", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>
                  {composerPlaceholder}
                </div>
                <div
                  style={{
                    width: 30,
                    height: 30,
                    flex: "none",
                    borderRadius: 9999,
                    background: "radial-gradient(circle at 20% 80%,#528fff 20%,#76b5ffe0,#99daffc2 90%)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#fff",
                  }}
                >
                  <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><path d="m5 12 7-7 7 7" /><path d="M12 19V5" /></svg>
                </div>
              </div>
              {composerNote && (
                <div style={{ marginTop: 7, textAlign: "center", fontSize: 11, color: "#a3a29d" }}>
                  {composerNote}
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* The artifact, sliding into the space the column gave up. */}
      {artifactMounted && (
        <div
          style={{
            flex: 1,
            minWidth: 0,
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            background: "#fff",
            opacity: artifactOpacity,
            transform: `translateX(${artifactX}px)`,
          }}
        >
          {(artifactHeader || !artifact) && (
            <div
              style={{
                height: DECK_HEADER_H,
                flex: "none",
                display: "flex",
                alignItems: "center",
                padding: "0 24px",
                gap: 12,
                borderBottom: `1px solid ${HAIRLINE}`,
              }}
            >
              {artifactHeader ?? (
                <>
                  <div style={{ width: 28, height: 28, flex: "none", display: "flex", alignItems: "center", justifyContent: "center" }}>
                    {artifactIcon ?? (
                      <svg width="22" height="22" viewBox="0 0 18 18" fill="none">
                        <rect x="1.3" y="1.3" width="15.4" height="15.4" rx="3.2" fill={accent} />
                        <rect x="4.5" y="5.2" width="9" height="5.6" rx="1" fill="#fff" />
                        <rect x="6.6" y="12" width="4.8" height="1.2" rx="0.6" fill="#fff" opacity="0.7" />
                      </svg>
                    )}
                  </div>
                  <div style={{ fontSize: 19, fontWeight: 600, color: INK }}>{artifactTitle}</div>
                  <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 18, color: "#5f5e59" }}>
                    <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><path d="M15 3h6v6" /><path d="M10 14 21 3" /><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" /></svg>
                    <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><path d="M12 15V3" /><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /><path d="m7 10 5 5 5-5" /></svg>
                    <svg width="20" height="20" viewBox="0 0 24 24" {...stroke}><path d="M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z" /></svg>
                  </div>
                </>
              )}
            </div>
          )}

          {artifact ?? (
            <>
              {/* Menus + toolbar */}
              <div style={{ padding: "10px 18px 8px", borderBottom: `1px solid ${HAIRLINE}` }}>
                <div style={{ display: "flex", gap: 28, fontSize: 15, color: "#3c3c39", height: DECK_MENU_ROW_H, alignItems: "center", paddingBottom: 8, boxSizing: "content-box" }}>
                  {DECK_MENUS.map((m) => (
                    <span key={m}>{m}</span>
                  ))}
                </div>
                <div style={{ display: "flex", alignItems: "center", gap: 16, color: "#4a4945", height: DECK_TOOL_ROW_H }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 14, color: "#3c3c39" }}>
                    <svg width="15" height="15" fill="none" viewBox="0 0 16 16">
                      <path stroke="currentColor" strokeLinecap="round" strokeWidth="1.25" d="M7.625 12.625h-4a2 2 0 0 1-2-2v-6a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v3" />
                      <circle cx="12" cy="11" r="4" fill={accent} />
                      <path stroke="#fff" strokeLinecap="round" d="M10 11h4m-2-2v4" />
                    </svg>
                    New slide
                  </div>
                  <div style={{ width: 1, height: 18, background: HAIRLINE }} />
                  <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" d="M4.636 8.854 1.6 5.777 4.636 2.7M1.6 5.777h9.038a3.761 3.761 0 1 1 0 7.523H8" /></svg>
                  <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><path stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.25" d="M11.364 8.354 14.4 5.277 11.364 2.2M14.4 5.277H5.36a3.762 3.762 0 0 0 0 7.523H8" /></svg>
                  <div style={{ width: 1, height: 18, background: HAIRLINE }} />
                  <svg width="16" height="16" fill="none" viewBox="0 0 16 16"><rect width="12.8" height="12.8" x="1.6" y="1.6" stroke="currentColor" strokeWidth="1.2" rx="1.4" /><path stroke="currentColor" strokeLinecap="round" strokeWidth="1.2" d="M5.113 6.196V5.31c0-.058.047-.105.105-.105h5.564c.058 0 .105.047.105.105v.886M8 5.205v5.25m-1.312.262h2.624" /></svg>
                </div>
              </div>

              {/* Canvas: thumbnails + the active slide */}
              <div style={{ flex: 1, display: "flex", minHeight: 0, padding: `${DECK_CANVAS_PAD_TOP}px ${DECK_CANVAS_PAD_X}px 0`, gap: 14 }}>
                <div style={{ width: THUMB_COLUMN_WIDTH, flex: "none", overflow: "hidden", display: "flex", flexDirection: "column", gap: THUMB_GAP }}>
                  {slides.map((s, i) => (
                    <div key={i} style={{ display: "flex", alignItems: "center", gap: 7, height: THUMB_ROW_H, flex: "none" }}>
                      <span style={{ fontSize: 12, color: "#a3a29d", width: 12, textAlign: "right" }}>{i + 1}</span>
                      <SlideThumb slide={s} active={i === activeSlide} />
                    </div>
                  ))}
                </div>

                <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
                  {slides.length > 0 && (
                    <SlideCanvas
                      slide={slides[activeSlide]}
                      index={activeSlide}
                      total={slides.length}
                      cornerOpacity={cornerOpacity}
                      footerLabel={slideFooterLabel}
                    />
                  )}

                  {/* Prompt bar */}
                  <div style={{ flex: "none", margin: "12px 0 0", border: `1px solid ${HAIRLINE}`, borderRadius: 11, height: 48, display: "flex", alignItems: "center", padding: "0 8px 0 16px", gap: 12 }}>
                    <div style={{ flex: 1, fontSize: 14, color: "#9a9994", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>
                      {promptPlaceholder}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 14, color: "#3c3c39" }}>
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><line x1="4" y1="7" x2="14" y2="7" /><line x1="4" y1="12" x2="11" y2="12" /><line x1="4" y1="17" x2="14" y2="17" /><path d="M17 6l2.5 2.5L17 11" /></svg>
                      Generate
                    </div>
                    <div style={{ width: 22, height: 22, borderRadius: "50%", background: "radial-gradient(circle at 35% 30%,#9a8bff,#5b4be0)" }} />
                    <div style={{ width: 28, height: 28, borderRadius: 7, display: "flex", alignItems: "center", justifyContent: "center", color: "#3c3c39" }}>
                      <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M8 5l11 7-11 7z" /></svg>
                    </div>
                  </div>
                </div>
              </div>

              {/* Status footer */}
              <div style={{ flex: "none", height: 42, display: "flex", alignItems: "center", padding: "0 20px", gap: 14, fontSize: 13, color: "#5f5e59", borderTop: `1px solid ${HAIRLINE}`, marginTop: 10 }}>
                <span style={{ color: "#3c3c39" }}>
                  Slide {activeSlide + 1} / {slides.length}
                </span>
                <span style={{ marginLeft: "auto", color: "#3c3c39" }}>Trash</span>
                <span style={{ marginLeft: 14 }}>57%</span>
              </div>
            </>
          )}
        </div>
      )}

      {cursorMounted && (
        <div style={{ position: "absolute", inset: 0, zIndex: 100, opacity: cursorOpacity, pointerEvents: "none" }}>
          <Cursor
            // The arrow occupies ~0.9 of its box, so 44 lands the pointer at the
            // ~38px the source drew it at inside this 1536px shell.
            size={44}
            rippleColor={accent}
            style={{ x: CURSOR_X, y: cursorY, scale: 1, pressScale: press, rippleOpacity, rippleScale }}
          />
        </div>
      )}
    </div>
  );
}

// ── Thread items ────────────────────────────────────────────────────────────────────

function ThreadItem({ item, accent }: { item: MessageDockThreadItem; accent: string }) {
  if (item.kind === "custom") return <>{item.node}</>;

  if (item.kind === "message") {
    return (
      <div style={{ display: "flex", justifyContent: "flex-end" }}>
        <div style={{ background: "#dbe3f4", borderRadius: 16, padding: "14px 18px", fontSize: 14, lineHeight: 1.42, color: "#23241f", maxWidth: 440, fontWeight: 500 }}>
          {item.text}
        </div>
      </div>
    );
  }

  if (item.kind === "step") {
    const icon = item.icon ?? "bullet";
    return (
      <div style={{ display: "flex", alignItems: "center", gap: 12, fontSize: 14, color: icon === "bullet" ? INK : INK_DIM }}>
        <StepIcon name={icon} />
        <span>
          {item.label && <strong style={{ color: INK, fontWeight: 600 }}>{item.label} </strong>}
          {item.text}
        </span>
      </div>
    );
  }

  return (
    <div style={{ fontSize: 14, lineHeight: 1.5, color: INK }}>
      {item.intro && <p style={{ margin: "4px 0 8px" }}>{item.intro}</p>}
      {item.bullets && item.bullets.length > 0 && (
        <ul style={{ margin: "6px 0 10px", paddingLeft: 18, display: "flex", flexDirection: "column", gap: 4 }}>
          {item.bullets.map((b, i) => (
            <li key={i}>
              <strong>{b.label}</strong> — {b.text}
            </li>
          ))}
        </ul>
      )}
      {item.sources && (
        <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "5px 12px 5px 8px", borderRadius: 9999, background: PAPER, fontSize: 13, color: "#5f5e5a" }}>
          <span style={{ display: "flex" }}>
            <span style={{ width: 20, height: 20, borderRadius: "50%", background: accent, border: "2px solid #fff", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width="10" height="10" viewBox="0 0 16 16" fill="none" stroke="#fff" strokeWidth="1.6" strokeLinecap="round"><path d="M4 4h6M4 8h8M4 12h5" /></svg>
            </span>
            <span style={{ width: 20, height: 20, borderRadius: "50%", background: accent, border: "2px solid #fff", display: "flex", alignItems: "center", justifyContent: "center", marginLeft: -6 }}>
              <svg width="10" height="10" viewBox="0 0 16 16" fill="#fff"><path d="M1.6 4.4A1.8 1.8 0 0 1 3.4 2.6h4.8a1.8 1.8 0 0 1 1.8 1.8v7.2a1.8 1.8 0 0 1-1.8 1.8H3.4a1.8 1.8 0 0 1-1.8-1.8z" /><path d="M11 6.6 14.4 4.5v7l-3.4-2.1z" /></svg>
            </span>
          </span>
          <span>{item.sources}</span>
          <svg width="12" height="12" viewBox="0 0 24 24" {...stroke}><path d="M9 6l6 6-6 6" /></svg>
        </div>
      )}
    </div>
  );
}
