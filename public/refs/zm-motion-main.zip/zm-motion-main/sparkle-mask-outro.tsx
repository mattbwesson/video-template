/**
 * sparkle-mask-outro.tsx — scene outro: the outgoing scene is masked by a four-point
 * sparkle silhouette that contracts from full-frame down to icon size, revealing a
 * backdrop around it; a 3D diamond sparkle crossfades in over the silhouette as it
 * settles, then plays an 18-frame flip and rests facing the camera.
 *
 * THE MECHANIC, beat by beat (offsets from `holdBefore`, at the default 24-frame shrink):
 *   •  0→24  the SVG sparkle mask scales down from covering the frame to rest size, on
 *            bezier(0.16, 1, 0.3, 1) — the scene appears to collapse into the sparkle.
 *   •  6→15  a flat white sparkle silhouette fades in behind the masked scene.
 *   • 10→25  the 3D sparkle sprite (frozen on its resting pose, source frame 18)
 *            crossfades in over the silhouette.
 *   • 17→27  as the sprite passes half opacity, everything beneath it — the masked
 *            scene and the silhouette — dissolves, so the handoff to the sprite is
 *            continuous. The sprite's soft edges never quite cover the silhouette's
 *            hard ones, so cutting these layers instead of fading them reads as a
 *            white halo popping out of existence.
 *   •    27  the mask and the outgoing scene are UNMOUNTED at zero opacity — from
 *            here it is only the backdrop and the sprite.
 *   • 28→46  the sprite plays its flip, source frames 18 → 0 at one per frame, and
 *            rests on frame 0 (a mirror resting pose). Add `holdAfter` to sit on it.
 *
 * The sprite is a 28-frame PNG sequence in ./sparkle-frames, shipped with the library
 * and resolved via `new URL(..., import.meta.url)` — both Remotion's webpack and Vite
 * emit the files automatically, so consumers need no public/ copying step.
 *
 * Layering a logo lockup (or any finale) after the flip: mount your own layer at
 * `sparkleMaskOutroBeats(...).flipEnd` — the sparkle rests at (centerX, centerY) at
 * `sparkleSize`, so a swap-in aligns with it there.
 *
 * The `outgoing` children are NOT rebased (see AGENTS.md): they render on this
 * component's own timeline. Wrap the whole component in a `<Sequence>` to place the
 * outro inside a larger composition.
 */
import { useId } from "react";
import type { CSSProperties, ReactNode, SVGProps } from "react";
import {
  AbsoluteFill,
  Easing,
  Img,
  interpolate,
  useCurrentFrame,
  useVideoConfig,
} from "remotion";
import { ShaderMeshGradient } from "./shader-mesh-gradient";

// ── Sparkle vector geometry ─────────────────────────────────────────────────────────
// The two paths of the four-point sparkle (large star + small companion twinkle),
// shared by the icon and the contracting mask so they overlay exactly.

const SPARKLE_VIEWBOX = "0 0 158.27 152.92";

/** Center of the large star inside the sparkle SVG's viewBox, in path units. */
export const SPARKLE_SVG_CENTER_X = 79.135;
export const SPARKLE_SVG_CENTER_Y = 76.46;

const SPARKLE_PATH_LARGE =
  "M0,80.51v-3.03c1.78-1.57,3.83-2.78,6.2-3.79l14.34-6.13c5.66-2.42,10.81-5.22,15.99-8.53,15.66-10.02,22.52-24.91,29.56-41.47,1.94-4.57,4.66-11.69,7.66-11.63,5.7.1,10.95,28.64,27.18,45.16,17.23,17.54,47.53,22.1,46.03,28.59-.65,2.84-8.84,5.76-13.6,7.62-31.75,12.43-40.09,22.03-52.69,53.39-1.88,4.67-4.87,12.46-7.88,12.22-2.79-.22-5.37-6.78-7.09-11.09-13.49-33.82-21.9-41.86-55.68-55.83-3.68-1.52-7.13-3.07-10.02-5.47Z";
const SPARKLE_PATH_SMALL =
  "M134.51,0l4.07,8.87c2.28,4.92,5.93,8.5,10.86,10.74l7.86,3.57c.66.3,1.02.97.96,1.49-.05.44-.47.81-1.02,1.04l-8.02,3.42c-4.74,2.02-8.41,5.36-10.53,10.07l-4.04,8.95c-.29.65-.75,1.22-1.32,1.15-.43-.05-.89-.5-1.11-1.03l-3.14-7.32c-2.22-5.19-5.84-9.24-10.99-11.62l-8.48-3.91c-.42-.19-.93-.86-.88-1.17s.61-.82,1.03-1.01l7.92-3.54c9.44-4.22,11.26-11.55,15.28-19.71h1.55Z";

// Maps a rendered size in px to the mask's SVG-unit scale, so the contracting mask
// and the flat silhouette drawn behind it land on exactly the same shape. Tuned
// against the source composition — do not re-derive from the viewBox alone.
const MASK_SCALE_PER_PX = 1.1057 / 175;

// ── 3D sparkle sprite frames ────────────────────────────────────────────────────────
// `new URL(..., import.meta.url)` rather than module imports: webpack 5 and Vite both
// detect it statically and emit the asset, and it needs no ambient "*.png" module
// declaration that could collide with one a consumer already ships.

const SPARKLE_FRAME_URLS: string[] = [
  new URL("./sparkle-frames/sparkle_00.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_01.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_02.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_03.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_04.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_05.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_06.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_07.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_08.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_09.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_10.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_11.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_12.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_13.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_14.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_15.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_16.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_17.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_18.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_19.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_20.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_21.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_22.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_23.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_24.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_25.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_26.png", import.meta.url).href,
  new URL("./sparkle-frames/sparkle_27.png", import.meta.url).href,
];

/** Number of frames in the sprite sequence (indices 0–27). */
export const SPARKLE_SPRITE_FRAME_COUNT = 28;

/**
 * The sprite's resting pose used by the outro: it freezes here through the shrink,
 * then flips 18 → 0. Frames 0 and 18 both face the camera; 9 is edge-on mid-spin.
 */
export const SPARKLE_SPRITE_REST_FRAME = 18;

/** Zoom-blue palette the default backdrop feeds to ShaderMeshGradient. */
export const SPARKLE_OUTRO_MESH_COLORS: string[] = [
  "#0053f9", // primary Zoom blue
  "#00299b", // deep royal
  "#3f8cff", // luminous accent
  "#0e6eff", // vivid electric
];

// Sits under the shader canvas so there is never a flash of empty backdrop while the
// GPU surface initialises.
const SPARKLE_OUTRO_FALLBACK_BACKGROUND =
  "linear-gradient(140deg, #00299b, #0053f9 60%, #3f8cff)";

// ── Timing ──────────────────────────────────────────────────────────────────────────

export interface SparkleMaskOutroTimings {
  /** Static frames before the contraction starts (the scene plays unmasked). Default 0. */
  holdBefore?: number;
  /**
   * Frames the mask takes to contract from full-frame to rest. Default 24. The other
   * beats (silhouette/sprite fades, unmask, flip start) scale proportionally.
   */
  shrinkDurationInFrames?: number;
  /** Extra frames to rest on the final sparkle pose after the flip. Default 0. */
  holdAfter?: number;
}

/** Frame offsets of every beat, on the same timeline as the component. */
export interface SparkleMaskOutroBeats {
  /** First frame of the mask contraction (== holdBefore). */
  shrinkStart: number;
  /** Frame the mask reaches rest size. */
  shrinkEnd: number;
  /** White silhouette fade-in window. */
  silhouetteIn: number;
  silhouetteFull: number;
  /** 3D sprite crossfade window. */
  spriteIn: number;
  spriteFull: number;
  /**
   * The sprite crossfade passes half opacity, and everything beneath it — the
   * masked scene and the flat silhouette — starts dissolving toward `unmaskEnd`.
   * Fractional by nature: it is the midpoint of the crossfade, not a rounded
   * frame.
   */
  underlayerFadeStart: number;
  /** Mask + outgoing scene unmount here; only backdrop and sprite remain. */
  unmaskEnd: number;
  /** The flip begins (sprite plays source frames 18 → 0, one per frame). */
  flipStart: number;
  /** The flip lands on its final pose (source frame 0). */
  flipEnd: number;
}

/**
 * Every beat of the outro as a frame offset. Use this to schedule your own layers
 * against the transition — e.g. mount a logo lockup at `flipEnd`.
 */
export function sparkleMaskOutroBeats(
  timings: SparkleMaskOutroTimings = {},
): SparkleMaskOutroBeats {
  const { holdBefore = 0, shrinkDurationInFrames = 24 } = timings;
  const s = shrinkDurationInFrames;
  const shrinkStart = holdBefore;
  // Ratios preserve the source composition's beats (6/15/10/25 of a 24-frame shrink).
  const spriteIn = shrinkStart + Math.round(s * (10 / 24));
  const spriteFull = shrinkStart + Math.round(s * (25 / 24));
  return {
    shrinkStart,
    shrinkEnd: shrinkStart + s,
    silhouetteIn: shrinkStart + Math.round(s * (6 / 24)),
    silhouetteFull: shrinkStart + Math.round(s * (15 / 24)),
    spriteIn,
    spriteFull,
    // Midpoint of the crossfade — the frame the sprite is half opaque.
    underlayerFadeStart: spriteIn + (spriteFull - spriteIn) / 2,
    unmaskEnd: shrinkStart + s + 3,
    flipStart: shrinkStart + s + 4,
    flipEnd: shrinkStart + s + 4 + SPARKLE_SPRITE_REST_FRAME,
  };
}

/**
 * Total frames the outro occupies: holdBefore + shrink + flip + one resting frame +
 * holdAfter. Pass the same timings you give the component.
 */
export function sparkleMaskOutroDuration(
  timings: SparkleMaskOutroTimings = {},
): number {
  const { holdAfter = 0 } = timings;
  return sparkleMaskOutroBeats(timings).flipEnd + 1 + holdAfter;
}

// ── Components ──────────────────────────────────────────────────────────────────────

export interface SparkleMaskOutroProps extends SparkleMaskOutroTimings {
  /**
   * Outgoing scene content, masked by the contracting sparkle. Renders on this
   * component's timeline (NOT rebased) and is unmounted once the mask is gone
   * (`sparkleMaskOutroBeats(...).unmaskEnd`).
   */
  outgoing: ReactNode;
  /**
   * Backdrop revealed around the contracting mask; mounted from the frame the
   * contraction starts. Default: animated Zoom-blue mesh gradient
   * (ShaderMeshGradient over SPARKLE_OUTRO_MESH_COLORS). Pass null for none.
   */
  background?: ReactNode;
  /** Center of the resting sparkle in px. Default: the composition center. */
  centerX?: number;
  /** Center of the resting sparkle in px. Default: the composition center. */
  centerY?: number;
  /** Size of the resting sparkle in px. Default 162 (tuned for 1080p). */
  sparkleSize?: number;
  /**
   * Mask scale multiplier at the start of the contraction. Default: computed so the
   * silhouette's concave gaps clear the farthest frame corner (160 at 1080p center).
   */
  maxScale?: number;
}

/**
 * The sparkle-mask outro transition. See the file header for the beat-by-beat
 * mechanic; use `sparkleMaskOutroDuration` for the sequence length and
 * `sparkleMaskOutroBeats` to schedule other layers against it.
 */
export function SparkleMaskOutro({
  outgoing,
  background,
  holdBefore = 0,
  shrinkDurationInFrames = 24,
  centerX,
  centerY,
  sparkleSize = 162,
  maxScale,
}: SparkleMaskOutroProps) {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const rawId = useId();
  const maskId = `sparkle-outro-mask-${rawId.replace(/:/g, "")}`;

  const beats = sparkleMaskOutroBeats({ holdBefore, shrinkDurationInFrames });

  const cx = centerX ?? width / 2;
  const cy = centerY ?? height / 2;

  // 160 was tuned to cover 1080p from its center; scale it with the distance to the
  // farthest corner so other sizes (or an off-center sparkle) stay fully covered.
  const farthestCorner = Math.hypot(
    Math.max(cx, width - cx),
    Math.max(cy, height - cy),
  );
  const startScale = maxScale ?? (160 * farthestCorner) / Math.hypot(960, 540);

  const shrinkProgress = interpolate(
    frame,
    [beats.shrinkStart, beats.shrinkEnd],
    [0, 1],
    {
      easing: Easing.bezier(0.16, 1, 0.3, 1),
      extrapolateLeft: "clamp",
      extrapolateRight: "clamp",
    },
  );

  // Mask (and sprite stack) scale: startScale down to 1.
  const zoomScaleMultiplier = interpolate(shrinkProgress, [0, 1], [startScale, 1]);
  const maskScale = sparkleSize * MASK_SCALE_PER_PX * zoomScaleMultiplier;

  const started = frame >= beats.shrinkStart;
  const fullyShrunk = frame >= beats.unmaskEnd;

  const silhouetteOpacity = interpolate(
    frame,
    [beats.silhouetteIn, beats.silhouetteFull],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  const spriteOpacity = interpolate(
    frame,
    [beats.spriteIn, beats.spriteFull],
    [0, 1],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  // Everything under the sprite — the masked scene and the flat silhouette —
  // dissolves from the moment the sprite is half opaque until the unmount.
  // Without this the underlayers sit at full opacity and vanish in one frame at
  // unmaskEnd; the sprite's soft edges don't quite cover the silhouette's hard
  // ones, so that cut reads as a white halo popping out of existence.
  // Landing on zero one frame BEFORE the unmount is what makes the unmount free:
  // if the fade ended exactly at unmaskEnd the layers would still be ~10% visible
  // on the last mounted frame, and dropping them would be a small step of its own.
  const underlayerOpacity = interpolate(
    frame,
    [beats.underlayerFadeStart, beats.unmaskEnd - 1],
    [1, 0],
    { extrapolateLeft: "clamp", extrapolateRight: "clamp" },
  );

  // Frozen on the resting pose until the flip, then one source frame per frame down to 0.
  const spriteFrame =
    frame >= beats.flipStart
      ? Math.max(0, SPARKLE_SPRITE_REST_FRAME - Math.floor(frame - beats.flipStart))
      : SPARKLE_SPRITE_REST_FRAME;

  const resolvedBackground =
    background === undefined ? <DefaultBackdrop /> : background;

  return (
    <AbsoluteFill style={{ overflow: "hidden" }}>
      {/* Backdrop revealed around the mask — mounted only once the contraction starts */}
      {started && resolvedBackground !== null && (
        <AbsoluteFill>{resolvedBackground}</AbsoluteFill>
      )}

      {/* Contracting sparkle mask definition */}
      <svg
        style={{ position: "absolute", width: 0, height: 0, pointerEvents: "none" }}
      >
        <defs>
          <mask
            id={maskId}
            maskUnits="userSpaceOnUse"
            x="0"
            y="0"
            width={width}
            height={height}
          >
            <rect x="0" y="0" width={width} height={height} fill="#000000" />
            <g
              transform={`translate(${cx}, ${cy}) scale(${maskScale}) translate(-${SPARKLE_SVG_CENTER_X}, -${SPARKLE_SVG_CENTER_Y})`}
            >
              <path fill="#ffffff" d={SPARKLE_PATH_LARGE} />
              <path fill="#ffffff" d={SPARKLE_PATH_SMALL} />
            </g>
          </mask>
        </defs>
      </svg>

      {/* Outgoing scene, masked once the contraction starts, unmounted after unmask */}
      {!fullyShrunk && (
        <AbsoluteFill
          style={{
            mask: started ? `url(#${maskId})` : "none",
            WebkitMask: started ? `url(#${maskId})` : "none",
            opacity: started ? underlayerOpacity : 1,
          }}
        >
          {outgoing}
        </AbsoluteFill>
      )}

      {/* Centered sparkle stack: white silhouette, then the 3D sprite over it */}
      {started && (
        <div
          style={{
            position: "absolute",
            left: cx,
            top: cy,
            width: sparkleSize,
            height: sparkleSize,
            transform: `translate(-50%, -50%) scale(${zoomScaleMultiplier})`,
            pointerEvents: "none",
          }}
        >
          {!fullyShrunk && (
            <div
              style={{
                position: "absolute",
                inset: 0,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                opacity: silhouetteOpacity * underlayerOpacity,
              }}
            >
              <SparkleSilhouette size={sparkleSize} color="#ffffff" />
            </div>
          )}
          <div
            style={{
              position: "absolute",
              inset: 0,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              opacity: spriteOpacity,
            }}
          >
            <SparkleSprite size={sparkleSize} frameIndex={spriteFrame} />
          </div>
        </div>
      )}
    </AbsoluteFill>
  );
}

interface SparkleSilhouetteProps extends SVGProps<SVGSVGElement> {
  /** Rendered width and height in px. Default 162. */
  size?: number;
  /** Fill colour of both sparkle points. Default "#ffffff". */
  color?: string;
}

/**
 * Flat vector of the four-point sparkle, drawn behind the sprite while the mask
 * contracts. Deliberately NOT exported: it exists to make the shrink read as a
 * solid shape resolving into the 3D sprite, and on its own it is just an icon —
 * which is not what this library is for. It shares its paths with the mask, so
 * the two overlay exactly.
 */
function SparkleSilhouette({
  size = 162,
  color = "#ffffff",
  style,
  ...props
}: SparkleSilhouetteProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox={SPARKLE_VIEWBOX}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ display: "block", ...style }}
      {...props}
    >
      <path fill={color} d={SPARKLE_PATH_LARGE} />
      <path fill={color} d={SPARKLE_PATH_SMALL} />
    </svg>
  );
}

export interface SparkleSpriteProps {
  /**
   * Source frame to display, 0–27 (floored and clamped). 0 and 18 are resting poses
   * facing the camera; 9 is edge-on mid-spin. Drive it from your own timeline for
   * custom playback — the outro's flip is 18 down to 0 at one per frame.
   */
  frameIndex: number;
  /** Rendered box size in px. Default 162. */
  size?: number;
  style?: CSSProperties;
}

/**
 * One frame of the 3D diamond sparkle PNG sequence, optically centred to overlay
 * the mask silhouette at the same size and center.
 */
export function SparkleSprite({ frameIndex, size = 162, style }: SparkleSpriteProps) {
  const index = Math.max(
    0,
    Math.min(SPARKLE_SPRITE_FRAME_COUNT - 1, Math.floor(frameIndex)),
  );
  return (
    <div
      style={{
        width: size,
        height: size,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        filter: "drop-shadow(0px 6px 20px rgba(0, 97, 213, 0.35))",
        pointerEvents: "none",
        flex: "none",
        ...style,
      }}
    >
      <Img
        src={SPARKLE_FRAME_URLS[index]}
        alt="3D diamond sparkle"
        style={{
          width: "100%",
          height: "100%",
          objectFit: "contain",
          // Aligns the render's optical centre with the vector sparkle's centre.
          transform: "translate(-2.87%, 1.71%) scale(1.0757)",
          transformOrigin: "50% 50%",
        }}
      />
    </div>
  );
}

function DefaultBackdrop() {
  return (
    <AbsoluteFill style={{ background: SPARKLE_OUTRO_FALLBACK_BACKGROUND }}>
      <ShaderMeshGradient
        colors={SPARKLE_OUTRO_MESH_COLORS}
        speed={0.36}
        distortion={0.55}
        swirl={0.35}
      />
    </AbsoluteFill>
  );
}
