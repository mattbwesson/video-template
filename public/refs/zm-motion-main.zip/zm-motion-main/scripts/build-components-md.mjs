#!/usr/bin/env node
// Regenerates COMPONENTS.md — the one-row-per-component inventory.
//
//   node scripts/build-components-md.mjs
//
// Generated rather than hand-written for the same reason as the barrel: an
// inventory of 90+ modules that is maintained by hand is wrong within a month,
// and a stale inventory is worse than none because it is trusted.
//
// The columns that CAN be derived are derived (component names, import paths,
// props types, duration helpers, one-line summaries lifted from each file's own
// header comment). The one column that cannot — what a component keeps MOUNTED,
// which is the cost that matters in Remotion and that nothing else surfaces —
// is curated below in MOUNTS, because it is a judgement about behaviour, not a
// fact recoverable from a regex.
import fs from "node:fs";
import path from "node:path";

const ROOT = path.resolve(import.meta.dirname, "..");

/**
 * What each component keeps mounted, and for how long. Absent = draws only its own
 * subtree for as long as the caller mounts it (the ordinary case).
 * Add a row here whenever a component can hold something on screen that the caller
 * would not expect from the call site alone.
 */
const MOUNTS = {
  "match-cut":
    "**2 scenes** during the transition window in `mode=\"directional\"` (a whip pan needs " +
    "edge-to-edge coverage); **1** in every other mode, which occlude. Outside the window all " +
    "modes drop to 1 — the dormant panel is unmounted. See `matchCutPanelLifetime`.",
  "typewriter-tracking-match-cut": "1 — the text and camera are a single subtree.",
  "zoommate-simple":
    "1 — the card. The attachment menu and the cursor are each mounted only inside " +
    "their own windows (menu: `menuOpen`→`menuGone`; cursor: `cursorIn`→`typingStart`) " +
    "rather than held at opacity 0, so neither costs anything before or after its beat.",
  "cta-pills":
    "Only the pills still on screen. Each unmounts the moment its merge completes, " +
    "rather than sitting at opacity 0 — they carry a backdrop-filter and a large shadow, " +
    "which are among the most expensive things to keep mounted in Remotion.",
  "message-dock-reveal":
    "1 — the shell. The deck editor mounts only from the frame the move starts, each " +
    "thread item only from its own slot, and the cursor only between its fly-in and its " +
    "fade-out; only the active slide's canvas is rendered, so a long deck costs one " +
    "thumbnail row per slide rather than a full canvas each.",
  "sparkle-mask-outro":
    "**`outgoing` + backdrop** from the start of the contraction until `unmaskEnd` " +
    "(shrink + 3), where the scene and mask unmount; after that only the backdrop and " +
    "the sparkle sprite remain. During `holdBefore` only `outgoing` is mounted.",
};

/**
 * One line per component, in terms of what it DOES on screen — the column an agent
 * actually chooses from. Curated because most of the vendored primitives carry no
 * header comment to lift a summary out of; where a file does have one, it is used
 * as the fallback. Keep these to a single clause.
 */
const DESCRIPTIONS = {
  // transitions
  "match-cut": "A→B cut hidden inside fast motion. Six modes: scale, directional (whip pan), directional-scale, rotational, scale-rotational, perspective (real 3D flip).",
  "typewriter-tracking-match-cut": "Types a sentence while the camera tracks the cursor, then a 3D pull-back match cut to fit the whole line.",
  "whip-pan": "TransitionPresentation: fast directional pan with motion blur. Use inside `<TransitionSeries>`.",
  "push-through": "TransitionPresentation: scene B pushes through/past scene A. Use inside `<TransitionSeries>`.",
  "message-dock-reveal": "A centred message docks into a chat sidebar while the app shell fades up and a deck editor slides in from the right — one continuous move — then a cursor clicks down the slide thumbnails. Ships the whole surface: icon rail, composer, thumbnails and slide canvas, all driven by one slide model.",
  "sparkle-mask-outro": "Outro: the scene collapses into a four-point sparkle over a mesh-gradient backdrop, then the 3D sparkle plays a flip and rests. `SparkleSprite` draws any single pose of the sequence if you want to drive playback yourself; ships its own PNG frames.",
  // scenes & flows
  "chat-gpt": "ChatGPT-style prompt-and-response scene, typed prompt then streaming answer.",
  "claude-chat": "Claude-style chat scene, typed prompt then streaming answer.",
  "imessage-chat-flow": "iMessage thread: bubbles arrive in sequence with typing indicators.",
  "signup-flow": "Multi-step signup form filling itself in — fields, validation, submit.",
  "settings-toggle-flow": "Settings panel with switches and rows toggling in sequence.",
  "live-code-compilation": "Code types itself out and compiles, with output appearing beneath.",
  "ecosystem-constellation": "Labelled nodes orbiting a centre mark, connected by lines.",
  "infinite-bento-pan": "Continuous pan across a seamless bento-grid of cards.",
  "cta-pills": "Labelled glass pills pop in one at a time while the camera jump-cuts between them, then all of them arc into the centre and are absorbed.",
  "zoom-meeting": "Zoom meeting UI: participant tiles, active-speaker highlight, toolbar.",
  "zoommate-full": "The whole ZoomMate surface as a window — rail, header, title, composer, chips and an agenda card cut off by the bottom edge — assembling in staggered groups, then the content pans up inside the frame.",
  "zoommate-full-icons": "The ZoomMate icon set `ZoomMateFull` draws from, lifted verbatim from the design.",
  "zoommate-simple": "ZoomMate composer alone (no product chrome): cursor opens the attachment menu, ticks each row, then the prompt types out as the pill grows into a card.",
  "dashboard-nav-zoom": "Camera pushes into a Zoom account dashboard's left nav while a selection pill slides down onto one submenu row, lighting up whichever row it currently passes over.",
  "orbit-animation/IconOrbitScene": "Icons orbiting a centre point on elliptical paths.",
  // backgrounds
  "shader-grain-gradient": "Animated grainy gradient backdrop (GPU shader).",
  "shader-mesh-gradient": "Animated mesh gradient backdrop (GPU shader).",
  "perspective-marquee": "Perspective-skewed marquee of scrolling text.",
  backdrop: "Generic full-frame backdrop layer — solid, gradient or image.",
  "orbit-animation/BlobBackground": "Soft drifting colour blobs behind a scene.",
  "orbit-animation/RippleDotGrid": "Dot grid with an expanding shockwave ripple; `burst` for a stronger multi-front wave.",
  // text
  "blur-in": "Text resolves in from a blur.",
  "blur-out-up": "Text blurs out while drifting upward.",
  "bottom-up-letters": "Letters rise into place from below, staggered.",
  drift: "Text drifts gently in one direction.",
  "focus-blur-resolve": "Text pulls from out-of-focus to sharp.",
  "inline-highlight": "A highlight sweeps behind an inline run of text.",
  "kinetic-center-build": "Words assemble outward from the centre.",
  "line-by-line-slide": "Lines slide in one after another.",
  "marker-highlight": "Hand-drawn marker stroke sweeps across text.",
  "mask-reveal-up": "Text revealed by a mask wiping upward.",
  "micro-scale-fade": "Subtle scale-and-fade entrance.",
  "per-character-rise": "Each character rises independently, staggered.",
  "per-word-crossfade": "Words crossfade between two phrases.",
  "rgb-glitch-text": "RGB channel-split glitch on text.",
  "rolling-number": "Number rolls odometer-style to a target value.",
  "rolodex-flip": "Text flips like a rolodex card to the next value.",
  "scale-down-fade": "Text scales down as it fades out.",
  "shared-axis-z": "Material shared-axis Z transition between two texts.",
  "shimmer-sweep": "A shimmer highlight sweeps across text.",
  "silky-smooth": "Headline glides in word by word — the slide outlasts the fade and the whole block travels with it; optional reverse-order exit.",
  "short-slide-down": "Short slide-down entrance.",
  "short-slide-right": "Short slide-right entrance.",
  "slot-machine-roll": "Characters spin like slot reels before settling.",
  "soft-blur-in": "Gentle blur-and-fade entrance.",
  "spring-scale-in": "Springy scale-up entrance.",
  "staggered-fade-up": "Lines/words fade up on a stagger.",
  "tracking-in": "Letter-spacing contracts as text fades in.",
  typewriter: "Types text out character by character.",
  "value-swap": "Swaps one value for another with a vertical roll.",
  // ui primitives
  accordion: "Expanding/collapsing accordion panel.",
  button: "Button with press/hover/loading states.",
  caret: "Blinking text caret.",
  "command-menu": "Command palette shell.",
  "command-menu-item": "A single command-palette row.",
  cursor: "Animated mouse cursor that follows a path.",
  "dropdown-menu": "Dropdown menu surface.",
  "dropdown-menu-item": "A single dropdown row.",
  field: "Labelled form field wrapper.",
  input: "Text input with focus/typing states.",
  "message-bubble": "Chat bubble with entrance and optional reaction.",
  progress: "Determinate progress bar.",
  resizable: "Resizable split pane with a draggable divider.",
  select: "Select control surface.",
  "select-item": "A single select option row.",
  sheet: "Bottom/side sheet that slides in.",
  slider: "Draggable value slider.",
  spinner: "Indeterminate loading spinner.",
  stepper: "Multi-step progress stepper.",
  switch: "On/off toggle switch.",
  tabs: "Tab bar with an animated active indicator.",
  toast: "Toast notification that slides in and out.",
  "typing-indicator": "Three-dot 'typing…' indicator.",
};

const HOOK_NOTE =
  "Returns the animated style for its component — pass the result to the matching primitive.";

const isScreaming = (n) => /^[A-Z0-9_]+$/.test(n);

function sourcePath(mod) {
  return ["tsx", "ts"]
    .map((ext) => path.join(ROOT, `${mod}.${ext}`))
    .find((p) => fs.existsSync(p));
}

/** First meaningful sentence of the file's leading comment block, if it has one. */
function summarize(src) {
  const block = src.match(/^\s*\/\*\*([\s\S]*?)\*\//);
  let text;
  if (block) {
    text = block[1]
      .split("\n")
      .map((l) => l.replace(/^\s*\*ic?\s?/, "").replace(/^\s*\*\s?/, ""))
      .join(" ");
  } else {
    const lines = [];
    for (const line of src.split("\n")) {
      const m = line.match(/^\/\/\s?(.*)$/);
      if (m) lines.push(m[1]);
      else if (lines.length) break;
      else if (line.trim() === "") continue;
      else break;
    }
    text = lines.join(" ");
  }
  if (!text) return "";
  // Drop a leading "filename.tsx — " prefix, then take the first sentence.
  text = text.replace(/^\s*[\w.-]+\.tsx?\s*[—-]\s*/, "").trim();
  const stop = text.search(/\.\s|\.$/);
  if (stop > 0) text = text.slice(0, stop + 1);
  return text.replace(/\s+/g, " ").replace(/\|/g, "\\|").trim();
}

const GROUPS = JSON.parse(
  fs.readFileSync(path.join(ROOT, "scripts/component-groups.json"), "utf8"),
);

const rows = [];
for (const [title, mods] of GROUPS) {
  const group = [];
  for (const mod of mods.slice().sort()) {
    const file = sourcePath(mod);
    if (!file) throw new Error(`missing source for ${mod}`);
    const src = fs.readFileSync(file, "utf8");

    const values = [...src.matchAll(/^export\s+(?:const|function)\s+([A-Za-z0-9_]+)/gm)]
      .map((m) => m[1])
      .filter((n) => !isScreaming(n));
    const types = [...src.matchAll(/^export\s+(?:type|interface)\s+([A-Za-z0-9_]+)/gm)].map(
      (m) => m[1],
    );

    const components = values.filter((n) => /^[A-Z]/.test(n));
    const hooks = values.filter((n) => /^use[A-Z]/.test(n));
    const durations = values.filter((n) => /Duration(InFrames)?$/.test(n));
    const propsTypes = types.filter((n) => /Props$/.test(n));

    const primary = components[0] ?? hooks[0] ?? values[0];
    if (!primary) continue;

    group.push({
      mod,
      primary,
      extras: [...components.slice(1), ...hooks.filter((h) => h !== primary)],
      props: propsTypes[0] ?? "",
      duration: durations[0] ?? "",
      summary:
        DESCRIPTIONS[mod] ?? (mod.startsWith("use-") ? HOOK_NOTE : summarize(src)),
      mounts: MOUNTS[mod] ?? "",
    });
  }
  rows.push([title, group]);
}

const total = rows.reduce((n, [, g]) => n + g.length, 0);

const out = [];
out.push("# COMPONENTS");
out.push("");
out.push("<!-- GENERATED by scripts/build-components-md.mjs — do not edit by hand. -->");
out.push("<!-- Re-run: node scripts/build-components-md.mjs -->");
out.push("");
out.push(
  `Every component in zm-motion — ${total} entries. This is the file to read first: one row ` +
    "per component, so you can pick the right one without listing the package or opening 90 files.",
);
out.push("");
out.push("## How to read this");
out.push("");
out.push("- **Import** — every component is also available from the barrel:");
out.push("  `import {MatchCut, framesFor} from 'zm-motion'`. The per-file path shown is the");
out.push("  tree-shakeable form.");
out.push("- **Duration** — call this instead of hand-computing a frame count. Passing a wrong");
out.push("  frame count fails silently: the motion just feels off, with no error to search for.");
out.push("- **Mounts** — what the component keeps on screen, and for how long. Blank means the");
out.push("  ordinary case (its own subtree, for as long as you mount it). This column exists");
out.push("  because in Remotion a mounted-but-invisible element still costs a full render,");
out.push("  layout, paint and one frame extraction per `<OffthreadVideo>` — there is no");
out.push("  compositor to skip it. `<Sequence>` is the only construct that unmounts anything;");
out.push("  `opacity: 0`, `visibility: hidden`, `scale(0)` and off-canvas transforms are all");
out.push("  *invisible but mounted*, and all cost full price.");
out.push("");
out.push("## Before you write frame math");
out.push("");
out.push("`framesFor(seconds, fps)` (from `zm-motion` or `zm-motion/lib`) converts seconds to");
out.push("frames at the composition's actual fps. Reach for it instead of `Math.round(sec * 30)`");
out.push("— a hardcoded fps silently breaks every timing the moment the composition changes rate.");
out.push("");
out.push("Also in `lib`: `easings`, `springs`, `clamp01`, `revealCount`, `revealedText`,");
out.push("`useTypewriter`, `useStateTransition`, OKLCH colour helpers, and the theme provider.");
out.push("");

for (const [title, group] of rows) {
  if (!group.length) continue;
  out.push(`## ${title}`);
  out.push("");
  out.push("| Component | Import | Props | Duration | Does | Mounts |");
  out.push("|---|---|---|---|---|---|");
  for (const r of group) {
    const name = [`\`${r.primary}\``, ...r.extras.map((e) => `\`${e}\``)].join("<br>");
    out.push(
      `| ${name} | \`zm-motion/${r.mod}\` | ${r.props ? `\`${r.props}\`` : "—"} | ` +
        `${r.duration ? `\`${r.duration}\`` : "—"} | ${r.summary || "—"} | ${r.mounts || "—"} |`,
    );
  }
  out.push("");
}

fs.writeFileSync(path.join(ROOT, "COMPONENTS.md"), out.join("\n") + "\n");
console.log(`build-components-md: COMPONENTS.md <- ${total} components`);
